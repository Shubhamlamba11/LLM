# Adaptive Reasoning in Uncertainty
## Multi-Modal Uncertainty Quantification System for LLMs

A comprehensive Python framework for estimating, calibrating, and managing uncertainty in Large Language Model outputs across text, images, and structured data.

---

## IMPORTANT: How It Works

**This system requires a real LLM model for accurate uncertainty estimation.**

Without a model, the system uses heuristic fallbacks that provide moderate accuracy.

### With a Real Model (Recommended)
```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from uncertainty_quant import AdvancedUncertaintyEstimator

model_name = "microsoft/Phi-3-mini-128k-instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

estimator = AdvancedUncertaintyEstimator(model=model, tokenizer=tokenizer)
result = estimator.estimate(prompt, response)
```

### Without a Model (Limited)
The system uses heuristics and will work, but with reduced accuracy.

---

## Features

### Core Uncertainty Estimation (8+ methods)
- **Token Probability Uncertainty (TPU)**: Measures uncertainty from token-level probabilities
- **Semantic Entropy**: Captures uncertainty in semantic meaning across multiple samples
- **Verbalized Uncertainty**: Detects uncertainty expressions in generated text
- **Self-Consistency**: Measures agreement across multiple model generations
- **Puzzle-based**: Detects mathematical/arithmetic uncertainty
- **Semantic Augmentation**: Perturbation-based uncertainty
- **NLI-based**: Natural Language Inference for contradiction detection
- **Margin-based**: Top-k probability margins

### Hallucination Detection
- **Semantic-Verbal Mismatch**: Identifies when models express high certainty about uncertain content
- **Cross-Model Consistency**: Uses multiple models to detect potential hallucinations
- **Claim Extraction & Verification**: Extracts factual claims and checks consistency
- **Risk Classification**: Categorizes outputs by hallucination risk level

### Reasoning Integration
- **Chain-of-Thought Uncertainty Tracking**: Step-level confidence propagation
- **Tree of Uncertain Thoughts (TouT)**: Uncertainty-aware reasoning path selection
- **Process Reward Model (PRM)**: Step-by-step reasoning verification
- **Confidence Chain**: Recurrent confidence tracking across reasoning steps
- **Critical Step Identification**: Highlights unreliable reasoning steps

### Multi-Modal Fusion
- **Text + Image + Structured Data**: Unified uncertainty from multiple modalities
- **Cross-Modal Consistency**: Detects conflicts between modalities
- **Adaptive Weighting**: Automatically weights modalities by reliability

### Evaluation & Benchmarking
```python
from uncertainty_quant.evaluation import UncertaintyEvaluator

evaluator = UncertaintyEvaluator()
report = evaluator.run_full_evaluation(
    confidences=your_confidences,
    correct=your_correct_labels,
)

# Check metrics
print(f"ECE: {report.calibration.ece:.4f}")  # Should be < 0.05
print(f"AUROC: {report.selective_prediction.auroc:.4f}")  # Should be > 0.85
```

---

## Quick Start with Real Model

```bash
# Install dependencies
pip install torch transformers numpy

# Run with model
python example_with_model.py
```

## Example with Real Model

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from uncertainty_quant import AdvancedUncertaintyEstimator, HallucinationDetector
from uncertainty_quant.api import UnifiedUncertaintyAPI

# Load model
MODEL = "microsoft/Phi-3-mini-128k-instruct"  # Or any HuggingFace model
tokenizer = AutoTokenizer.from_pretrained(MODEL)
model = AutoModelForCausalLM.from_pretrained(MODEL)

# Initialize with model
estimator = AdvancedUncertaintyEstimator(model=model, tokenizer=tokenizer)
detector = HallucinationDetector(model=model, tokenizer=tokenizer)

# Generate response
prompt = "Who won the Nobel Prize in Physics 2024?"
inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
outputs = model.generate(**inputs, max_new_tokens=200)
response = tokenizer.decode(outputs[0], skip_special_tokens=True)

# Analyze uncertainty
result = estimator.estimate(prompt, response, return_all=True)
print(f"Uncertainty: {result.total_uncertainty:.3f}")
print(f"Confidence: {result.confidence:.3f}")

# Check for hallucination
hall_result = detector.detect(prompt, response, return_all=True)
print(f"Is Hallucination: {hall_result.is_hallucination}")
```

---

## Evaluation Framework

The system includes comprehensive evaluation tools to prove uncertainty estimates are accurate:

```bash
# Run evaluation benchmark
python -m uncertainty_quant.evaluation

# Run baseline comparison
python -m uncertainty_quant.benchmark

# Run red flag detection
python -m uncertainty_quant.red_flag_tests

# Run realistic scenario tests
python -m uncertainty_quant.test_realistic
```

### Key Metrics

| Metric | Target | Meaning |
|--------|--------|---------|
| **ECE** | < 0.05 | When model says "80% confident", it's right ~80% of the time |
| **AUROC** | > 0.85 | Uncertainty separates correct from incorrect predictions |
| **Coverage @ 90%** | > 0.70 | Can use 70%+ of predictions at 90% accuracy |

---

## Architecture

```
uncertainty_quant/
├── core/
│   ├── uncertainty_estimator.py    # Basic estimation
│   ├── advanced_estimator.py      # 8+ methods with model support
│   └── calibration.py             # Temperature scaling, isotonic regression
├── hallucination/
│   └── detector.py               # Hallucination detection
├── reasoning/
│   ├── cot_tracker.py            # Chain-of-Thought tracking
│   ├── tout.py                   # Tree of Uncertain Thoughts
│   ├── prm_verifier.py          # Process Reward Model
│   └── router.py                # Uncertainty-aware routing
├── multimodal/
│   └── fusion.py                # Multi-modal uncertainty fusion
├── evaluation.py                 # Evaluation framework
├── benchmark.py                 # Baseline comparisons
├── red_flag_tests.py            # Failure mode detection
├── test_realistic.py            # Realistic scenario tests
├── api.py                       # Unified API
├── api_server.py               # FastAPI production server
├── demo.py                      # Basic demonstration
└── demo_advanced.py             # Advanced features demonstration
```

---

## Production API Server

```bash
# Install server dependencies
pip install fastapi uvicorn

# Start server
python -m uncertainty_quant.api_server
```

Then call:
```bash
curl -X POST http://localhost:8000/api/v1/uncertainty \
  -H "Content-Type: application/json" \
  -d '{"prompt": "What is AI?", "response": "AI stands for Artificial Intelligence."}'
```

---

## Risk Levels

- **LOW** (< 0.2): High confidence, minimal verification needed
- **MEDIUM** (0.2-0.4): Standard verification recommended
- **HIGH** (0.4-0.6): Careful verification advised
- **CRITICAL** (> 0.6): Human review strongly recommended

---

## Supported Models

Works with any HuggingFace transformers model:

| Model Family | Example Models |
|--------------|----------------|
| Llama | meta-llama/Llama-3.2-1B, meta-llama/Llama-3.2-70B |
| Mistral | mistralai/Mistral-7B-Instruct |
| Phi | microsoft/Phi-3-mini-128k-instruct |
| Qwen | Qwen/Qwen2.5-7B-Instruct |
| Gemma | google/gemma-2-2b-it |
| Custom | Any AutoModelForCausalLM compatible model |

---

## Installation

```bash
pip install torch transformers numpy scipy scikit-learn
```

Or install all dependencies:
```bash
pip install -r requirements.txt
```

---

## License

MIT License
