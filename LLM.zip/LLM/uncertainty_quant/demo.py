"""
Demo Application for Uncertainty Quantification System
Interactive demonstration of multi-modal uncertainty estimation
"""

import json
from typing import Dict, Any, Optional, List


def demo_basic_uncertainty():
    from uncertainty_quant import UncertaintyEstimator
    
    estimator = UncertaintyEstimator()
    
    print("=" * 60)
    print("DEMO 1: Basic Uncertainty Estimation")
    print("=" * 60)
    
    test_cases = [
        ("What is the capital of France?", "The capital of France is Paris."),
        ("Should I invest in tech stocks?", "Maybe, but it's uncertain."),
        ("What is 2+2?", "2+2 equals 4."),
    ]
    
    for prompt, response in test_cases:
        result = estimator.estimate(prompt, response, return_all=True)
        print(f"\nPrompt: {prompt}")
        print(f"Response: {response}")
        print(f"Uncertainty: {result.total_uncertainty:.3f}")
        print(f"Confidence: {result.confidence:.3f}")
        print(f"Risk Level: {result.get_risk_level()}")


def demo_hallucination_detection():
    from uncertainty_quant import HallucinationDetector
    
    detector = HallucinationDetector()
    
    print("\n" + "=" * 60)
    print("DEMO 2: Hallucination Detection")
    print("=" * 60)
    
    test_cases = [
        {
            "prompt": "Who won the Nobel Prize in Physics in 2024?",
            "response": "The Nobel Prize in Physics 2024 was won by John Smith from MIT.",
        },
        {
            "prompt": "What is machine learning?",
            "response": "Machine learning is a subset of artificial intelligence that enables systems to learn from data.",
        },
    ]
    
    for case in test_cases:
        result = detector.detect(
            case["prompt"],
            case["response"],
            return_all=True
        )
        print(f"\nPrompt: {case['prompt']}")
        print(f"Response: {case['response']}")
        print(f"Is Hallucination: {result.is_hallucination}")
        print(f"Confidence: {result.confidence:.3f}")
        print(f"Risk Level: {result.risk_level}")
        print(f"Recommendation: {result.get_recommendation()}")


def demo_cot_uncertainty():
    from uncertainty_quant import CoTUncertaintyTracker
    
    tracker = CoTUncertaintyTracker()
    
    print("\n" + "=" * 60)
    print("DEMO 3: Chain-of-Thought Uncertainty Tracking")
    print("=" * 60)
    
    reasoning = """
    Step 1: First, I need to identify the key variables in this problem.
    The problem asks about the relationship between study time and test scores.
    
    Step 2: Based on the data, students who studied 10 hours scored around 85%.
    Students who studied 5 hours scored around 70%.
    
    Step 3: Therefore, there appears to be a positive correlation between study time and test scores.
    
    Step 4: The answer is that more study time generally leads to higher test scores.
    """
    
    analysis = tracker.analyze(
        "What is the relationship between study time and test scores?",
        reasoning,
        return_all=True
    )
    
    print(f"\nOverall Confidence: {analysis.overall_confidence:.3f}")
    print(f"Uncertainty Score: {analysis.uncertainty_score:.3f}")
    print(f"Chain Reliability: {analysis.chain_reliability:.3f}")
    print(f"\nStep-by-Step Analysis:")
    
    for step in analysis.steps:
        print(f"  Step {step.step_number}: {step.get_confidence_level().value} "
              f"(confidence: {step.confidence:.2f}, importance: {step.importance:.2f})")
    
    suggestions = tracker.suggest_refinement(analysis)
    if suggestions:
        print(f"\nRefinement Suggestions:")
        for s in suggestions:
            print(f"  - {s['reason']}: {s['action']}")


def demo_tree_of_thoughts():
    from uncertainty_quant import TreeOfUncertainThoughts, SearchStrategy
    
    tout = TreeOfUncertainThoughts(
        max_depth=4,
        max_breadth=3,
        num_samples=3,
    )
    
    print("\n" + "=" * 60)
    print("DEMO 4: Tree of Uncertain Thoughts")
    print("=" * 60)
    
    problem = "Solve: If a train travels 120 km in 2 hours, what is its average speed?"
    
    def generate_fn(content, k=3):
        return [
            f"{content} - Calculate distance/time",
            f"{content} - Use speed formula",
            f"{content} - Check units first",
        ]
    
    def evaluate_fn(content):
        if "formula" in content.lower():
            return 0.9, 0.1
        elif "calculate" in content.lower():
            return 0.7, 0.2
        else:
            return 0.5, 0.4
    
    result = tout.solve(
        problem,
        generate_fn=generate_fn,
        evaluate_fn=evaluate_fn,
        search_strategy=SearchStrategy.BEST_FIRST,
        return_all=True
    )
    
    print(f"\nProblem: {problem}")
    print(f"Result: {result.get_summary()}")
    print(f"\nExploration Stats:")
    print(f"  Total Nodes: {result.exploration_stats['total_nodes']}")
    print(f"  Expanded: {result.exploration_stats['expanded']}")
    print(f"  Pruned: {result.exploration_stats['pruned']}")
    print(f"  Max Depth: {result.exploration_stats['max_depth_reached']}")
    
    if result.best_path:
        print(f"\nBest Path ({len(result.best_path)} steps):")
        for i, node in enumerate(result.best_path):
            print(f"  {i+1}. {node.content[:50]}... "
                  f"(uncertainty: {node.uncertainty:.2f})")


def demo_multimodal():
    from uncertainty_quant import MultiModalUncertaintyFusion, ModalityUncertainty, ModalModality
    
    fusion = MultiModalUncertaintyFusion()
    
    print("\n" + "=" * 60)
    print("DEMO 5: Multi-Modal Uncertainty Fusion")
    print("=" * 60)
    
    mod_uncs = [
        ModalityUncertainty(
            modality=ModalModality.TEXT,
            uncertainty=0.3,
            confidence=0.9,
        ),
        ModalityUncertainty(
            modality=ModalModality.IMAGE,
            uncertainty=0.5,
            confidence=0.7,
        ),
        ModalityUncertainty(
            modality=ModalModality.STRUCTURED,
            uncertainty=0.2,
            confidence=0.8,
        ),
    ]
    
    result = fusion.fuse(mod_uncs, return_all=True)
    
    print(f"\nFused Uncertainty: {result.fused_uncertainty:.3f}")
    print(f"Dominant Modality: {result.dominant_modality.value}")
    print(f"Consensus Score: {result.consensus_score:.3f}")
    print(f"Cross-Modal Conflict: {result.has_cross_modal_conflict()}")
    print(f"\nModality Ranking:")
    for modality, unc in result.get_modality_ranking():
        print(f"  {modality}: {unc:.3f}")


def demo_routing():
    from uncertainty_quant import UncertaintyAwareRouter
    
    router = UncertaintyAwareRouter()
    
    print("\n" + "=" * 60)
    print("DEMO 6: Uncertainty-Aware Routing")
    print("=" * 60)
    
    test_queries = [
        "What is the capital of France?",
        "Analyze the implications of quantum computing on cryptography.",
        "Calculate the derivative of x^2 + 3x - 5 at x=2.",
    ]
    
    for query in test_queries:
        decision = router.route(query, return_all=True)
        print(f"\nQuery: {query}")
        print(f"Selected Solver: {decision.selected_solver.value}")
        print(f"Uncertainty: {decision.uncertainty:.3f}")
        print(f"Reasoning: {decision.reasoning}")
        print(f"Needs Verification: {decision.requires_additional_verification()}")


def demo_unified_api():
    from uncertainty_quant.api import UnifiedUncertaintyAPI, OutputFormat
    
    api = UnifiedUncertaintyAPI()
    
    print("\n" + "=" * 60)
    print("DEMO 7: Unified API")
    print("=" * 60)
    
    test_cases = [
        {
            "prompt": "Explain quantum entanglement.",
            "response": "Quantum entanglement is a phenomenon where particles become connected.",
        },
        {
            "prompt": "What is 2+2?",
            "response": "2+2 = 4.",
        },
    ]
    
    for case in test_cases:
        report = api.analyze(
            case["prompt"],
            case["response"],
            detect_hallucination=True,
            analyze_reasoning=True,
            route_query=True,
            output_format=OutputFormat.DETAILED,
        )
        
        print(f"\nPrompt: {case['prompt']}")
        print(f"Response: {case['response']}")
        print(f"\nUncertainty Report:")
        print(f"  Overall Uncertainty: {report.overall_uncertainty:.3f}")
        print(f"  Confidence: {report.confidence:.3f}")
        print(f"  Risk Level: {report.risk_level}")
        print(f"  Should Verify: {report.should_verify()}")
        print(f"\nBreakdown:")
        for key, value in report.uncertainty_breakdown.items():
            print(f"  {key}: {value:.3f}")
        print(f"\nRecommendations:")
        for rec in report.recommendations:
            print(f"  - {rec}")


def run_all_demos():
    print("\n" + "=" * 60)
    print("UNCERTAINTY QUANTIFICATION SYSTEM - DEMONSTRATION")
    print("=" * 60)
    
    demo_basic_uncertainty()
    demo_hallucination_detection()
    demo_cot_uncertainty()
    demo_tree_of_thoughts()
    demo_multimodal()
    demo_routing()
    demo_unified_api()
    
    print("\n" + "=" * 60)
    print("ALL DEMOS COMPLETED")
    print("=" * 60)


if __name__ == "__main__":
    run_all_demos()
