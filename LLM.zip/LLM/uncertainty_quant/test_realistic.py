"""
Realistic Evaluation with Proper Test Data
Tests the system with realistic scenarios
"""

import numpy as np
from uncertainty_quant import AdvancedUncertaintyEstimator, UncertaintyEstimator


def test_with_realistic_scenarios():
    print("=" * 70)
    print("REALISTIC SCENARIO EVALUATION")
    print("=" * 70)
    
    estimator = AdvancedUncertaintyEstimator()
    basic_estimator = UncertaintyEstimator()
    
    scenarios = [
        {
            "name": "High Confidence Correct (Easy Factual)",
            "prompt": "What is the capital of France?",
            "response": "The capital of France is Paris.",
            "expected_confidence": "HIGH",
            "should_be_correct": True,
        },
        {
            "name": "High Confidence Wrong (Hallucination)",
            "prompt": "Who won the Nobel Prize in Physics 2024?",
            "response": "John Smith from MIT won the Nobel Prize in Physics 2024.",
            "expected_confidence": "LOW (but model is overconfident)",
            "should_be_correct": False,
        },
        {
            "name": "Medium Confidence Uncertain (Subjective)",
            "prompt": "Should I invest in tech stocks?",
            "response": "Maybe, but it's uncertain. Tech stocks can be volatile.",
            "expected_confidence": "MEDIUM",
            "should_be_correct": True,  # Subjective so no right/wrong
        },
        {
            "name": "Math Problem (Verifiable)",
            "prompt": "What is 15% of 200?",
            "response": "15% of 200 is 30.",
            "expected_confidence": "HIGH",
            "should_be_correct": True,
        },
        {
            "name": "Out-of-Distribution (Future)",
            "prompt": "What will happen in the year 3025?",
            "response": "In 3025, humanity has colonized Mars.",
            "expected_confidence": "LOW",
            "should_be_correct": False,  # Cannot predict
        },
    ]
    
    print("\n{:<45} {:>12} {:>12} {:>10}".format(
        "Scenario", "Confidence", "Uncertainty", "Risk"
    ))
    print("-" * 80)
    
    all_results = []
    
    for scenario in scenarios:
        result = estimator.estimate(scenario["prompt"], scenario["response"])
        
        all_results.append({
            "scenario": scenario["name"],
            "confidence": result.confidence,
            "uncertainty": result.total_uncertainty,
            "risk_level": result.risk_level,
            "expected_correct": scenario["should_be_correct"],
        })
        
        print("{:<45} {:>12.2f} {:>12.2f} {:>10}".format(
            scenario["name"][:45],
            result.confidence,
            result.total_uncertainty,
            result.risk_level,
        ))
    
    print("\n" + "=" * 70)
    print("CALIBRATION ANALYSIS")
    print("=" * 70)
    
    print("\n{:<35} {:>10} {:>12} {:>12}".format(
        "Scenario", "Conf", "Expected", "Calibrated?"
    ))
    print("-" * 70)
    
    calibration_checks = []
    
    for i, scenario in enumerate(scenarios):
        result = all_results[i]
        
        if scenario["expected_confidence"] == "HIGH":
            expected_range = (0.6, 1.0)
            calibrated = expected_range[0] <= result["confidence"] <= expected_range[1]
        elif scenario["expected_confidence"] == "MEDIUM":
            expected_range = (0.3, 0.7)
            calibrated = expected_range[0] <= result["confidence"] <= expected_range[1]
        else:
            expected_range = (0.0, 0.4)
            calibrated = result["confidence"] <= expected_range[1]
        
        status = "[OK]" if calibrated else "[MIS]"
        calibration_checks.append(calibrated)
        
        print("{:<35} {:>10.2f} {:>12} {:>12}".format(
            scenario["name"][:35],
            result["confidence"],
            scenario["expected_confidence"][:12],
            status,
        ))
    
    print("\n" + "=" * 70)
    print("HALLUCINATION DETECTION TEST")
    print("=" * 70)
    
    from uncertainty_quant import HallucinationDetector
    
    detector = HallucinationDetector()
    
    hallucination_cases = [
        {
            "name": "Definite Hallucination",
            "prompt": "Who won the Nobel Prize in Physics 2024?",
            "response": "John Smith from MIT won the Nobel Prize in Physics 2024.",
        },
        {
            "name": "Likely Hallucination",
            "prompt": "What is the population of planet X?",
            "response": "Planet X has a population of 15 billion people.",
        },
        {
            "name": "Likely Correct",
            "prompt": "What is machine learning?",
            "response": "Machine learning is a subset of artificial intelligence.",
        },
        {
            "name": "Definite Correct",
            "prompt": "What is H2O?",
            "response": "H2O is the chemical formula for water.",
        },
    ]
    
    print("\n{:<35} {:>15} {:>12}".format(
        "Case", "Hallucination?", "Risk"
    ))
    print("-" * 65)
    
    for case in hallucination_cases:
        result = detector.detect(
            case["prompt"],
            case["response"],
            return_all=True
        )
        
        status = "YES" if result.is_hallucination else "NO"
        
        print("{:<35} {:>15} {:>12}".format(
            case["name"][:35],
            status,
            result.risk_level,
        ))
    
    print("\n" + "=" * 70)
    print("REASONING CHAIN VERIFICATION")
    print("=" * 70)
    
    from uncertainty_quant import ProcessRewardVerifier
    
    verifier = ProcessRewardVerifier()
    
    reasoning_cases = [
        {
            "name": "Correct Math Chain",
            "prompt": "Calculate 25 + 17",
            "chain": """
Step 1: Identify the numbers: 25 and 17
Step 2: Add the ones place: 5 + 7 = 12
Step 3: Write down 2, carry 1
Step 4: Add the tens: 2 + 1 + 1 = 4
Step 5: Therefore, 25 + 17 = 42
""",
        },
        {
            "name": "Incorrect Math Chain",
            "prompt": "Calculate 25 + 17",
            "chain": """
Step 1: Identify the numbers: 25 and 17
Step 2: Add the ones place: 5 + 7 = 13
Step 3: Write down 3, carry 1
Step 4: Add the tens: 2 + 1 + 1 = 5
Step 5: Therefore, 25 + 17 = 53
""",
        },
    ]
    
    print("\n{:<35} {:>12} {:>12} {:>10}".format(
        "Case", "Verdict", "Score", "Errors"
    ))
    print("-" * 70)
    
    for case in reasoning_cases:
        result = verifier.verify(case["prompt"], case["chain"], return_all=True)
        
        print("{:<35} {:>12} {:>12.2f} {:>10}".format(
            case["name"][:35],
            result.get_verdict(),
            result.overall_score,
            result.total_errors,
        ))
    
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    
    calibration_rate = sum(calibration_checks) / len(calibration_checks)
    
    print(f"\nCalibration Rate: {calibration_rate:.0%} ({sum(calibration_checks)}/{len(calibration_checks)})")
    print(f"Scenarios Tested: {len(scenarios)}")
    print(f"Hallucination Cases: {len(hallucination_cases)}")
    print(f"Reasoning Chains: {len(reasoning_cases)}")
    
    if calibration_rate >= 0.8:
        print("\n[RESULT] System shows GOOD calibration on realistic scenarios")
    elif calibration_rate >= 0.6:
        print("\n[RESULT] System shows MODERATE calibration - room for improvement")
    else:
        print("\n[RESULT] System needs IMPROVEMENT on calibration")


def run_auroc_calculation():
    print("\n" + "=" * 70)
    print("AUROC CALCULATION (Selective Prediction Test)")
    print("=" * 70)
    
    from uncertainty_quant import AdvancedUncertaintyEstimator
    
    estimator = AdvancedUncertaintyEstimator()
    
    np.random.seed(42)
    
    test_cases = []
    
    factual_correct = [
        ("What is the capital of France?", "The capital of France is Paris."),
        ("What is H2O?", "H2O is water."),
        ("What planet are we on?", "We are on Earth."),
        ("What is 2+2?", "2+2 equals 4."),
    ]
    
    factual_incorrect = [
        ("Who won the Nobel Prize in 2024?", "John Smith won the Nobel Prize."),
        ("What year did Rome fall?", "Rome fell in 3025."),
    ]
    
    subjective_cases = [
        ("What should I have for dinner?", "That's a matter of personal preference."),
        ("Is AI dangerous?", "AI has both benefits and risks."),
    ]
    
    for prompt, response in factual_correct * 25:
        test_cases.append((prompt, response, True, "factual"))
    
    for prompt, response in factual_incorrect * 25:
        test_cases.append((prompt, response, False, "factual"))
    
    for prompt, response in subjective_cases * 10:
        test_cases.append((prompt, response, True, "subjective"))
    
    confidences = []
    is_correct = []
    
    print(f"\nTesting {len(test_cases)} cases...")
    
    for prompt, response, expected_correct, case_type in test_cases:
        result = estimator.estimate(prompt, response)
        confidences.append(result.confidence)
        is_correct.append(expected_correct or result.total_uncertainty > 0.5)
    
    confidences = np.array(confidences)
    is_correct = np.array(is_correct)
    
    print("\n{:<20} {:>10}".format("Metric", "Value"))
    print("-" * 35)
    
    print("{:<20} {:>10.2f}".format("Avg Confidence", confidences.mean()))
    print("{:<20} {:>10.2%}".format("Accuracy", is_correct.mean()))
    
    uncertainties = 1 - confidences
    
    auroc = compute_auroc(uncertainties, ~is_correct)
    print("{:<20} {:>10.4f}".format("AUROC", auroc))
    
    for threshold in [0.5, 0.6, 0.7, 0.8, 0.9]:
        mask = confidences >= threshold
        coverage = mask.mean()
        if mask.sum() > 0:
            accuracy_at_threshold = is_correct[mask].mean()
        else:
            accuracy_at_threshold = 0
        print("{:<20} {:>10.2%} {:>10.2%}".format(
            f"Conf>{threshold:.1f}:",
            coverage,
            accuracy_at_threshold
        ))
    
    print("\n" + "=" * 70)
    
    if auroc > 0.85:
        print("[SUCCESS] AUROC > 0.85 - Uncertainty predicts errors well!")
    elif auroc > 0.70:
        print("[MODERATE] AUROC 0.70-0.85 - Some predictive power")
    else:
        print("[NEEDS WORK] AUROC < 0.70 - Uncertainty doesn't predict errors")


def compute_auroc(uncertainties: np.ndarray, is_error: np.ndarray) -> float:
    pos_unc = uncertainties[is_error]
    neg_unc = uncertainties[~is_error]
    
    if len(pos_unc) == 0 or len(neg_unc) == 0:
        return 0.5
    
    comparisons = 0
    for u_pos in pos_unc:
        for u_neg in neg_unc:
            if u_pos > u_neg:
                comparisons += 1
            elif u_pos == u_neg:
                comparisons += 0.5
    
    return comparisons / (len(pos_unc) * len(neg_unc))


if __name__ == "__main__":
    test_with_realistic_scenarios()
    run_auroc_calculation()
