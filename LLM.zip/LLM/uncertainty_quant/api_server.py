"""
Production API Server for Uncertainty Quantification
FastAPI-based async server with caching and batch processing
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any, Union
from contextlib import asynccontextmanager
import asyncio
import hashlib
import json
from datetime import datetime
from collections import defaultdict
import threading

from .core.advanced_estimator import AdvancedUncertaintyEstimator, UncertaintyMethod, AdvancedUncertaintyResult
from .hallucination.detector import HallucinationDetector, HallucinationResult
from .reasoning.prm_verifier import ProcessRewardVerifier, ReasoningVerification
from .reasoning.cot_tracker import CoTUncertaintyTracker
from .reasoning.tout import TreeOfUncertainThoughts, SearchStrategy
from .multimodal.fusion import MultiModalUncertaintyFusion, ModalityUncertainty, ModalModality
from .core.calibration import Calibrator, CalibrationMethod


cache = {}
cache_lock = threading.Lock()
stats = defaultdict(int)
stats_lock = threading.Lock()


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Starting Uncertainty Quantification API...")
    yield
    print("Shutting down...")


app = FastAPI(
    title="Uncertainty Quantification API",
    description="Multi-modal uncertainty estimation for LLMs",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

estimator = AdvancedUncertaintyEstimator(use_cache=True)
hallucination_detector = HallucinationDetector()
prm_verifier = ProcessRewardVerifier()
cot_tracker = CoTUncertaintyTracker()
tout_solver = TreeOfUncertainThoughts()
multimodal_fusion = MultiModalUncertaintyFusion()
calibrator = Calibrator(method=CalibrationMethod.TEMPERATURE_SCALING)


class UncertaintyRequest(BaseModel):
    prompt: str
    response: Optional[str] = None
    methods: Optional[List[str]] = None
    include_reasoning: bool = False
    include_hallucination: bool = True


class BatchUncertaintyRequest(BaseModel):
    items: List[Dict[str, str]]
    include_hallucination: bool = False


class ReasoningRequest(BaseModel):
    prompt: str
    reasoning_chain: str
    verify_steps: bool = True


class TouTRequest(BaseModel):
    problem: str
    max_depth: int = 8
    max_breadth: int = 5
    strategy: str = "best_first"
    uncertainty_threshold: float = 0.5


class MultiModalRequest(BaseModel):
    text: str
    image_features: Optional[Dict[str, Any]] = None
    structured_data: Optional[Dict[str, Any]] = None
    context: Optional[str] = None


class CalibrationRequest(BaseModel):
    uncertainties: List[float]
    correctness: List[bool]


def _update_stats(key: str):
    with stats_lock:
        stats[key] += 1


def _get_cache_key(prompt: str, response: Optional[str] = None) -> str:
    text = prompt + (response or "")
    return hashlib.sha256(text.encode()).hexdigest()


@app.get("/")
async def root():
    return {
        "service": "Uncertainty Quantification API",
        "version": "1.0.0",
        "endpoints": {
            "uncertainty": "/api/v1/uncertainty",
            "batch": "/api/v1/uncertainty/batch",
            "reasoning": "/api/v1/reasoning/verify",
            "tout": "/api/v1/solve/tout",
            "multimodal": "/api/v1/multimodal",
            "calibrate": "/api/v1/calibrate",
            "stats": "/api/v1/stats",
        }
    }


@app.post("/api/v1/uncertainty")
async def analyze_uncertainty(request: UncertaintyRequest):
    _update_stats("uncertainty_requests")
    
    cache_key = _get_cache_key(request.prompt, request.response)
    
    with cache_lock:
        if cache_key in cache:
            _update_stats("cache_hits")
            return cache[cache_key]
    
    methods = None
    if request.methods:
        methods = [UncertaintyMethod(m) for m in request.methods]
    
    result = estimator.estimate(
        request.prompt,
        request.response,
        methods=methods,
        return_all=True,
    )
    
    response_data = {
        "uncertainty": result.total_uncertainty,
        "confidence": result.confidence,
        "epistemic": result.epistemic,
        "aleatoric": result.aleatoric,
        "risk_level": result.risk_level,
        "method_scores": result.method_scores,
        "uncertainty_components": result.uncertainty_components,
        "confidence_interval": list(result.confidence_interval),
        "recommendations": result.recommendations,
        "calibration_quality": result.calibration_quality,
    }
    
    hallucination_data = None
    if request.include_hallucination and request.response:
        hall_result = hallucination_detector.detect(
            request.prompt,
            request.response,
            return_all=True,
        )
        hallucination_data = {
            "is_hallucination": hall_result.is_hallucination,
            "confidence": hall_result.confidence,
            "risk_level": hall_result.risk_level,
            "hallucination_type": hall_result.hallucination_type.value if hall_result.hallucination_type else None,
            "mismatch_score": hall_result.mismatch_score,
            "contributing_factors": list(hall_result.contributing_factors),
        }
        response_data["hallucination"] = hallucination_data
    
    reasoning_data = None
    if request.include_reasoning and request.response:
        cot_result = cot_tracker.analyze(
            request.prompt,
            request.response,
            return_all=True,
        )
        reasoning_data = {
            "overall_confidence": cot_result.overall_confidence,
            "uncertainty_score": cot_result.uncertainty_score,
            "chain_reliability": cot_result.chain_reliability,
            "weakest_step": cot_result.weakest_step.step_number if cot_result.weakest_step else None,
            "step_confidences": cot_result.confidence_chain,
        }
        response_data["reasoning"] = reasoning_data
    
    with cache_lock:
        cache[cache_key] = response_data
    
    return response_data


@app.post("/api/v1/uncertainty/batch")
async def batch_uncertainty(request: BatchUncertaintyRequest):
    _update_stats("batch_requests")
    
    items = [(item.get("prompt", ""), item.get("response")) for item in request.items]
    
    results = []
    for prompt, response in items:
        result = estimator.estimate(prompt, response, return_all=True)
        
        item_result = {
            "prompt": prompt,
            "response": response,
            "uncertainty": result.total_uncertainty,
            "confidence": result.confidence,
            "risk_level": result.risk_level,
        }
        
        if request.include_hallucination and response:
            hall = hallucination_detector.detect(prompt, response, return_all=True)
            item_result["hallucination"] = {
                "is_hallucination": hall.is_hallucination,
                "confidence": hall.confidence,
            }
        
        results.append(item_result)
    
    return {"results": results, "total": len(results)}


@app.post("/api/v1/reasoning/verify")
async def verify_reasoning(request: ReasoningRequest):
    _update_stats("reasoning_requests")
    
    if request.verify_steps:
        verification = prm_verifier.verify(
            request.prompt,
            request.reasoning_chain,
            return_all=True,
        )
        
        return {
            "verdict": verification.get_verdict(),
            "overall_score": verification.overall_score,
            "total_errors": verification.total_errors,
            "chain_reliability": verification.chain_reliability,
            "reliable_steps": verification.reliable_steps,
            "unreliable_steps": verification.unreliable_steps,
            "critical_errors": verification.critical_errors,
            "requires_regeneration": verification.requires_regeneration(),
            "steps": [s.to_dict() for s in verification.steps],
            "fix_suggestions": verification.get_fix_suggestions(),
        }
    else:
        cot_result = cot_tracker.analyze(
            request.prompt,
            request.reasoning_chain,
            return_all=True,
        )
        
        return {
            "overall_confidence": cot_result.overall_confidence,
            "uncertainty_score": cot_result.uncertainty_score,
            "chain_reliability": cot_result.chain_reliability,
            "steps": [
                {
                    "step": s.step_number,
                    "confidence": s.confidence,
                    "importance": s.importance,
                    "is_critical": s.is_critical,
                }
                for s in cot_result.steps
            ],
            "issues": cot_result.get_step_issues(),
        }


@app.post("/api/v1/solve/tout")
async def solve_with_tout(request: TouTRequest):
    _update_stats("tout_requests")
    
    strategy_map = {
        "bfs": SearchStrategy.BFS,
        "dfs": SearchStrategy.DFS,
        "best_first": SearchStrategy.BEST_FIRST,
        "ucb": SearchStrategy.UCB,
    }
    
    strategy = strategy_map.get(request.strategy.lower(), SearchStrategy.BEST_FIRST)
    
    tout = TreeOfUncertainThoughts(
        max_depth=request.max_depth,
        max_breadth=request.max_breadth,
        uncertainty_threshold=request.uncertainty_threshold,
    )
    
    result = tout.solve(
        request.problem,
        search_strategy=strategy,
        return_all=True,
    )
    
    return {
        "solution": result.best_path[-1].content if result.best_path else None,
        "uncertainty": result.final_uncertainty,
        "risk_level": "LOW" if result.final_uncertainty < 0.3 else "MEDIUM" if result.final_uncertainty < 0.6 else "HIGH",
        "path_length": len(result.best_path),
        "exploration_stats": result.exploration_stats,
        "best_path": [
            {
                "depth": n.depth,
                "uncertainty": n.uncertainty,
                "value": n.value,
                "content_preview": n.content[:100],
            }
            for n in result.best_path
        ],
    }


@app.post("/api/v1/multimodal")
async def analyze_multimodal(request: MultiModalRequest):
    _update_stats("multimodal_requests")
    
    mod_uncs = []
    
    text_unc = multimodal_fusion.estimate_text_uncertainty(request.text, request.context)
    mod_uncs.append(text_unc)
    
    if request.image_features:
        img_unc = multimodal_fusion.estimate_image_uncertainty(request.image_features)
        mod_uncs.append(img_unc)
    
    if request.structured_data:
        struct_unc = multimodal_fusion.estimate_structured_uncertainty(request.structured_data)
        mod_uncs.append(struct_unc)
    
    if len(mod_uncs) == 1:
        return {
            "fused_uncertainty": mod_uncs[0].uncertainty,
            "modality": mod_uncs[0].modality.value,
            "confidence": mod_uncs[0].confidence,
        }
    
    result = multimodal_fusion.fuse(mod_uncs, return_all=True)
    
    return {
        "fused_uncertainty": result.fused_uncertainty,
        "dominant_modality": result.dominant_modality.value,
        "consensus_score": result.consensus_score,
        "disagreement_score": result.disagreement_score,
        "cross_modal_conflict": result.has_cross_modal_conflict(),
        "modality_ranking": [(m.value, u) for m, u in result.get_modality_ranking()],
        "reliability_weights": {m.value: w for m, w in result.reliability_weights.items()},
    }


@app.post("/api/v1/calibrate")
async def calibrate_system(request: CalibrationRequest):
    _update_stats("calibration_requests")
    
    calibrator.fit(request.uncertainties, request.correctness)
    
    eval_result = calibrator.evaluate_calibration(
        request.uncertainties,
        request.correctness,
    )
    
    return {
        "status": "calibrated",
        "calibration_quality": eval_result,
        "calibration_params": calibrator.to_dict(),
    }


@app.get("/api/v1/stats")
async def get_stats():
    with stats_lock:
        total = sum(stats.values())
    
    cache_size = len(cache)
    
    return {
        "total_requests": total,
        "requests_by_type": dict(stats),
        "cache_size": cache_size,
        "cache_hit_rate": stats.get("cache_hits", 0) / max(total, 1),
    }


@app.post("/api/v1/cache/clear")
async def clear_cache():
    with cache_lock:
        cache.clear()
    return {"status": "cache_cleared", "size": 0}


def run_server(host: str = "0.0.0.0", port: int = 8000):
    import uvicorn
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    run_server()
