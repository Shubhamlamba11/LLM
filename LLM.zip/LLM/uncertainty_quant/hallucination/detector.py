"""
Hallucination Detection Module
Detects hallucinations via semantic-verbal uncertainty mismatch and cross-consistency
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional, Any, Tuple
import numpy as np


class HallucinationType(Enum):
    FACTUAL = "factual"
    SEMANTIC = "semantic"
    NUMERICAL = "numerical"
    REFERENTIAL = "referential"
    UNKNOWN = "unknown"


@dataclass
class HallucinationResult:
    is_hallucination: bool
    confidence: float
    hallucination_type: Optional[HallucinationType] = None
    semantic_uncertainty: float = 0.0
    verbal_uncertainty: float = 0.0
    mismatch_score: float = 0.0
    contributing_factors: List[str] = field(default_factory=dict)
    extracted_claims: List[str] = field(default_factory=list)
    risk_level: str = "LOW"
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_recommendation(self) -> str:
        if self.risk_level == "CRITICAL":
            return "Do not use - high hallucination probability. Verify with external source."
        elif self.risk_level == "HIGH":
            return "Use with caution - verify critical claims before proceeding."
        elif self.risk_level == "MEDIUM":
            return "Partially reliable - review key assertions."
        else:
            return "Low hallucination risk - proceed with normal verification."
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_hallucination": self.is_hallucination,
            "confidence": self.confidence,
            "hallucination_type": self.hallucination_type.value if self.hallucination_type else None,
            "semantic_uncertainty": self.semantic_uncertainty,
            "verbal_uncertainty": self.verbal_uncertainty,
            "mismatch_score": self.mismatch_score,
            "risk_level": self.risk_level,
            "recommendation": self.get_recommendation(),
            "contributing_factors": list(self.contributing_factors),
        }


class HallucinationDetector:
    def __init__(
        self,
        model: Any = None,
        tokenizer: Any = None,
        nli_model: Any = None,
        device: str = "cpu",
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.nli_model = nli_model
        self.device = device
        self.claim_cache: Dict[str, List[str]] = {}
        
    def detect(
        self,
        prompt: str,
        response: str,
        context: Optional[str] = None,
        return_all: bool = False,
    ) -> HallucinationResult:
        claims = self._extract_claims(response)
        
        semantic_uncertainty = self._compute_semantic_uncertainty(prompt, response, claims)
        verbal_uncertainty = self._compute_verbal_uncertainty(response)
        mismatch_score = self._compute_mismatch(semantic_uncertainty, verbal_uncertainty)
        
        factual_consistency = self._check_factual_consistency(prompt, response, claims, context)
        numerical_accuracy = self._check_numerical_claims(response, claims)
        referential_coherence = self._check_referential_coherence(response, claims)
        
        cross_model_consistency = self._compute_cross_model_consistency(prompt, response)
        
        hallucination_score = self._compute_hallucination_score(
            semantic_uncertainty, verbal_uncertainty, mismatch_score,
            factual_consistency, numerical_accuracy, referential_coherence,
            cross_model_consistency
        )
        
        h_type = self._classify_hallucination_type(
            factual_consistency, numerical_accuracy, referential_coherence
        )
        
        risk_level = self._determine_risk_level(
            hallucination_score, mismatch_score, factual_consistency
        )
        
        contributing = []
        if mismatch_score > 0.4:
            contributing.append("High semantic-verbal uncertainty mismatch")
        if factual_consistency < 0.5:
            contributing.append("Low factual consistency with context")
        if numerical_accuracy < 0.6:
            contributing.append("Potential numerical inconsistency")
        if referential_coherence < 0.5:
            contributing.append("Referential coherence issues")
        if cross_model_consistency < 0.4:
            contributing.append("Low cross-model agreement")
            
        result = HallucinationResult(
            is_hallucination=bool(hallucination_score > 0.5),
            confidence=float(1.0 - abs(hallucination_score - 0.5) * 2),
            hallucination_type=h_type,
            semantic_uncertainty=semantic_uncertainty,
            verbal_uncertainty=verbal_uncertainty,
            mismatch_score=mismatch_score,
            contributing_factors=contributing,
            extracted_claims=claims,
            risk_level=risk_level,
            metadata={
                "factual_consistency": factual_consistency,
                "numerical_accuracy": numerical_accuracy,
                "referential_coherence": referential_coherence,
                "cross_model_consistency": cross_model_consistency,
            }
        )
        
        if return_all:
            return result
        return result.is_hallucination
    
    def _extract_claims(self, response: str) -> List[str]:
        import re
        
        claim_patterns = [
            r'(?:According to|stated|reported|found|discovered) ([^.]+)\.',
            r'(\d+(?:\.\d+)?(?:\s*%)?(?:\s*(?:million|billion|thousand)?\s*(?:\w+)?)?)\s+(?:people|users|individuals|participants|respondents)',
            r'(?:The|That|This)\s+(\w+)\s+(?:is|was|are|were)\s+([^.]+)\.',
            r'(?:in\s+\d{4}|during\s+\w+\s+\d{4}|since\s+\d{4})',
        ]
        
        claims = []
        sentences = response.split('.')
        
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) > 20:
                for pattern in claim_patterns:
                    if re.search(pattern, sentence, re.IGNORECASE):
                        claims.append(sentence)
                        break
                else:
                    if any(word in sentence.lower() for word in ['is', 'was', 'has', 'have', 'will', 'would']):
                        claims.append(sentence)
        
        return claims[:20]
    
    def _compute_semantic_uncertainty(
        self, prompt: str, response: str, claims: List[str]
    ) -> float:
        if len(claims) == 0:
            return 0.3
        
        consistency_scores = []
        for claim in claims:
            consistency = self._semantic_similarity(prompt + " " + response, claim)
            consistency_scores.append(consistency)
        
        uncertainty = 1.0 - np.mean(consistency_scores)
        return min(uncertainty * 1.5, 1.0)
    
    def _semantic_similarity(self, text1: str, text2: str) -> float:
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        words1 = {w for w in words1 if len(w) > 2}
        words2 = {w for w in words2 if len(w) > 2}
        
        if not words1 or not words2:
            return 0.5
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union) if union else 0.5
    
    def _compute_verbal_uncertainty(self, response: str) -> float:
        uncertainty_indicators = {
            "i think": 0.3, "i believe": 0.3, "probably": 0.4, "possibly": 0.5,
            "maybe": 0.5, "might": 0.4, "perhaps": 0.5, "seems": 0.4,
            "appears": 0.4, "suggests": 0.3, "indicates": 0.3, "likely": 0.3,
            "uncertain": 0.7, "unclear": 0.7, "unknown": 0.8, "not sure": 0.6,
        }
        
        certain_indicators = {
            "definitely": 0.0, "certainly": 0.0, "obviously": 0.0, "clearly": 0.0,
            "undoubtedly": 0.0, "absolutely": 0.0, "always": 0.0, "never": 0.1,
            "proven": 0.1, "established": 0.1, "fact": 0.1, "always true": 0.0,
        }
        
        text_lower = response.lower()
        scores = []
        
        for indicator, score in uncertainty_indicators.items():
            if indicator in text_lower:
                scores.append(score)
                
        for indicator, score in certain_indicators.items():
            if indicator in text_lower:
                scores.append(score)
        
        if not scores:
            return 0.6
        
        return min(np.mean(scores) + 0.2, 1.0)
    
    def _compute_mismatch(
        self, semantic_uncertainty: float, verbal_uncertainty: float
    ) -> float:
        mismatch = abs(semantic_uncertainty - verbal_uncertainty)
        
        if semantic_uncertainty > 0.6 and verbal_uncertainty < 0.3:
            return min(mismatch * 1.5, 1.0)
        
        return mismatch
    
    def _check_factual_consistency(
        self,
        prompt: str,
        response: str,
        claims: List[str],
        context: Optional[str] = None,
    ) -> float:
        if context is None:
            context = prompt
        
        if len(claims) == 0:
            return 0.7
        
        consistency_scores = []
        for claim in claims:
            score = self._fact_consistency_score(context, claim)
            consistency_scores.append(score)
        
        return np.mean(consistency_scores) if consistency_scores else 0.5
    
    def _fact_consistency_score(self, context: str, claim: str) -> float:
        context_words = set(context.lower().split())
        claim_words = set(claim.lower().split())
        
        context_words = {w for w in context_words if len(w) > 2}
        claim_words = {w for w in claim_words if len(w) > 2}
        
        if not claim_words:
            return 0.5
            
        overlap = len(context_words & claim_words)
        return min(overlap / len(claim_words), 1.0)
    
    def _check_numerical_claims(
        self, response: str, claims: List[str]
    ) -> float:
        import re
        
        numbers = re.findall(r'\d+(?:\.\d+)?', response)
        
        if len(numbers) <= 1:
            return 0.9
        
        number_claims = [c for c in claims if re.search(r'\d+', c)]
        
        if len(number_claims) < 2:
            return 0.8
        
        conflicts = 0
        for i, c1 in enumerate(number_claims):
            for c2 in number_claims[i+1:]:
                nums1 = set(re.findall(r'\d+(?:\.\d+)?', c1))
                nums2 = set(re.findall(r'\d+(?:\.\d+)?', c2))
                
                common = nums1 & nums2
                if common and nums1 != nums2:
                    conflicts += 0.5
                    
        return max(0.0, 1.0 - conflicts / len(number_claims))
    
    def _check_referential_coherence(self, response: str, claims: List[str]) -> float:
        pronouns = ["he", "she", "it", "they", "this", "that", "these", "those"]
        
        pronouns_in_response = sum(1 for p in pronouns if f" {p} " in f" {response.lower()} ")
        
        if pronouns_in_response == 0:
            return 0.9
        
        antecedents = [c.split()[0] for c in claims if c.split()]
        valid_references = sum(1 for p in pronouns if any(a.lower() in f" {response.lower()} " for a in antecedents))
        
        if pronouns_in_response > 0:
            return min(valid_references / pronouns_in_response, 1.0)
        return 0.9
    
    def _compute_cross_model_consistency(
        self, prompt: str, response: str
    ) -> float:
        simulated_responses = [
            response,
            self._paraphrase(response),
            self._alternative_response(prompt),
        ]
        
        similarities = []
        for r1 in [response]:
            for r2 in simulated_responses[1:]:
                sim = self._semantic_similarity(r1, r2)
                similarities.append(sim)
        
        return np.mean(similarities) if similarities else 0.5
    
    def _paraphrase(self, text: str) -> str:
        return text
    
    def _alternative_response(self, prompt: str) -> str:
        return f"Alternative response to: {prompt[:50]}..."
    
    def _compute_hallucination_score(
        self,
        semantic_uncertainty: float,
        verbal_uncertainty: float,
        mismatch_score: float,
        factual_consistency: float,
        numerical_accuracy: float,
        referential_coherence: float,
        cross_model_consistency: float,
    ) -> float:
        weights = {
            "mismatch": 0.25,
            "factual": 0.25,
            "numerical": 0.15,
            "referential": 0.10,
            "cross_model": 0.25,
        }
        
        score = (
            mismatch_score * weights["mismatch"] +
            (1 - factual_consistency) * weights["factual"] +
            (1 - numerical_accuracy) * weights["numerical"] +
            (1 - referential_coherence) * weights["referential"] +
            (1 - cross_model_consistency) * weights["cross_model"]
        )
        
        return min(max(score, 0.0), 1.0)
    
    def _classify_hallucination_type(
        self,
        factual_consistency: float,
        numerical_accuracy: float,
        referential_coherence: float,
    ) -> Optional[HallucinationType]:
        if factual_consistency < 0.4:
            return HallucinationType.FACTUAL
        elif numerical_accuracy < 0.5:
            return HallucinationType.NUMERICAL
        elif referential_coherence < 0.4:
            return HallucinationType.REFERENTIAL
        elif factual_consistency < 0.6:
            return HallucinationType.SEMANTIC
        return None
    
    def _determine_risk_level(
        self,
        hallucination_score: float,
        mismatch_score: float,
        factual_consistency: float,
    ) -> str:
        if hallucination_score > 0.7 or (mismatch_score > 0.5 and factual_consistency < 0.3):
            return "CRITICAL"
        elif hallucination_score > 0.5 or mismatch_score > 0.4:
            return "HIGH"
        elif hallucination_score > 0.3 or mismatch_score > 0.25:
            return "MEDIUM"
        return "LOW"
    
    def detect_batch(
        self,
        items: List[Tuple[str, str]],
        context: Optional[str] = None,
    ) -> List[HallucinationResult]:
        return [
            self.detect(prompt, response, context) 
            for prompt, response in items
        ]
