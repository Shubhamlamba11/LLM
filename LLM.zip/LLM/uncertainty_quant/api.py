"""
Unified Uncertainty Quantification API
Comprehensive interface for multi-modal uncertainty estimation
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any, Union, Callable
from enum import Enum

from .core.uncertainty_estimator import UncertaintyEstimator, UncertaintyResult, UncertaintyType
from .core.calibration import Calibrator, CalibrationMethod
from .hallucination.detector import HallucinationDetector, HallucinationResult
from .reasoning.cot_tracker import CoTUncertaintyTracker, CoTAnalysis
from .reasoning.tout import TreeOfUncertainThoughts, TouTResult
from .reasoning.router import UncertaintyAwareRouter, RoutingDecision
from .multimodal.fusion import (
    MultiModalUncertaintyFusion,
    MultiModalResult,
    ModalityUncertainty,
    ModalModality,
)


class OutputFormat(Enum):
    COMPACT = "compact"
    DETAILED = "detailed"
    FULL = "full"


@dataclass
class UncertaintyReport:
    overall_uncertainty: float
    confidence: float
    risk_level: str
    
    uncertainty_breakdown: Dict[str, float] = field(default_factory=dict)
    hallucination_check: Optional[HallucinationResult] = None
    reasoning_analysis: Optional[CoTAnalysis] = None
    routing_decision: Optional[RoutingDecision] = None
    multi_modal: Optional[MultiModalResult] = None
    
    recommendations: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def should_verify(self, threshold: float = 0.5) -> bool:
        return self.overall_uncertainty > threshold
    
    def should_reject(self, threshold: float = 0.75) -> bool:
        return self.overall_uncertainty > threshold
    
    def to_dict(self, format: OutputFormat = OutputFormat.COMPACT) -> Dict[str, Any]:
        result = {
            "uncertainty": self.overall_uncertainty,
            "confidence": self.confidence,
            "risk_level": self.risk_level,
            "should_verify": self.should_verify(),
            "should_reject": self.should_reject(),
            "recommendations": self.recommendations,
        }
        
        if format in [OutputFormat.DETAILED, OutputFormat.FULL]:
            result["uncertainty_breakdown"] = self.uncertainty_breakdown
            result["warnings"] = self.warnings
            
        if format == OutputFormat.FULL:
            result["hallucination_check"] = self.hallucination_check.to_dict() if self.hallucination_check else None
            result["reasoning_analysis"] = self.reasoning_analysis.to_dict() if self.reasoning_analysis else None
            result["routing_decision"] = self.routing_decision.to_dict() if self.routing_decision else None
            result["multi_modal"] = self.multi_modal.to_dict() if self.multi_modal else None
            result["metadata"] = self.metadata
            
        return result


class UnifiedUncertaintyAPI:
    def __init__(
        self,
        model: Any = None,
        tokenizer: Any = None,
        device: str = "cpu",
        default_uncertainty_threshold: float = 0.5,
        enable_hallucination_detection: bool = True,
        enable_reasoning_analysis: bool = True,
        enable_routing: bool = True,
        enable_multimodal: bool = True,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.threshold = default_uncertainty_threshold
        
        self.uncertainty_estimator = UncertaintyEstimator(
            model=model,
            tokenizer=tokenizer,
            device=device,
        )
        
        self.calibrator = Calibrator(method=CalibrationMethod.TEMPERATURE_SCALING)
        
        self.hallucination_detector = None
        if enable_hallucination_detection:
            self.hallucination_detector = HallucinationDetector(
                model=model,
                tokenizer=tokenizer,
                device=device,
            )
        
        self.cot_tracker = None
        if enable_reasoning_analysis:
            self.cot_tracker = CoTUncertaintyTracker(
                model=model,
                tokenizer=tokenizer,
                device=device,
            )
        
        self.tout_solver = None
        if enable_reasoning_analysis:
            self.tout_solver = TreeOfUncertainThoughts(
                model=model,
                tokenizer=tokenizer,
                device=device,
            )
        
        self.router = None
        if enable_routing:
            self.router = UncertaintyAwareRouter(
                uncertainty_estimator=self.uncertainty_estimator,
            )
        
        self.multimodal_fusion = None
        if enable_multimodal:
            self.multimodal_fusion = MultiModalUncertaintyFusion()
        
        self.calibration_data: List[Dict[str, Any]] = []
    
    def analyze(
        self,
        prompt: str,
        response: Optional[str] = None,
        context: Optional[str] = None,
        text: Optional[str] = None,
        image_features: Optional[Dict[str, Any]] = None,
        structured_data: Optional[Dict[str, Any]] = None,
        analyze_reasoning: bool = True,
        detect_hallucination: bool = True,
        route_query: bool = False,
        output_format: OutputFormat = OutputFormat.DETAILED,
    ) -> UncertaintyReport:
        input_text = text or response or prompt
        
        uncertainty_result = self.uncertainty_estimator.estimate(
            prompt, response, return_all=True
        )
        
        uncertainty_breakdown = {}
        if hasattr(uncertainty_result, 'method_scores'):
            uncertainty_breakdown = uncertainty_result.method_scores
        if hasattr(uncertainty_result, 'epistemic_uncertainty') and uncertainty_result.epistemic_uncertainty:
            uncertainty_breakdown['epistemic'] = uncertainty_result.epistemic_uncertainty
        if hasattr(uncertainty_result, 'aleatoric_uncertainty') and uncertainty_result.aleatoric_uncertainty:
            uncertainty_breakdown['aleatoric'] = uncertainty_result.aleatoric_uncertainty
        
        hallucination_result = None
        if detect_hallucination and self.hallucination_detector and response:
            hallucination_result = self.hallucination_detector.detect(
                prompt, response, context, return_all=True
            )
            uncertainty_breakdown['hallucination_risk'] = (
                hallucination_result.confidence if hallucination_result else 0.5
            )
        
        reasoning_analysis = None
        if analyze_reasoning and self.cot_tracker and response:
            reasoning_analysis = self.cot_tracker.analyze(
                prompt, response, return_all=True
            )
            if reasoning_analysis:
                uncertainty_breakdown['reasoning_uncertainty'] = reasoning_analysis.uncertainty_score
        
        routing_decision = None
        if route_query and self.router:
            routing_decision = self.router.route(
                prompt, context, return_all=True
            )
            if routing_decision:
                uncertainty_breakdown['routing_uncertainty'] = routing_decision.uncertainty
        
        multi_modal_result = None
        if self.multimodal_fusion:
            mod_uncs = []
            
            text_unc = self.multimodal_fusion.estimate_text_uncertainty(input_text, context)
            mod_uncs.append(text_unc)
            
            if image_features:
                img_unc = self.multimodal_fusion.estimate_image_uncertainty(image_features)
                mod_uncs.append(img_unc)
            
            if structured_data:
                struct_unc = self.multimodal_fusion.estimate_structured_uncertainty(structured_data)
                mod_uncs.append(struct_unc)
            
            if len(mod_uncs) > 1:
                multi_modal_result = self.multimodal_fusion.fuse(mod_uncs, return_all=True)
                uncertainty_breakdown['text_uncertainty'] = text_unc.uncertainty
                if image_features:
                    uncertainty_breakdown['image_uncertainty'] = img_unc.uncertainty
                if structured_data:
                    uncertainty_breakdown['structured_uncertainty'] = struct_unc.uncertainty
        
        overall_uncertainty = self._compute_overall_uncertainty(
            uncertainty_result, hallucination_result, reasoning_analysis, multi_modal_result
        )
        
        recommendations, warnings = self._generate_recommendations(
            overall_uncertainty, hallucination_result, reasoning_analysis, routing_decision
        )
        
        risk_level = self._determine_risk_level(overall_uncertainty)
        
        return UncertaintyReport(
            overall_uncertainty=overall_uncertainty,
            confidence=1.0 - overall_uncertainty,
            risk_level=risk_level,
            uncertainty_breakdown=uncertainty_breakdown,
            hallucination_check=hallucination_result,
            reasoning_analysis=reasoning_analysis,
            routing_decision=routing_decision,
            multi_modal=multi_modal_result,
            recommendations=recommendations,
            warnings=warnings,
            metadata={
                "input_length": len(prompt),
                "response_length": len(response) if response else 0,
                "analyzers_enabled": {
                    "uncertainty": True,
                    "hallucination": detect_hallucination,
                    "reasoning": analyze_reasoning,
                    "routing": route_query,
                    "multimodal": multi_modal_result is not None,
                }
            }
        )
    
    def _compute_overall_uncertainty(
        self,
        uncertainty_result: UncertaintyResult,
        hallucination_result: Optional[HallucinationResult],
        reasoning_analysis: Optional[CoTAnalysis],
        multi_modal_result: Optional[MultiModalResult],
    ) -> float:
        components = [uncertainty_result.total_uncertainty]
        weights = [0.4]
        
        if hallucination_result and hallucination_result.confidence < 0.5:
            components.append(hallucination_result.confidence)
            weights.append(0.25)
        
        if reasoning_analysis:
            components.append(reasoning_analysis.uncertainty_score)
            weights.append(0.2)
        
        if multi_modal_result:
            components.append(multi_modal_result.fused_uncertainty)
            weights.append(0.15)
        
        total_weight = sum(weights)
        if total_weight > 0:
            normalized_weights = [w / total_weight for w in weights]
            overall = sum(c * w for c, w in zip(components, normalized_weights))
            return min(overall, 1.0)
        
        return uncertainty_result.total_uncertainty
    
    def _generate_recommendations(
        self,
        overall_uncertainty: float,
        hallucination_result: Optional[HallucinationResult],
        reasoning_analysis: Optional[CoTAnalysis],
        routing_decision: Optional[RoutingDecision],
    ) -> tuple:
        recommendations = []
        warnings = []
        
        if overall_uncertainty > 0.75:
            recommendations.append("CRITICAL: High uncertainty - Do not use without verification")
            warnings.append("Output confidence is critically low")
        elif overall_uncertainty > 0.5:
            recommendations.append("Verify output with additional sources before use")
        
        if hallucination_result and hallucination_result.is_hallucination:
            recommendations.append(f"Potential hallucination detected ({hallucination_result.hallucination_type})")
            warnings.extend(hallucination_result.contributing_factors)
        
        if reasoning_analysis and reasoning_analysis.weakest_step:
            recommendations.append(
                f"Review reasoning step {reasoning_analysis.weakest_step.step_number} "
                f"(confidence: {reasoning_analysis.weakest_step.confidence:.2f})"
            )
        
        if routing_decision and routing_decision.requires_additional_verification():
            recommendations.append(
                f"Use {routing_decision.selected_solver.value} with verification"
            )
        
        if not recommendations:
            recommendations.append("Output appears reliable - standard verification recommended")
        
        return recommendations, warnings
    
    def _determine_risk_level(self, uncertainty: float) -> str:
        if uncertainty < 0.2:
            return "LOW"
        elif uncertainty < 0.4:
            return "MEDIUM"
        elif uncertainty < 0.6:
            return "HIGH"
        else:
            return "CRITICAL"
    
    def solve_with_uncertainty(
        self,
        problem: str,
        context: Optional[str] = None,
        use_tout: bool = True,
        verify_solution: bool = True,
    ) -> Dict[str, Any]:
        if use_tout and self.tout_solver:
            tout_result = self.tout_solver.solve(problem, return_all=True)
            
            if verify_solution:
                final_node = tout_result.best_path[-1] if tout_result.best_path else None
                solution_text = final_node.content if final_node else problem
                
                verification = self.analyze(
                    problem,
                    solution_text,
                    context,
                    detect_hallucination=True,
                    analyze_reasoning=True,
                )
                
                return {
                    "solution": solution_text,
                    "uncertainty": verification.overall_uncertainty,
                    "risk_level": verification.risk_level,
                    "path_length": len(tout_result.best_path),
                    "exploration_stats": tout_result.exploration_stats,
                    "verification_report": verification.to_dict(),
                }
            
            return {
                "solution": tout_result.best_path[-1].content if tout_result.best_path else None,
                "uncertainty": tout_result.final_uncertainty,
                "risk_level": self._determine_risk_level(tout_result.final_uncertainty),
                "path_length": len(tout_result.best_path),
                "exploration_stats": tout_result.exploration_stats,
            }
        
        direct_analysis = self.analyze(problem, verify_solution=True)
        return {
            "solution": problem,
            "uncertainty": direct_analysis.overall_uncertainty,
            "risk_level": direct_analysis.risk_level,
            "verification_report": direct_analysis.to_dict(),
        }
    
    def calibrate(
        self,
        training_data: List[Dict[str, Any]],
        correctness: List[bool],
    ) -> "UnifiedUncertaintyAPI":
        uncertainties = [
            self.analyze(item.get("prompt", ""), item.get("response", "")).overall_uncertainty
            for item in training_data
        ]
        
        self.calibrator.fit(uncertainties, correctness)
        
        self.calibration_data = list(zip(uncertainties, correctness))
        
        return self
    
    def get_calibration_quality(self) -> Dict[str, float]:
        if not self.calibration_data:
            return {"message": "No calibration data available"}
        
        uncertainties, correctness = zip(*self.calibration_data)
        return self.calibrator.evaluate_calibration(
            list(uncertainties), list(correctness)
        )


def create_api(
    model: Any = None,
    tokenizer: Any = None,
    **kwargs,
) -> UnifiedUncertaintyAPI:
    return UnifiedUncertaintyAPI(
        model=model,
        tokenizer=tokenizer,
        **kwargs,
    )
