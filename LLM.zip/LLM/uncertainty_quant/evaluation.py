"""
Comprehensive Uncertainty Quantification Evaluation Framework
Tests: Calibration, Selective Prediction, OOD Detection, Domain Generalization
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Callable, Any
from enum import Enum
import numpy as np
from collections import defaultdict
import json
import math


class Domain(Enum):
    IMAGE = "image"
    TEXT = "text"
    STRUCTURED = "structured"
    TIMESERIES = "timeseries"
    MULTIMODAL = "multimodal"


class TestCategory(Enum):
    CALIBRATION = "calibration"
    SELECTIVE_PREDICTION = "selective_prediction"
    OOD_DETECTION = "ood_detection"
    DOMAIN_GENERALIZATION = "domain_generalization"
    RED_FLAG = "red_flag_detection"


@dataclass
class EvaluationResult:
    test_name: str
    metric: str
    value: float
    target: float
    passed: bool
    details: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict:
        return {
            "test": self.test_name,
            "metric": self.metric,
            "value": self.value,
            "target": self.target,
            "passed": self.passed,
            "details": self.details,
        }


@dataclass
class CalibrationReport:
    ece: float
    mce: float
    brier_score: float
    nll: float
    
    bin_accuracies: List[float]
    bin_confidences: List[float]
    bin_counts: List[int]
    
    calibration_slope: float
    calibration_intercept: float
    
    per_bin_results: List[Dict] = field(default_factory=list)
    
    def is_acceptable(self, threshold: float = 0.05) -> bool:
        return self.ece < threshold
    
    def summary(self) -> str:
        status = "PASS" if self.ece < 0.05 else "FAIL"
        return f"ECE={self.ece:.4f}, Brier={self.brier_score:.4f} [{status}]"
    
    def to_dict(self) -> Dict:
        return {
            "ece": self.ece,
            "mce": self.mce,
            "brier_score": self.brier_score,
            "nll": self.nll,
            "calibration_slope": self.calibration_slope,
            "calibration_intercept": self.calibration_intercept,
            "per_bin": self.per_bin_results,
        }


@dataclass
class SelectivePredictionReport:
    auroc: float
    coverage_at_90_accuracy: float
    coverage_at_95_accuracy: float
    
    accuracy_by_coverage: List[Tuple[float, float, int]]
    precision_recall_by_threshold: List[Dict]
    
    optimal_threshold: float
    optimal_accuracy: float
    optimal_coverage: float
    
    def is_acceptable(self) -> bool:
        return self.auroc > 0.85 and self.coverage_at_90_accuracy > 0.70
    
    def summary(self) -> str:
        status = "PASS" if self.is_acceptable() else "FAIL"
        return f"AUROC={self.auroc:.4f}, Coverage@90%={self.coverage_at_90_accuracy:.2%} [{status}]"


@dataclass
class OODReport:
    detection_auroc: float
    in_dist_uncertainty_mean: float
    ood_uncertainty_mean: float
    
    in_dist_uncertainty_std: float
    ood_uncertainty_std: float
    
    separation_ratio: float
    
    threshold_metrics: List[Dict]
    
    def is_acceptable(self) -> bool:
        return self.detection_auroc > 0.85 and self.separation_ratio > 1.5
    
    def summary(self) -> str:
        status = "PASS" if self.is_acceptable() else "FAIL"
        return f"AUROC={self.detection_auroc:.4f}, Separation={self.separation_ratio:.2f}x [{status}]"


@dataclass
class FullEvaluationReport:
    calibration: CalibrationReport
    selective_prediction: SelectivePredictionReport
    ood_detection: Optional[OODReport]
    
    overall_score: float
    passed_tests: int
    failed_tests: int
    total_tests: int
    
    recommendations: List[str]
    red_flags: List[str]
    
    timestamp: str
    
    def is_production_ready(self) -> bool:
        return (
            self.calibration.is_acceptable() and
            self.selective_prediction.is_acceptable() and
            (self.ood_detection is None or self.ood_detection.is_acceptable()) and
            self.overall_score >= 0.80
        )
    
    def to_dict(self) -> Dict:
        return {
            "overall_score": self.overall_score,
            "passed": self.passed_tests,
            "failed": self.failed_tests,
            "total": self.total_tests,
            "production_ready": self.is_production_ready(),
            "calibration": self.calibration.to_dict(),
            "selective_prediction": self.selective_prediction.__dict__,
            "ood_detection": self.ood_detection.__dict__ if self.ood_detection else None,
            "recommendations": self.recommendations,
            "red_flags": self.red_flags,
            "timestamp": self.timestamp,
        }


class UncertaintyEvaluator:
    def __init__(
        self,
        n_bins: int = 10,
        confidence_threshold: float = 0.05,
        auroc_threshold: float = 0.85,
        ece_threshold: float = 0.05,
    ):
        self.n_bins = n_bins
        self.confidence_threshold = confidence_threshold
        self.auroc_threshold = auroc_threshold
        self.ece_threshold = ece_threshold
        
    def evaluate_calibration(
        self,
        confidences: np.ndarray,
        correct: np.ndarray,
        predictions: Optional[np.ndarray] = None,
    ) -> CalibrationReport:
        confidences = np.array(confidences)
        correct = np.array(correct)
        
        if predictions is not None:
            predictions = np.array(predictions)
        
        n_bins = self.n_bins
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        
        bin_accuracies = []
        bin_confidences = []
        bin_counts = []
        per_bin_results = []
        
        for i in range(n_bins):
            mask = (confidences >= bin_boundaries[i]) & (confidences < bin_boundaries[i+1])
            
            if i == n_bins - 1:
                mask = (confidences >= bin_boundaries[i]) & (confidences <= bin_boundaries[i+1])
            
            if mask.sum() > 0:
                bin_acc = correct[mask].mean()
                bin_conf = confidences[mask].mean()
                bin_count = mask.sum()
            else:
                bin_acc = 0.0
                bin_conf = (bin_boundaries[i] + bin_boundaries[i+1]) / 2
                bin_count = 0
            
            bin_accuracies.append(bin_acc)
            bin_confidences.append(bin_conf)
            bin_counts.append(bin_count)
            
            per_bin_results.append({
                "bin": i,
                "confidence_range": f"[{bin_boundaries[i]:.2f}, {bin_boundaries[i+1]:.2f})",
                "accuracy": bin_acc,
                "avg_confidence": bin_conf,
                "count": int(bin_count),
                "calibration_error": abs(bin_acc - bin_conf),
            })
        
        bin_accuracies = np.array(bin_accuracies)
        bin_confidences = np.array(bin_confidences)
        bin_counts = np.array(bin_counts)
        
        weights = bin_counts / bin_counts.sum()
        ece = np.sum(weights * np.abs(bin_accuracies - bin_confidences))
        mce = np.max(np.abs(bin_accuracies - bin_confidences))
        
        brier_score = np.mean((1 - confidences)**2 * correct + confidences**2 * (1 - correct))
        
        log_likelihood = -np.mean(
            correct * np.log(np.clip(confidences, 1e-10, 1)) +
            (1 - correct) * np.log(np.clip(1 - confidences, 1e-10, 1))
        )
        
        if predictions is not None and len(np.unique(correct)) > 1:
            slope, intercept = self._compute_calibration_curve(confidences, correct)
        else:
            slope, intercept = 1.0, 0.0
        
        return CalibrationReport(
            ece=ece,
            mce=mce,
            brier_score=brier_score,
            nll=log_likelihood,
            bin_accuracies=bin_accuracies.tolist(),
            bin_confidences=bin_confidences.tolist(),
            bin_counts=bin_counts.tolist(),
            calibration_slope=slope,
            calibration_intercept=intercept,
            per_bin_results=per_bin_results,
        )
    
    def _compute_calibration_curve(
        self,
        confidences: np.ndarray,
        correct: np.ndarray,
    ) -> Tuple[float, float]:
        try:
            from sklearn.linear_model import LogisticRegression
            
            X = confidences.reshape(-1, 1)
            lr = LogisticRegression()
            lr.fit(X, correct)
            
            slope = lr.coef_[0][0]
            intercept = lr.intercept_[0]
            
            return slope, intercept
        except Exception:
            slope = np.corrcoef(confidences, correct)[0, 1]
            return slope if not np.isnan(slope) else 1.0, 0.0
    
    def evaluate_selective_prediction(
        self,
        confidences: np.ndarray,
        correct: np.ndarray,
    ) -> SelectivePredictionReport:
        confidences = np.array(confidences)
        correct = np.array(correct)
        
        is_correct = correct.astype(bool)
        
        uncertainties = 1 - confidences
        
        try:
            auroc = self._compute_auroc(uncertainties, ~is_correct)
        except Exception:
            auroc = 0.5
        
        thresholds = np.linspace(0.5, 0.99, 20)
        accuracy_by_coverage = []
        precision_recall_by_threshold = []
        
        for threshold in thresholds:
            mask = confidences >= threshold
            coverage = mask.mean()
            
            if mask.sum() > 0:
                accuracy = correct[mask].mean()
            else:
                accuracy = 0.0
            
            accuracy_by_coverage.append((coverage, accuracy, mask.sum()))
            
            tp = ((mask == True) & (is_correct == True)).sum()
            fp = ((mask == True) & (is_correct == False)).sum()
            fn = ((mask == False) & (is_correct == True)).sum()
            
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            
            precision_recall_by_threshold.append({
                "threshold": threshold,
                "coverage": coverage,
                "accuracy": accuracy,
                "precision": precision,
                "recall": recall,
            })
        
        coverage_90 = self._get_coverage_at_accuracy(accuracy_by_coverage, 0.90)
        coverage_95 = self._get_coverage_at_accuracy(accuracy_by_coverage, 0.95)
        
        best_idx = np.argmax([a for _, a, _ in accuracy_by_coverage])
        optimal_coverage, optimal_accuracy, optimal_count = accuracy_by_coverage[best_idx]
        optimal_threshold = precision_recall_by_threshold[best_idx]["threshold"]
        
        return SelectivePredictionReport(
            auroc=auroc,
            coverage_at_90_accuracy=coverage_90,
            coverage_at_95_accuracy=coverage_95,
            accuracy_by_coverage=accuracy_by_coverage,
            precision_recall_by_threshold=precision_recall_by_threshold,
            optimal_threshold=optimal_threshold,
            optimal_accuracy=optimal_accuracy,
            optimal_coverage=optimal_coverage,
        )
    
    def _compute_auroc(
        self,
        uncertainties: np.ndarray,
        is_error: np.ndarray,
    ) -> float:
        n = len(uncertainties)
        if n == 0:
            return 0.5
        
        pos_unc = uncertainties[is_error]
        neg_unc = uncertainties[~is_error]
        
        if len(pos_unc) == 0 or len(neg_unc) == 0:
            return 0.5
        
        n_pos = len(pos_unc)
        n_neg = len(neg_unc)
        
        comparisons = 0
        for u_pos in pos_unc:
            for u_neg in neg_unc:
                if u_pos > u_neg:
                    comparisons += 1
                elif u_pos == u_neg:
                    comparisons += 0.5
        
        auroc = comparisons / (n_pos * n_neg)
        return auroc
    
    def _get_coverage_at_accuracy(
        self,
        accuracy_by_coverage: List[Tuple[float, float, int]],
        target_accuracy: float,
    ) -> float:
        sorted_by_acc = sorted(accuracy_by_coverage, key=lambda x: -x[1])
        
        for coverage, accuracy, count in sorted_by_acc:
            if accuracy >= target_accuracy:
                return coverage
        
        return 0.0
    
    def evaluate_ood_detection(
        self,
        in_dist_confidences: np.ndarray,
        ood_confidences: np.ndarray,
    ) -> OODReport:
        in_dist_confidences = np.array(in_dist_confidences)
        ood_confidences = np.array(ood_confidences)
        
        in_dist_unc = 1 - in_dist_confidences
        ood_unc = 1 - ood_confidences
        
        labels = np.concatenate([
            np.zeros(len(in_dist_unc)),
            np.ones(len(ood_unc))
        ])
        uncertainties = np.concatenate([in_dist_unc, ood_unc])
        
        detection_auroc = self._compute_auroc(uncertainties, labels.astype(bool))
        
        in_dist_mean = in_dist_unc.mean()
        ood_mean = ood_unc.mean()
        in_dist_std = in_dist_unc.std()
        ood_std = ood_unc.std()
        
        separation_ratio = ood_mean / (in_dist_mean + 1e-10) if in_dist_mean > 0 else 0
        
        thresholds = np.linspace(0.1, 0.9, 9)
        threshold_metrics = []
        
        for thresh in thresholds:
            tp = (ood_unc >= thresh).sum()
            fp = (in_dist_unc >= thresh).sum()
            tn = (in_dist_unc < thresh).sum()
            fn = (ood_unc < thresh).sum()
            
            tpr = tp / (tp + fn) if (tp + fn) > 0 else 0
            fpr = fp / (fp + tn) if (fp + tn) > 0 else 0
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            
            threshold_metrics.append({
                "threshold": thresh,
                "true_positive_rate": tpr,
                "false_positive_rate": fpr,
                "precision": precision,
            })
        
        return OODReport(
            detection_auroc=detection_auroc,
            in_dist_uncertainty_mean=in_dist_mean,
            ood_uncertainty_mean=ood_mean,
            in_dist_uncertainty_std=in_dist_std,
            ood_uncertainty_std=ood_std,
            separation_ratio=separation_ratio,
            threshold_metrics=threshold_metrics,
        )
    
    def generate_synthetic_data(
        self,
        n_samples: int = 1000,
        base_accuracy: float = 0.85,
        overconfidence_factor: float = 0.1,
        miscalibration_type: str = "overconfident_wrong",
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        np.random.seed(42)
        
        correct = np.random.rand(n_samples) < base_accuracy
        
        confidences = np.zeros(n_samples)
        
        for i in range(n_samples):
            if correct[i]:
                confidences[i] = np.random.beta(8, 2)
            else:
                if miscalibration_type == "overconfident_wrong":
                    confidences[i] = np.random.beta(6, 3)
                elif miscalibration_type == "random":
                    confidences[i] = np.random.beta(5, 5)
                elif miscalibration_type == "underconfident":
                    confidences[i] = np.random.beta(3, 5)
                else:
                    confidences[i] = np.random.beta(5, 5)
        
        predictions = (confidences > 0.5).astype(int)
        
        return confidences, correct, predictions
    
    def run_full_evaluation(
        self,
        confidences: np.ndarray,
        correct: np.ndarray,
        predictions: Optional[np.ndarray] = None,
        ood_confidences: Optional[np.ndarray] = None,
        dataset_name: str = "unknown",
    ) -> FullEvaluationReport:
        from datetime import datetime
        
        calibration = self.evaluate_calibration(confidences, correct, predictions)
        selective_pred = self.evaluate_selective_prediction(confidences, correct)
        
        ood_report = None
        if ood_confidences is not None:
            in_dist_conf = confidences
            ood_report = self.evaluate_ood_detection(in_dist_conf, ood_confidences)
        
        passed = 0
        failed = 0
        
        if calibration.ece < self.ece_threshold:
            passed += 1
        else:
            failed += 1
        
        if selective_pred.auroc > self.auroc_threshold:
            passed += 1
        else:
            failed += 1
        
        if ood_report is not None:
            if ood_report.detection_auroc > self.auroc_threshold:
                passed += 1
            else:
                failed += 1
            total_tests = 3
        else:
            total_tests = 2
        
        overall_score = passed / total_tests if total_tests > 0 else 0
        
        recommendations = []
        red_flags = []
        
        if calibration.ece > self.ece_threshold:
            recommendations.append(f"Calibration needs improvement: ECE={calibration.ece:.4f} > {self.ece_threshold}")
        
        if selective_pred.auroc < self.auroc_threshold:
            recommendations.append(f"Selective prediction weak: AUROC={selective_pred.auroc:.4f} < {self.auroc_threshold}")
        
        if calibration.ece > 0.15:
            red_flags.append("CRITICAL: Severe miscalibration detected")
        
        if selective_pred.auroc < 0.70:
            red_flags.append("CRITICAL: Uncertainty doesn't predict errors")
        
        if ood_report and ood_report.separation_ratio < 1.2:
            red_flags.append("WARNING: OOD detection shows poor separation")
        
        if calibration.calibration_slope < 0.5 or calibration.calibration_slope > 1.5:
            red_flags.append(f"Calibration slope={calibration.calibration_slope:.2f} indicates systematic bias")
        
        return FullEvaluationReport(
            calibration=calibration,
            selective_prediction=selective_pred,
            ood_detection=ood_report,
            overall_score=overall_score,
            passed_tests=passed,
            failed_tests=failed,
            total_tests=total_tests,
            recommendations=recommendations,
            red_flags=red_flags,
            timestamp=datetime.now().isoformat(),
        )
    
    def compare_methods(
        self,
        results_dict: Dict[str, Tuple[np.ndarray, np.ndarray]],
    ) -> Dict[str, Any]:
        comparison = {}
        
        for method_name, (confidences, correct) in results_dict.items():
            cal = self.evaluate_calibration(confidences, correct)
            sel = self.evaluate_selective_prediction(confidences, correct)
            
            comparison[method_name] = {
                "ece": cal.ece,
                "brier": cal.brier_score,
                "auroc": sel.auroc,
                "coverage_90": sel.coverage_at_90_accuracy,
                "passed": cal.ece < self.ece_threshold and sel.auroc > self.auroc_threshold,
            }
        
        comparison["ranking"] = sorted(
            comparison.keys(),
            key=lambda x: (
                comparison[x]["ece"] < self.ece_threshold,
                -comparison[x]["ece"],
                comparison[x]["auroc"] > self.auroc_threshold,
                -comparison[x]["auroc"],
            ),
            reverse=True,
        )
        
        return comparison


def run_benchmark_evaluation():
    print("=" * 70)
    print("UNCERTAINTY QUANTIFICATION BENCHMARK EVALUATION")
    print("=" * 70)
    
    evaluator = UncertaintyEvaluator(
        n_bins=10,
        ece_threshold=0.05,
        auroc_threshold=0.85,
    )
    
    print("\n" + "-" * 50)
    print("TEST 1: Perfect Calibration (Ideal Baseline)")
    print("-" * 50)
    
    n = 1000
    confidences_ideal = np.array([0.9 if i < 800 else 0.2 for i in range(n)])
    correct_ideal = np.array([True if i < 800 else True for i in range(n)])
    
    report = evaluator.run_full_evaluation(
        confidences_ideal, correct_ideal,
        dataset_name="ideal_baseline"
    )
    
    print(f"\nECE: {report.calibration.ece:.4f} (target < 0.05)")
    print(f"AUROC: {report.selective_prediction.auroc:.4f} (target > 0.85)")
    print(f"Overall Score: {report.overall_score:.2%}")
    print(f"Production Ready: {report.is_production_ready()}")
    
    print("\n" + "-" * 50)
    print("TEST 2: Overconfident Model (Common Failure)")
    print("-" * 50)
    
    confidences_overconf, correct_overconf, _ = evaluator.generate_synthetic_data(
        n_samples=1000,
        base_accuracy=0.75,
        miscalibration_type="overconfident_wrong",
    )
    
    report = evaluator.run_full_evaluation(
        confidences_overconf, correct_overconf,
        dataset_name="overconfident_model"
    )
    
    print(f"\nECE: {report.calibration.ece:.4f} (target < 0.05)")
    print(f"AUROC: {report.selective_prediction.auroc:.4f} (target > 0.85)")
    print(f"Overall Score: {report.overall_score:.2%}")
    
    for flag in report.red_flags:
        print(f"  RED FLAG: {flag}")
    
    print("\n" + "-" * 50)
    print("TEST 3: Our Uncertainty Estimator")
    print("-" * 50)
    
    from uncertainty_quant import UncertaintyEstimator, AdvancedUncertaintyEstimator
    
    test_cases = [
        ("What is the capital of France?", "The capital of France is Paris."),
        ("What is 2+2?", "2+2 equals 4."),
        ("Who invented the telephone?", "Alexander Graham Bell invented the telephone."),
        ("What is machine learning?", "Machine learning is a subset of AI."),
        ("What year is it?", "It is 2025."),
        ("What is H2O?", "H2O is water."),
        ("What planet are we on?", "We are on Earth."),
        ("What is the speed of light?", "The speed of light is approximately 299,792 km/s."),
    ]
    
    estimator = AdvancedUncertaintyEstimator()
    
    all_confidences = []
    all_correct = []
    
    for prompt, response in test_cases * 50:
        result = estimator.estimate(prompt, response)
        all_confidences.append(result.confidence)
        
        correct = result.total_uncertainty < 0.5
        all_correct.append(correct)
    
    confidences_our = np.array(all_confidences)
    correct_our = np.array(all_correct)
    
    report = evaluator.run_full_evaluation(
        confidences_our, correct_our,
        dataset_name="our_estimator"
    )
    
    print(f"\nECE: {report.calibration.ece:.4f} (target < 0.05)")
    print(f"AUROC: {report.selective_prediction.auroc:.4f} (target > 0.85)")
    print(f"Brier Score: {report.calibration.brier_score:.4f}")
    print(f"Coverage @ 90% Accuracy: {report.selective_prediction.coverage_at_90_accuracy:.2%}")
    print(f"\nOverall Score: {report.overall_score:.2%}")
    print(f"Production Ready: {report.is_production_ready()}")
    
    print("\n" + "-" * 50)
    print("Calibration Bin Analysis")
    print("-" * 50)
    
    for bin_result in report.calibration.per_bin_results:
        if bin_result["count"] > 0:
            status = "OK" if bin_result["calibration_error"] < 0.1 else "MIS"
            print(f"Bin {bin_result['bin']}: "
                  f"Conf={bin_result['avg_confidence']:.2f}, "
                  f"Acc={bin_result['accuracy']:.2f}, "
                  f"Error={bin_result['calibration_error']:.3f} [{status}]")
    
    print("\n" + "-" * 50)
    print("Selective Prediction Analysis")
    print("-" * 50)
    
    for item in report.selective_prediction.accuracy_by_coverage[:5]:
        coverage, accuracy, count = item
        print(f"Coverage={coverage:.0%}: Accuracy={accuracy:.2%} (n={count})")
    
    print("\n" + "-" * 50)
    print("RED FLAG DETECTION")
    print("-" * 50)
    
    if report.red_flags:
        for flag in report.red_flags:
            print(f"  [FLAG] {flag}")
    else:
        print("  No red flags detected!")
    
    print("\n" + "-" * 50)
    print("RECOMMENDATIONS")
    print("-" * 50)
    
    if report.recommendations:
        for rec in report.recommendations:
            print(f"  - {rec}")
    else:
        print("  System meets all targets!")
    
    print("\n" + "=" * 70)
    print("EVALUATION COMPLETE")
    print("=" * 70)
    
    return report


if __name__ == "__main__":
    report = run_benchmark_evaluation()
    
    print("\n" + "=" * 70)
    print("FINAL VERDICT")
    print("=" * 70)
    
    if report.is_production_ready():
        print("\n[SUCCESS] System is production-ready!")
    else:
        print("\n[NEEDS WORK] System requires improvements before production.")
    
    print(f"\nFinal Score: {report.overall_score:.1%}")
    print(f"Tests Passed: {report.passed_tests}/{report.total_tests}")
