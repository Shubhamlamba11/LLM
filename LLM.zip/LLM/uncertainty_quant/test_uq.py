from uncertainty_quant import (
    UncertaintyEstimator,
    HallucinationDetector,
    AdvancedUncertaintyEstimator,
    ProcessRewardVerifier,
    TreeOfUncertainThoughts,
)

def test_basic():
    print("=== Basic Uncertainty ===")
    estimator = UncertaintyEstimator()
    result = estimator.estimate(
        "What is AI?",
        "AI stands for Artificial Intelligence."
    )
    print(f"Uncertainty: {result.total_uncertainty:.3f}")
    print(f"Risk: {result.get_risk_level()}")

def test_advanced():
    print("\n=== Advanced Uncertainty ===")
    estimator = AdvancedUncertaintyEstimator()
    result = estimator.estimate(
        "What is machine learning?",
        "Machine learning is a subset of AI that enables systems to learn from data."
    )
    print(f"Uncertainty: {result.total_uncertainty:.3f}")
    print(f"Methods: {list(result.method_scores.keys())}")

def test_reasoning():
    print("\n=== Process Reward Verifier ===")
    verifier = ProcessRewardVerifier()
    chain = """
Step 1: Add 10 + 5
Step 2: 10 + 5 = 15
Step 3: Therefore, 10 + 5 = 15
"""
    result = verifier.verify("What is 10 + 5?", chain)
    print(f"Verdict: {result.get_verdict()}")
    print(f"Errors: {result.total_errors}")

def test_tout():
    print("\n=== Tree of Uncertain Thoughts ===")
    tout = TreeOfUncertainThoughts(max_depth=4)
    
    def gen(content, k=3):
        return [f"{content} - approach {i}" for i in range(k)]
    
    result = tout.solve("What is 2+2?", generate_fn=gen)
    print(f"Result: {result.get_summary()}")

if __name__ == "__main__":
    test_basic()
    test_advanced()
    test_reasoning()
    test_tout()
    print("\n[All tests passed!]")