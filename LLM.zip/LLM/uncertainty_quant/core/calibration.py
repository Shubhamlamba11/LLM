"""
Calibration Module for Uncertainty Quantification
Implements temperature scaling, isotonic regression, and cross-domain calibration
"""

from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Optional, Callable, Tuple
import numpy as np
from scipy.optimize import minimize_scalar
from sklearn.isotonic import IsotonicRegression


class CalibrationMethod(Enum):
    TEMPERATURE_SCALING = "temperature_scaling"
    ISOTONIC_REGRESSION = "isotonic_regression"
    PLATT_SCALING = "platt_scaling"
    VENN_ABERS = "venn_abers"
    HISTOGRAM_BINNING = "histogram_binning"
    ADAPTIVE = "adaptive"


@dataclass
class CalibrationResult:
    calibrated_uncertainty: float
    calibration_factor: float
    expected_accuracy: float
    calibration_error: float
    confidence_interval: Tuple[float, float]
    method: CalibrationMethod
    

class Calibrator:
    def __init__(
        self,
        method: CalibrationMethod = CalibrationMethod.TEMPERATURE_SCALING,
        n_bins: int = 15,
    ):
        self.method = method
        self.n_bins = n_bins
        self.temperature = 1.0
        self.isotonic = None
        self.platt_params = None
        self.calibration_history: List[Dict] = []
        
    def fit(
        self,
        uncertainties: List[float],
        correctness: List[bool],
    ) -> "Calibrator":
        if len(uncertainties) != len(correctness):
            raise ValueError("Uncertainty and correctness lists must have same length")
        
        self.calibration_history.append({
            "n_samples": len(uncertainties),
            "accuracy": sum(correctness) / len(correctness) if correctness else 0,
        })
        
        if self.method == CalibrationMethod.TEMPERATURE_SCALING:
            self._fit_temperature_scaling(uncertainties, correctness)
        elif self.method == CalibrationMethod.ISOTONIC_REGRESSION:
            self._fit_isotonic(uncertainties, correctness)
        elif self.method == CalibrationMethod.PLATT_SCALING:
            self._fit_platt(uncertainties, correctness)
        elif self.method == CalibrationMethod.ADAPTIVE:
            self._fit_adaptive(uncertainties, correctness)
            
        return self
    
    def calibrate(
        self,
        uncertainty: float,
        return_all: bool = False,
    ) -> CalibrationResult:
        if self.method == CalibrationMethod.TEMPERATURE_SCALING:
            calibrated = self._apply_temperature_scaling(uncertainty)
        elif self.method == CalibrationMethod.ISOTONIC_REGRESSION:
            calibrated = self._apply_isotonic(uncertainty)
        elif self.method == CalibrationMethod.PLATT_SCALING:
            calibrated = self._apply_platt(uncertainty)
        elif self.method == CalibrationMethod.ADAPTIVE:
            calibrated = self._apply_adaptive(uncertainty)
        else:
            calibrated = uncertainty
            
        expected_acc = self._estimate_expected_accuracy(calibrated)
        cal_error = self._calibration_error(uncertainty, calibrated)
        
        result = CalibrationResult(
            calibrated_uncertainty=calibrated,
            calibration_factor=self.temperature if hasattr(self, 'temperature') else 1.0,
            expected_accuracy=expected_acc,
            calibration_error=cal_error,
            confidence_interval=(max(0, calibrated - 0.1), min(1, calibrated + 0.1)),
            method=self.method,
        )
        
        if return_all:
            return result
        return result.calibrated_uncertainty
    
    def calibrate_batch(
        self,
        uncertainties: List[float],
    ) -> List[float]:
        return [self.calibrate(u) if isinstance(u, float) else self.calibrate(u) 
                for u in uncertainties]
    
    def _fit_temperature_scaling(
        self,
        uncertainties: List[float],
        correctness: List[bool],
    ):
        def negative_log_likelihood(temp):
            if temp <= 0.01:
                return float('inf')
            scaled = [min(max(u ** temp, 1e-10), 1-1e-10) for u in uncertainties]
            nll = 0
            for u, c in zip(scaled, correctness):
                if c:
                    nll -= math.log(u)
                else:
                    nll -= math.log(1 - u)
            return nll
        
        try:
            from scipy.optimize import minimize_scalar
            result = minimize_scalar(negative_log_likelihood, bounds=(0.1, 10.0), method='bounded')
            self.temperature = result.x
        except Exception:
            self.temperature = 1.0
    
    def _apply_temperature_scaling(self, uncertainty: float) -> float:
        return uncertainty ** self.temperature
    
    def _fit_isotonic(
        self,
        uncertainties: List[float],
        correctness: List[bool],
    ):
        self.isotonic = IsotonicRegression(y_min=0, y_max=1, out_of_bounds='clip')
        X = np.array(uncertainties).reshape(-1, 1)
        y = np.array(correctness, dtype=float)
        self.isotonic.fit(X.ravel(), y)
    
    def _apply_isotonic(self, uncertainty: float) -> float:
        if self.isotonic is None:
            return uncertainty
        return float(self.isotonic.predict([uncertainty])[0])
    
    def _fit_platt(
        self,
        uncertainties: List[float],
        correctness: List[bool],
    ):
        import numpy as np
        
        X = np.array([-math.log(max(u, 1e-10) / max(1-u, 1e-10)) for u in uncertainties])
        y = np.array(correctness, dtype=float)
        
        try:
            from sklearn.linear_model import LogisticRegression
            self.platt_model = LogisticRegression()
            self.platt_model.fit(X.reshape(-1, 1), y)
        except Exception:
            self.platt_model = None
            slope = 1.0
            intercept = 0.0
            for i, (xi, yi) in enumerate(zip(X, y)):
                slope += (yi - 0.5) * (xi - np.mean(X))
                intercept += (yi - 0.5)
            slope /= len(X) + 1e-10
            intercept /= len(X) + 1e-10
            self.platt_params = (slope, intercept)
    
    def _apply_platt(self, uncertainty: float) -> float:
        if hasattr(self, 'platt_model') and self.platt_model is not None:
            from scipy.special import expit
            logit = -math.log(max(uncertainty, 1e-10) / max(1-uncertainty, 1e-10))
            return float(self.platt_model.predict_proba([[logit]])[0, 1])
        
        if self.platt_params:
            slope, intercept = self.platt_params
            logit = -math.log(max(uncertainty, 1e-10) / max(1-uncertainty, 1e-10))
            return 1 / (1 + math.exp(-(slope * logit + intercept)))
        
        return uncertainty
    
    def _fit_adaptive(
        self,
        uncertainties: List[float],
        correctness: List[bool],
    ):
        self.histogram_bins = self._create_calibration_bins(uncertainties, correctness)
        self._fit_temperature_scaling(uncertainties, correctness)
    
    def _apply_adaptive(self, uncertainty: float) -> float:
        temp_scaled = self._apply_temperature_scaling(uncertainty)
        
        for low, high, expected_acc in self.histogram_bins:
            if low <= uncertainty <= high:
                combined = 0.7 * temp_scaled + 0.3 * (1 - expected_acc)
                return combined
        
        return temp_scaled
    
    def _create_calibration_bins(
        self,
        uncertainties: List[float],
        correctness: List[bool],
    ) -> List[Tuple[float, float, float]]:
        sorted_pairs = sorted(zip(uncertainties, correctness), key=lambda x: x[0])
        n = len(sorted_pairs)
        bin_size = max(1, n // self.n_bins)
        
        bins = []
        for i in range(0, n, bin_size):
            chunk = sorted_pairs[i:i+bin_size]
            if chunk:
                lows = [x[0] for x in chunk]
                accs = [x[1] for x in chunk]
                bins.append((
                    min(lows),
                    max(lows),
                    sum(accs) / len(accs) if accs else 0.5
                ))
        
        return bins
    
    def _estimate_expected_accuracy(self, uncertainty: float) -> float:
        if self.method == CalibrationMethod.TEMPERATURE_SCALING:
            return 1 - uncertainty ** self.temperature
        return 1 - uncertainty
    
    def _calibration_error(self, original: float, calibrated: float) -> float:
        return abs(original - calibrated)
    
    def evaluate_calibration(
        self,
        uncertainties: List[float],
        correctness: List[bool],
    ) -> Dict[str, float]:
        if len(uncertainties) != len(correctness):
            raise ValueError("Length mismatch")
        
        n = len(uncertainties)
        calibrated = [self.calibrate(u) for u in uncertainties]
        
        ece = self._expected_calibration_error(calibrated, correctness)
        mce = self._max_calibration_error(calibrated, correctness)
        
        return {
            "ECE": ece,
            "MCE": mce,
            "n_samples": n,
            "accuracy": sum(correctness) / n if correctness else 0,
        }
    
    def _expected_calibration_error(
        self,
        calibrated: List[float],
        correctness: List[bool],
        n_bins: int = 10,
    ) -> float:
        bins = np.linspace(0, 1, n_bins + 1)
        ece = 0.0
        
        for i in range(n_bins):
            mask = [(bins[i] <= c < bins[i+1]) for c in calibrated]
            if not any(mask):
                continue
            bin_acc = sum(correctness[j] for j in range(len(mask)) if mask[j]) / sum(mask)
            bin_conf = np.mean([calibrated[j] for j in range(len(mask)) if mask[j]])
            ece += sum(mask) / len(calibrated) * abs(bin_conf - bin_acc)
        
        return ece
    
    def _max_calibration_error(
        self,
        calibrated: List[float],
        correctness: List[bool],
    ) -> float:
        bins = np.linspace(0, 1, self.n_bins + 1)
        max_error = 0.0
        
        for i in range(len(bins) - 1):
            mask = [(bins[i] <= c < bins[i+1]) for c in calibrated]
            if not any(mask):
                continue
            bin_acc = sum(correctness[j] for j in range(len(mask)) if mask[j]) / sum(mask)
            bin_conf = np.mean([calibrated[j] for j in range(len(mask)) if mask[j]])
            max_error = max(max_error, abs(bin_conf - bin_acc))
        
        return max_error
    
    def transfer_calibration(
        self,
        source_domain_uncertainties: List[float],
        source_domain_correctness: List[bool],
        target_domain_calibrator: "Calibrator",
    ) -> "Calibrator":
        calibrated_source = [target_domain_calibrator.calibrate(u) for u in source_domain_uncertainties]
        self._fit_temperature_scaling(calibrated_source, source_domain_correctness)
        return self
    
    def to_dict(self) -> Dict:
        return {
            "method": self.method.value,
            "temperature": self.temperature,
            "n_bins": self.n_bins,
            "calibration_history": self.calibration_history,
        }


try:
    import math
except ImportError:
    import math
