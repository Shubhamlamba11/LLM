"""
Core Uncertainty Estimation Module
Implements multiple UQ methods for LLMs: TPU, Semantic Entropy, Verbalized, Self-Consistency
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List, Dict, Any, Callable, Union
import math
import numpy as np


class UncertaintyType(Enum):
    TOKEN_PROBABILITY = "token_probability"
    SEMANTIC_ENTROPY = "semantic_entropy"
    VERBALIZED = "verbalized"
    SELF_CONSISTENCY = "self_consistency"
    CROSS_MODEL = "cross_model"
    ENSEMBLE = "ensemble"
    COMBINED = "combined"


@dataclass
class UncertaintyResult:
    total_uncertainty: float
    epistemic_uncertainty: Optional[float] = None
    aleatoric_uncertainty: Optional[float] = None
    confidence: float = 1.0
    uncertainty_type: UncertaintyType = UncertaintyType.COMBINED
    method_scores: Dict[str, float] = field(default_factory=dict)
    step_scores: Optional[List[Dict[str, Any]]] = None
    reasoning_chain: Optional[List[str]] = None
    calibration_quality: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def is_high_uncertainty(self, threshold: float = 0.5) -> bool:
        return self.total_uncertainty > threshold
    
    def get_risk_level(self) -> str:
        if self.total_uncertainty < 0.2:
            return "LOW"
        elif self.total_uncertainty < 0.5:
            return "MEDIUM"
        elif self.total_uncertainty < 0.75:
            return "HIGH"
        else:
            return "CRITICAL"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_uncertainty": self.total_uncertainty,
            "confidence": self.confidence,
            "risk_level": self.get_risk_level(),
            "uncertainty_type": self.uncertainty_type.value,
            "epistemic": self.epistemic_uncertainty,
            "aleatoric": self.aleatoric_uncertainty,
            "method_scores": self.method_scores,
            "calibration_quality": self.calibration_quality,
        }


class UncertaintyEstimator:
    def __init__(
        self,
        model: Any = None,
        tokenizer: Any = None,
        device: str = "cpu",
        temperature: float = 0.7,
        num_samples: int = 5,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.temperature = temperature
        self.num_samples = num_samples
        
    def estimate(
        self,
        prompt: str,
        response: Optional[str] = None,
        methods: List[UncertaintyType] = None,
        return_all: bool = False,
    ) -> UncertaintyResult:
        if methods is None:
            methods = [UncertaintyType.COMBINED]
            
        scores = {}
        total = 0.0
        weights = {}
        
        for method in methods:
            if method == UncertaintyType.TOKEN_PROBABILITY:
                score = self._token_probability_uncertainty(prompt, response)
                scores["tpu"] = score
                weights["tpu"] = 0.2
            elif method == UncertaintyType.SEMANTIC_ENTROPY:
                score = self._semantic_entropy(prompt, response)
                scores["semantic"] = score
                weights["semantic"] = 0.3
            elif method == UncertaintyType.VERBALIZED:
                score = self._verbalized_uncertainty(prompt, response)
                scores["verbalized"] = score
                weights["verbalized"] = 0.25
            elif method == UncertaintyType.SELF_CONSISTENCY:
                score = self._self_consistency(prompt, response)
                scores["self_consistency"] = score
                weights["self_consistency"] = 0.25
            elif method == UncertaintyType.COMBINED:
                combined = self._combined_uncertainty(prompt, response)
                return combined
                
        if weights:
            total = sum(scores[k] * weights.get(k, 1/len(scores)) for k in scores)
            total /= sum(weights.values())
            
        return UncertaintyResult(
            total_uncertainty=total,
            confidence=1.0 - total,
            uncertainty_type=methods[0] if len(methods) == 1 else UncertaintyType.COMBINED,
            method_scores=scores,
        )
    
    def _token_probability_uncertainty(
        self, prompt: str, response: Optional[str] = None
    ) -> float:
        if self.model is None or self.tokenizer is None:
            return self._estimate_tpu_heuristic(prompt, response)
        
        try:
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
            response_text = response or ""
            response_ids = self.tokenizer(response_text, return_tensors="pt")["input_ids"]
            
            log_probs = []
            with torch.no_grad():
                for i in range(min(len(response_ids[0]) - 1, 50)):
                    input_ids = torch.cat([inputs["input_ids"], response_ids[0][:i+1:i+1]], dim=-1)
                    outputs = self.model(input_ids)
                    probs = torch.softmax(outputs.logits[0, -1], dim=-1)
                    token_prob = probs[response_ids[0][i+1]].item()
                    log_probs.append(max(token_prob, 1e-10))
            
            if not log_probs:
                return 0.5
            
            entropy = -np.mean([math.log(p) for p in log_probs])
            max_entropy = math.log(len(log_probs))
            return min(entropy / max_entropy, 1.0) if max_entropy > 0 else 0.5
            
        except Exception:
            return self._estimate_tpu_heuristic(prompt, response)
    
    def _estimate_tpu_heuristic(
        self, prompt: str, response: Optional[str] = None
    ) -> float:
        text = response or prompt
        uncertainty_indicators = [
            "uncertain", "maybe", "possibly", "might", "could", "probably",
            "perhaps", "not sure", "unclear", "ambiguous", "depends",
            "difficult to say", "hard to determine", "I'm not certain"
        ]
        for indicator in uncertainty_indicators:
            if indicator.lower() in text.lower():
                return 0.2
        
        question_marks = text.count("?")
        if question_marks > 2:
            return 0.3
        
        return 0.5
    
    def _semantic_entropy(
        self, prompt: str, response: Optional[str] = None
    ) -> float:
        if self.model is None or self.tokenizer is None:
            return 0.5
        
        try:
            responses = self._sample_responses(prompt, self.num_samples)
            if len(responses) < 2:
                return 0.5
            
            unique_responses = self._cluster_semantic_similar(responses)
            n_unique = len(unique_responses)
            n_total = len(responses)
            
            if n_unique == 1:
                return 0.1
            
            semantic_entropy = -(n_unique/n_total) * math.log(n_unique/n_total + 1e-10)
            max_entropy = math.log(n_total + 1)
            return min(semantic_entropy / max_entropy * 2, 1.0)
            
        except Exception:
            return 0.5
    
    def _verbalized_uncertainty(
        self, prompt: str, response: Optional[str] = None
    ) -> float:
        if response is None:
            return 0.5
            
        uncertainty_words = {
            "certain": 0.0, "sure": 0.0, "definitely": 0.0, "clearly": 0.0,
            "obviously": 0.0, "undoubtedly": 0.0, "confident": 0.1,
            "probably": 0.3, "likely": 0.3, "possibly": 0.4, "maybe": 0.5,
            "perhaps": 0.5, "might": 0.4, "could": 0.4, "uncertain": 0.7,
            "not sure": 0.6, "unclear": 0.7, "ambiguous": 0.8, "unknown": 0.8
        }
        
        text_lower = response.lower()
        scores = []
        
        for word, score in uncertainty_words.items():
            if word in text_lower:
                scores.append(score)
        
        if not scores:
            if any(x in text_lower for x in ["i think", "i believe", "my guess"]):
                return 0.4
            return 0.6
        
        return min(np.mean(scores) + 0.1, 1.0)
    
    def _self_consistency(
        self, prompt: str, response: Optional[str] = None
    ) -> float:
        if self.model is None or self.tokenizer is None:
            return 0.5
            
        try:
            samples = self._sample_responses(prompt, self.num_samples)
            if len(samples) < 2:
                return 0.5
            
            if response:
                samples.append(response)
            
            consistency = self._calculate_semantic_overlap(samples)
            return 1.0 - consistency
            
        except Exception:
            return 0.5
    
    def _combined_uncertainty(
        self, prompt: str, response: Optional[str] = None
    ) -> UncertaintyResult:
        tpu = self._token_probability_uncertainty(prompt, response)
        semantic = self._semantic_entropy(prompt, response)
        verbalized = self._verbalized_uncertainty(prompt, response)
        consistency = self._self_consistency(prompt, response)
        
        weights = {"tpu": 0.2, "semantic": 0.3, "verbalized": 0.25, "consistency": 0.25}
        
        epistemic = (semantic * 0.5 + consistency * 0.5)
        aleatoric = verbalized * 0.7 + tpu * 0.3
        
        total = (
            tpu * weights["tpu"] +
            semantic * weights["semantic"] +
            verbalized * weights["verbalized"] +
            consistency * weights["consistency"]
        )
        
        calibration_quality = self._estimate_calibration_quality(
            tpu, semantic, verbalized, consistency
        )
        
        return UncertaintyResult(
            total_uncertainty=total,
            epistemic_uncertainty=epistemic,
            aleatoric_uncertainty=aleatoric,
            confidence=1.0 - total,
            uncertainty_type=UncertaintyType.COMBINED,
            method_scores={
                "token_probability": tpu,
                "semantic_entropy": semantic,
                "verbalized": verbalized,
                "self_consistency": consistency,
            },
            calibration_quality=calibration_quality,
            metadata={"weights": weights},
        )
    
    def _estimate_calibration_quality(
        self, tpu: float, semantic: float, verbalized: float, consistency: float
    ) -> float:
        expected_high = verbalized > 0.5
        actual_high = (semantic + consistency) / 2 > 0.5
        
        if expected_high == actual_high:
            return 0.8
        elif abs(verbalized - (semantic + consistency) / 2) < 0.2:
            return 0.6
        else:
            return 0.3
    
    def _sample_responses(self, prompt: str, n: int) -> List[str]:
        if self.model is None or self.tokenizer is None:
            return [f"Sample {i}" for i in range(n)]
        
        try:
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
            samples = []
            
            for _ in range(n):
                with torch.no_grad():
                    outputs = self.model.generate(
                        inputs["input_ids"],
                        max_new_tokens=100,
                        temperature=self.temperature,
                        do_sample=True,
                        pad_token_id=self.tokenizer.pad_token_id,
                    )
                text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
                samples.append(text)
            
            return samples
            
        except Exception:
            return [f"Sample {i}" for i in range(n)]
    
    def _cluster_semantic_similar(self, responses: List[str]) -> List[str]:
        if len(responses) <= 1:
            return responses
        
        clusters = []
        for r in responses:
            found = False
            for c in clusters:
                if self._simple_similarity(r, c[0]) > 0.85:
                    c.append(r)
                    found = True
                    break
            if not found:
                clusters.append([r])
        
        return [c[0] for c in clusters]
    
    def _simple_similarity(self, text1: str, text2: str) -> float:
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        if not words1 or not words2:
            return 0.0
        intersection = words1 & words2
        union = words1 | words2
        return len(intersection) / len(union)
    
    def _calculate_semantic_overlap(self, responses: List[str]) -> float:
        if len(responses) < 2:
            return 1.0
        
        overlaps = []
        base = responses[0]
        for r in responses[1:]:
            overlaps.append(self._simple_similarity(base, r))
        
        return np.mean(overlaps)


try:
    import torch
except ImportError:
    torch = None
