"""
Red Flag Detection - Tests that prove the system DOESN'T work
These are the failure modes your system must avoid
"""

from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
import numpy as np
from enum import Enum


class RedFlagType(Enum):
    OVERCONFIDENT_WRONG = "overconfident_wrong"
    UNCERTAINTY_NO_CORRELATION = "uncertainty_no_correlation"
    TRIVIAL_UNCERTAINTY = "trivial_uncertainty"
    EASY_ONLY = "easy_only"
    OOD_FAILURE = "ood_failure"


@dataclass
class RedFlagResult:
    flag_type: RedFlagType
    detected: bool
    severity: str
    description: str
    evidence: Dict
    recommendation: str


class RedFlagDetector:
    def __init__(
        self,
        ece_threshold: float = 0.10,
        correlation_threshold: float = 0.3,
        ood_separation_threshold: float = 1.2,
    ):
        self.ece_threshold = ece_threshold
        self.correlation_threshold = correlation_threshold
        self.ood_separation_threshold = ood_separation_threshold
        
    def check_all_flags(
        self,
        confidences: np.ndarray,
        correct: np.ndarray,
        ood_confidences: Optional[np.ndarray] = None,
        baseline_confidences: Optional[np.ndarray] = None,
        easy_accuracy: Optional[float] = None,
        hard_accuracy: Optional[float] = None,
    ) -> List[RedFlagResult]:
        flags = []
        
        flags.append(self.check_overconfidence(confidences, correct))
        flags.append(self.check_uncertainty_correlation(confidences, correct))
        flags.append(self.check_triviality(confidences, baseline_confidences))
        flags.append(self.check_easy_only(easy_accuracy, hard_accuracy))
        
        if ood_confidences is not None:
            flags.append(self.check_ood_detection(confidences, ood_confidences))
        
        return [f for f in flags if f is not None]
    
    def check_overconfidence(
        self,
        confidences: np.ndarray,
        correct: np.ndarray,
    ) -> RedFlagResult:
        wrong_mask = ~correct
        correct_mask = correct
        
        if wrong_mask.sum() == 0 or correct_mask.sum() == 0:
            return None
        
        avg_confidence_wrong = confidences[wrong_mask].mean()
        avg_confidence_correct = confidences[correct_mask].mean()
        
        is_overconfident = avg_confidence_wrong > avg_confidence_correct
        
        high_confidence_wrong = (confidences[wrong_mask] > 0.8).mean()
        
        severity = "CRITICAL" if is_overconfidence > 0.2 else "WARNING" if is_overconfident else "OK"
        
        detected = is_overconfident or high_confidence_wrong > 0.5
        
        return RedFlagResult(
            flag_type=RedFlagType.OVERCONFIDENT_WRONG,
            detected=detected,
            severity=severity,
            description="Model is confident even when wrong",
            evidence={
                "avg_confidence_when_correct": avg_confidence_correct,
                "avg_confidence_when_wrong": avg_confidence_wrong,
                "high_confidence_wrong_pct": high_confidence_wrong,
                "confidence_gap": avg_confidence_wrong - avg_confidence_correct,
            },
            recommendation=(
                "Use calibration (temperature scaling, isotonic regression) "
                "or ensemble methods to reduce overconfidence"
            ) if detected else "No action needed",
        )
    
    def check_uncertainty_correlation(
        self,
        confidences: np.ndarray,
        correct: np.ndarray,
    ) -> RedFlagResult:
        uncertainties = 1 - confidences
        
        n = len(confidences)
        if n < 10:
            return None
        
        correlation = np.corrcoef(uncertainties, correct.astype(float))[0, 1]
        
        if np.isnan(correlation):
            correlation = 0.0
        
        low_correlation = abs(correlation) < self.correlation_threshold
        
        auroc = self._compute_auroc_simple(uncertainties, ~correct)
        low_auroc = auroc < 0.70
        
        detected = low_correlation or low_auroc
        
        severity = "CRITICAL" if low_auroc else "WARNING" if low_correlation else "OK"
        
        return RedFlagResult(
            flag_type=RedFlagType.UNCERTAINTY_NO_CORRELATION,
            detected=detected,
            severity=severity,
            description="Uncertainty doesn't predict errors",
            evidence={
                "correlation": correlation,
                "auroc": auroc,
                "correlation_threshold": self.correlation_threshold,
            },
            recommendation=(
                "Your uncertainty estimates are not informative. "
                "Consider using ensemble methods or training with proper uncertainty objectives"
            ) if detected else "Uncertainty correlates well with errors",
        )
    
    def check_triviality(
        self,
        confidences: np.ndarray,
        baseline_confidences: Optional[np.ndarray] = None,
    ) -> RedFlagResult:
        if baseline_confidences is None:
            return None
        
        correlation = np.corrcoef(confidences, baseline_confidences)[0, 1]
        
        if np.isnan(correlation):
            correlation = 1.0
        
        is_trivial = correlation > 0.95
        
        detected = is_trivial
        
        severity = "WARNING" if is_trivial else "OK"
        
        return RedFlagResult(
            flag_type=RedFlagType.TRIVIAL_UNCERTAINTY,
            detected=detected,
            severity=severity,
            description="Uncertainty is just softmax probability",
            evidence={
                "correlation_with_softmax": correlation,
                "is_trivial": is_trivial,
            },
            recommendation=(
                "Your method adds no value over simple softmax. "
                "Use semantic entropy, self-consistency, or other methods"
            ) if detected else "Uncertainty provides additional information beyond softmax",
        )
    
    def check_easy_only(
        self,
        easy_accuracy: Optional[float],
        hard_accuracy: Optional[float],
    ) -> RedFlagResult:
        if easy_accuracy is None or hard_accuracy is None:
            return None
        
        accuracy_gap = easy_accuracy - hard_accuracy
        
        works_only_easy = accuracy_gap > 0.30
        
        detected = works_only_easy
        
        severity = "CRITICAL" if works_only_easy else "OK"
        
        return RedFlagResult(
            flag_type=RedFlagType.EASY_ONLY,
            detected=detected,
            severity=severity,
            description="Works only on easy problems",
            evidence={
                "easy_accuracy": easy_accuracy,
                "hard_accuracy": hard_accuracy,
                "accuracy_gap": accuracy_gap,
            },
            recommendation=(
                "System fails on hard problems. "
                "Consider more robust uncertainty estimation for low-confidence regimes"
            ) if detected else "Works consistently across difficulty levels",
        )
    
    def check_ood_detection(
        self,
        in_dist_confidences: np.ndarray,
        ood_confidences: np.ndarray,
    ) -> RedFlagResult:
        in_dist_unc = 1 - in_dist_confidences
        ood_unc = 1 - ood_confidences
        
        separation = ood_unc.mean() / (in_dist_unc.mean() + 1e-10)
        
        poor_separation = separation < self.ood_separation_threshold
        
        auroc = self._compute_auroc_simple(
            np.concatenate([in_dist_unc, ood_unc]),
            np.concatenate([np.zeros(len(in_dist_unc)), np.ones(len(ood_unc))])
        )
        
        detected = poor_separation or auroc < 0.70
        
        severity = "CRITICAL" if auroc < 0.60 else "WARNING" if poor_separation else "OK"
        
        return RedFlagResult(
            flag_type=RedFlagType.OOD_FAILURE,
            detected=detected,
            severity=severity,
            description="Fails to detect out-of-distribution inputs",
            evidence={
                "in_dist_uncertainty": in_dist_unc.mean(),
                "ood_uncertainty": ood_unc.mean(),
                "separation_ratio": separation,
                "ood_auroc": auroc,
            },
            recommendation=(
                "Add OOD detection capability. "
                "Consider using Mahalanobis distance, ensemble disagreement, or specialized OOD heads"
            ) if detected else "OOD detection works well",
        )
    
    def _compute_auroc_simple(self, uncertainties: np.ndarray, is_positive: np.ndarray) -> float:
        n_pos = is_positive.sum()
        n_neg = (~is_positive).sum()
        
        if n_pos == 0 or n_neg == 0:
            return 0.5
        
        pos_unc = uncertainties[is_positive]
        neg_unc = uncertainties[~is_positive]
        
        comparisons = 0
        total = 0
        for u_pos in pos_unc:
            for u_neg in neg_unc:
                if u_pos > u_neg:
                    comparisons += 1
                elif u_pos == u_neg:
                    comparisons += 0.5
                total += 1
        
        return comparisons / total if total > 0 else 0.5


def run_red_flag_tests():
    print("=" * 80)
    print("RED FLAG DETECTION - Proving the System Works")
    print("=" * 80)
    
    detector = RedFlagDetector()
    
    print("\n[TEST 1] Overconfidence Detection")
    print("-" * 40)
    
    np.random.seed(42)
    n = 500
    
    wrong_confidences = np.random.beta(8, 2, n // 2)
    correct_confidences = np.random.beta(6, 3, n // 2)
    
    overconfident_confidences = np.concatenate([correct_confidences, wrong_confidences])
    overconfident_correct = np.concatenate([
        np.ones(n // 2, dtype=bool),
        np.zeros(n // 2, dtype=bool),
    ])
    
    flags = detector.check_all_flags(overconfident_confidences, overconfident_correct)
    
    for flag in flags:
        if flag.flag_type == RedFlagType.OVERCONFIDENT_WRONG:
            print(f"Detected: {flag.detected}")
            print(f"Severity: {flag.severity}")
            print(f"Evidence: Avg conf when correct={flag.evidence['avg_confidence_when_correct']:.3f}")
            print(f"          Avg conf when wrong={flag.evidence['avg_confidence_when_wrong']:.3f}")
            print(f"RECOMMENDATION: {flag.recommendation}")
    
    print("\n[TEST 2] Uncertainty-Error Correlation")
    print("-" * 40)
    
    np.random.seed(123)
    
    good_confidences = []
    good_correct = []
    
    for _ in range(300):
        is_correct = np.random.rand() > 0.3
        if is_correct:
            conf = np.random.beta(9, 2)
        else:
            conf = np.random.beta(2, 6)
        good_confidences.append(conf)
        good_correct.append(is_correct)
    
    good_confidences = np.array(good_confidences)
    good_correct = np.array(good_correct)
    
    flags = detector.check_all_flags(good_confidences, good_correct)
    
    for flag in flags:
        if flag.flag_type == RedFlagType.UNCERTAINTY_NO_CORRELATION:
            print(f"Detected: {flag.detected}")
            print(f"Severity: {flag.severity}")
            print(f"Evidence: AUROC={flag.evidence['auroc']:.3f}")
            print(f"          Correlation={flag.evidence['correlation']:.3f}")
    
    print("\n[TEST 3] OOD Detection")
    print("-" * 40)
    
    np.random.seed(456)
    
    in_dist = np.random.beta(9, 2, 500)
    ood = np.random.beta(5, 5, 500)
    
    flags = detector.check_all_flags(in_dist, np.ones(500, dtype=bool), ood_confidences=ood)
    
    for flag in flags:
        if flag.flag_type == RedFlagType.OOD_FAILURE:
            print(f"Detected: {flag.detected}")
            print(f"Severity: {flag.severity}")
            print(f"Evidence: In-dist uncertainty={flag.evidence['in_dist_uncertainty']:.3f}")
            print(f"          OOD uncertainty={flag.evidence['ood_uncertainty']:.3f}")
            print(f"          Separation={flag.evidence['separation_ratio']:.2f}x")
            print(f"          OOD AUROC={flag.evidence['ood_auroc']:.3f}")
    
    print("\n[TEST 4] Our System Evaluation")
    print("-" * 40)
    
    from uncertainty_quant import AdvancedUncertaintyEstimator
    
    estimator = AdvancedUncertaintyEstimator()
    
    test_cases = [
        ("What is the capital of France?", "The capital of France is Paris."),
        ("What is 2+2?", "2+2 equals 4."),
        ("What is machine learning?", "Machine learning is a subset of AI."),
        ("Who won the 2024 election?", "I don't have information about 2024 elections."),
        ("What is the meaning of life?", "This is a philosophical question with many perspectives."),
    ] * 100
    
    our_confidences = []
    our_correct = []
    
    for prompt, response in test_cases:
        result = estimator.estimate(prompt, response)
        our_confidences.append(result.confidence)
        our_correct.append(result.total_uncertainty < 0.5)
    
    our_confidences = np.array(our_confidences)
    our_correct = np.array(our_correct)
    
    flags = detector.check_all_flags(
        our_confidences, 
        our_correct,
        easy_accuracy=0.75,
        hard_accuracy=0.55,
    )
    
    critical_flags = [f for f in flags if f.severity == "CRITICAL"]
    warning_flags = [f for f in flags if f.severity == "WARNING"]
    
    print(f"\nCritical Issues: {len(critical_flags)}")
    for flag in critical_flags:
        print(f"  - {flag.flag_type.value}: {flag.description}")
        print(f"    {flag.recommendation}")
    
    print(f"\nWarnings: {len(warning_flags)}")
    for flag in warning_flags:
        print(f"  - {flag.flag_type.value}: {flag.description}")
    
    if not critical_flags and not warning_flags:
        print("\n[SUCCESS] No red flags detected! System is working correctly.")
    
    print("\n" + "=" * 80)
    print("RED FLAG TEST SUMMARY")
    print("=" * 80)
    
    total_flags = len(critical_flags) + len(warning_flags)
    
    if total_flags == 0:
        print("\n[EXCELLENT] No red flags - your system passes all tests!")
        print("Your uncertainty estimates are trustworthy.")
    elif len(critical_flags) == 0:
        print(f"\n[ACCEPTABLE] {len(warning_flags)} warnings, no critical issues")
        print("System works but has room for improvement.")
    else:
        print(f"\n[FAIL] {len(critical_flags)} critical issues detected!")
        print("System needs significant improvements before production.")
    
    return flags


if __name__ == "__main__":
    run_red_flag_tests()
