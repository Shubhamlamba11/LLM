"""
Multi-Modal Uncertainty Fusion Module
Integrates text, image, and structured data uncertainty
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional, Any, Union, Tuple
import numpy as np


class ModalModality(Enum):
    TEXT = "text"
    IMAGE = "image"
    STRUCTURED = "structured"
    AUDIO = "audio"
    VIDEO = "video"


class FusionStrategy(Enum):
    WEIGHTED_AVERAGE = "weighted_average"
    MAX_ENTROPY = "max_entropy"
    CONFIDENCE_WEIGHTED = "confidence_weighted"
    ADAPTIVE = "adaptive"
    HIERARCHICAL = "hierarchical"


@dataclass
class ModalityUncertainty:
    modality: ModalModality
    uncertainty: float
    confidence: float = 1.0
    sources: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def is_reliable(self, threshold: float = 0.6) -> bool:
        return self.confidence >= threshold
    
    def get_weight(self, strategy: FusionStrategy) -> float:
        if strategy == FusionStrategy.WEIGHTED_AVERAGE:
            return 1.0 / (self.uncertainty + 0.1)
        elif strategy == FusionStrategy.CONFIDENCE_WEIGHTED:
            return self.confidence
        elif strategy == FusionStrategy.MAX_ENTROPY:
            return self.uncertainty
        else:
            return 1.0 - self.uncertainty


@dataclass
class MultiModalResult:
    fused_uncertainty: float
    modality_uncertainties: Dict[ModalModality, ModalityUncertainty]
    dominant_modality: ModalModality
    consensus_score: float
    disagreement_score: float
    reliability_weights: Dict[ModalModality, float]
    cross_modal_consistency: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_modality_ranking(self) -> List[Tuple[ModalModality, float]]:
        sorted_mods = sorted(
            self.modality_uncertainties.items(),
            key=lambda x: x[1].uncertainty
        )
        return [(m, u.uncertainty) for m, u in sorted_mods]
    
    def has_cross_modal_conflict(self, threshold: float = 0.3) -> bool:
        return self.disagreement_score > threshold
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "fused_uncertainty": self.fused_uncertainty,
            "dominant_modality": self.dominant_modality.value,
            "consensus_score": self.consensus_score,
            "disagreement_score": self.disagreement_score,
            "cross_modal_conflict": self.has_cross_modal_conflict(),
            "modality_ranking": [(m.value, u) for m, u in self.get_modality_ranking()],
        }


class MultiModalUncertaintyFusion:
    def __init__(
        self,
        fusion_strategy: FusionStrategy = FusionStrategy.ADAPTIVE,
        default_weights: Optional[Dict[ModalModality, float]] = None,
    ):
        self.fusion_strategy = fusion_strategy
        self.default_weights = default_weights or {
            ModalModality.TEXT: 0.4,
            ModalModality.IMAGE: 0.3,
            ModalModality.STRUCTURED: 0.3,
        }
        
        self.calibration_cache: Dict[str, Any] = {}
        
    def fuse(
        self,
        modality_uncertainties: List[ModalityUncertainty],
        cross_references: Optional[Dict[str, Any]] = None,
        return_all: bool = False,
    ) -> MultiModalResult:
        if not modality_uncertainties:
            return MultiModalResult(
                fused_uncertainty=0.5,
                modality_uncertainties={},
                dominant_modality=ModalModality.TEXT,
                consensus_score=0.0,
                disagreement_score=1.0,
                reliability_weights={},
                cross_modal_consistency=0.0,
            )
        
        mod_dict = {u.modality: u for u in modality_uncertainties}
        
        for modality in ModalModality:
            if modality not in mod_dict:
                mod_dict[modality] = ModalityUncertainty(
                    modality=modality,
                    uncertainty=0.5,
                    confidence=0.3,
                    sources=["missing"],
                )
        
        weights = self._compute_reliability_weights(mod_dict, cross_references)
        
        if self.fusion_strategy == FusionStrategy.ADAPTIVE:
            fused = self._adaptive_fusion(mod_dict, weights)
        elif self.fusion_strategy == FusionStrategy.WEIGHTED_AVERAGE:
            fused = self._weighted_average_fusion(mod_dict, weights)
        elif self.fusion_strategy == FusionStrategy.MAX_ENTROPY:
            fused = self._max_entropy_fusion(mod_dict)
        elif self.fusion_strategy == FusionStrategy.CONFIDENCE_WEIGHTED:
            fused = self._confidence_weighted_fusion(mod_dict, weights)
        elif self.fusion_strategy == FusionStrategy.HIERARCHICAL:
            fused = self._hierarchical_fusion(mod_dict, cross_references)
        else:
            fused = self._weighted_average_fusion(mod_dict, weights)
        
        consensus = self._compute_consensus(mod_dict)
        disagreement = 1.0 - consensus
        
        dominant = self._identify_dominant_modality(mod_dict, weights)
        
        cross_consistency = self._compute_cross_modal_consistency(
            mod_dict, cross_references
        ) if cross_references else 0.5
        
        result = MultiModalResult(
            fused_uncertainty=fused,
            modality_uncertainties=mod_dict,
            dominant_modality=dominant,
            consensus_score=consensus,
            disagreement_score=disagreement,
            reliability_weights=weights,
            cross_modal_consistency=cross_consistency,
        )
        
        if return_all:
            return result
        return result
    
    def fuse_text_only(
        self,
        text_uncertainty: float,
        text_confidence: float = 1.0,
    ) -> MultiModalResult:
        return self.fuse([
            ModalityUncertainty(
                modality=ModalModality.TEXT,
                uncertainty=text_uncertainty,
                confidence=text_confidence,
            )
        ])
    
    def fuse_text_image(
        self,
        text_uncertainty: float,
        image_uncertainty: float,
        alignment_score: Optional[float] = None,
        text_confidence: float = 1.0,
        image_confidence: float = 1.0,
    ) -> MultiModalResult:
        mod_uncertainties = [
            ModalityUncertainty(
                modality=ModalModality.TEXT,
                uncertainty=text_uncertainty,
                confidence=text_confidence,
            ),
            ModalityUncertainty(
                modality=ModalModality.IMAGE,
                uncertainty=image_uncertainty,
                confidence=image_confidence,
            ),
        ]
        
        cross_refs = None
        if alignment_score is not None:
            cross_refs = {"alignment_score": alignment_score}
        
        return self.fuse(mod_uncertainties, cross_refs)
    
    def estimate_text_uncertainty(
        self,
        text: str,
        context: Optional[str] = None,
    ) -> ModalityUncertainty:
        uncertainty_score = 0.5
        
        uncertainty_words = {
            "uncertain": 0.3, "unclear": 0.3, "maybe": 0.4, "perhaps": 0.4,
            "probably": 0.3, "possibly": 0.4, "might": 0.35, "could": 0.35,
            "unfortunately": 0.3, "however": 0.2,
        }
        
        text_lower = text.lower()
        for word, score in uncertainty_words.items():
            if word in text_lower:
                uncertainty_score = min(uncertainty_score, score)
        
        if context:
            context_words = set(context.lower().split())
            text_words = set(text_lower.split())
            overlap = len(context_words & text_words) / max(len(text_words), 1)
            uncertainty_score = uncertainty_score * (1 - overlap * 0.3)
        
        return ModalityUncertainty(
            modality=ModalModality.TEXT,
            uncertainty=min(uncertainty_score, 1.0),
            confidence=0.8,
            sources=["lexical_analysis"],
        )
    
    def estimate_image_uncertainty(
        self,
        image_features: Dict[str, Any],
        caption: Optional[str] = None,
    ) -> ModalityUncertainty:
        uncertainty = 0.5
        
        if "detection_confidence" in image_features:
            uncertainty = 1.0 - image_features["detection_confidence"]
        
        if "bbox_count" in image_features:
            n_objects = image_features["bbox_count"]
            if n_objects > 10:
                uncertainty *= 1.2
            elif n_objects < 2:
                uncertainty *= 0.8
        
        if caption:
            caption_uncertainty = self.estimate_text_uncertainty(caption)
            uncertainty = 0.6 * uncertainty + 0.4 * caption_uncertainty.uncertainty
        
        return ModalityUncertainty(
            modality=ModalModality.IMAGE,
            uncertainty=min(uncertainty, 1.0),
            confidence=image_features.get("model_confidence", 0.7),
            sources=["detection", "caption_analysis"],
        )
    
    def estimate_structured_uncertainty(
        self,
        structured_data: Dict[str, Any],
        schema: Optional[Dict[str, Any]] = None,
    ) -> ModalityUncertainty:
        uncertainty = 0.3
        
        missing_fields = 0
        total_fields = 0
        
        if schema and "required" in schema:
            for field in schema["required"]:
                total_fields += 1
                if field not in structured_data:
                    missing_fields += 1
        
        if total_fields > 0:
            uncertainty += (missing_fields / total_fields) * 0.3
        
        type_errors = 0
        for key, value in structured_data.items():
            if schema and key in schema.get("properties", {}):
                expected_type = schema["properties"][key].get("type")
                if expected_type and not self._check_type(value, expected_type):
                    type_errors += 0.1
        
        uncertainty += min(type_errors, 0.3)
        
        return ModalityUncertainty(
            modality=ModalModality.STRUCTURED,
            uncertainty=min(uncertainty, 1.0),
            confidence=1.0 - uncertainty * 0.5,
            sources=["schema_validation", "type_checking"],
        )
    
    def _check_type(self, value: Any, expected_type: str) -> bool:
        type_map = {
            "string": str,
            "number": (int, float),
            "integer": int,
            "boolean": bool,
            "array": list,
            "object": dict,
        }
        
        expected = type_map.get(expected_type)
        if expected is None:
            return True
        
        return isinstance(value, expected)
    
    def _compute_reliability_weights(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
        cross_references: Optional[Dict[str, Any]],
    ) -> Dict[ModalModality, float]:
        weights = {}
        
        for modality, mu in mod_dict.items():
            base_weight = self.default_weights.get(modality, 0.33)
            
            reliability = mu.confidence * base_weight
            
            if mu.is_reliable():
                reliability *= 1.2
            else:
                reliability *= 0.7
            
            weights[modality] = reliability
        
        total = sum(weights.values())
        if total > 0:
            weights = {k: v / total for k, v in weights.items()}
        
        return weights
    
    def _weighted_average_fusion(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
        weights: Dict[ModalModality, float],
    ) -> float:
        weighted_sum = sum(
            mu.uncertainty * weights[modality]
            for modality, mu in mod_dict.items()
        )
        return min(weighted_sum, 1.0)
    
    def _max_entropy_fusion(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
    ) -> float:
        return max(mu.uncertainty for mu in mod_dict.values())
    
    def _confidence_weighted_fusion(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
        weights: Dict[ModalModality, float],
    ) -> float:
        total_weight = 0.0
        weighted_uncertainty = 0.0
        
        for modality, mu in mod_dict.items():
            w = weights[modality] * mu.confidence
            total_weight += w
            weighted_uncertainty += mu.uncertainty * w
        
        if total_weight > 0:
            return min(weighted_uncertainty / total_weight, 1.0)
        return 0.5
    
    def _adaptive_fusion(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
        weights: Dict[ModalModality, float],
    ) -> float:
        uncertainties = [mu.uncertainty for mu in mod_dict.values()]
        
        max_unc = max(uncertainties)
        min_unc = min(uncertainties)
        
        if max_unc - min_unc > 0.4:
            return self._max_entropy_fusion(mod_dict)
        
        consensus = self._compute_consensus(mod_dict)
        if consensus > 0.8:
            return self._weighted_average_fusion(mod_dict, weights)
        
        return self._confidence_weighted_fusion(mod_dict, weights)
    
    def _hierarchical_fusion(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
        cross_references: Optional[Dict[str, Any]],
    ) -> float:
        text_unc = mod_dict.get(ModalModality.TEXT, ModalityUncertainty(ModalModality.TEXT, 0.5)).uncertainty
        
        image_unc = mod_dict.get(ModalModality.IMAGE, ModalityUncertainty(ModalModality.IMAGE, 0.5)).uncertainty
        structured_unc = mod_dict.get(ModalModality.STRUCTURED, ModalityUncertainty(ModalModality.STRUCTURED, 0.5)).uncertainty
        
        non_text_unc = np.mean([image_unc, structured_unc])
        
        if cross_references and "alignment_score" in cross_references:
            alignment = cross_references["alignment_score"]
            text_weight = 0.3 + alignment * 0.3
        else:
            text_weight = 0.5
        
        fused = text_unc * text_weight + non_text_unc * (1 - text_weight)
        
        return min(fused, 1.0)
    
    def _compute_consensus(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
    ) -> float:
        uncertainties = [mu.uncertainty for mu in mod_dict.values()]
        
        if not uncertainties:
            return 0.0
        
        mean_unc = np.mean(uncertainties)
        variance = np.var(uncertainties)
        
        consensus = 1.0 - min(variance * 2, 1.0)
        
        return consensus
    
    def _identify_dominant_modality(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
        weights: Dict[ModalModality, float],
    ) -> ModalModality:
        if not weights:
            return ModalModality.TEXT
        
        scores = {
            modality: (1 - mu.uncertainty) * weights[modality]
            for modality, mu in mod_dict.items()
        }
        
        return max(scores, key=scores.get)
    
    def _compute_cross_modal_consistency(
        self,
        mod_dict: Dict[ModalModality, ModalityUncertainty],
        cross_references: Optional[Dict[str, Any]],
    ) -> float:
        if not cross_references:
            return 0.5
        
        consistency_score = 0.5
        
        if "alignment_score" in cross_references:
            consistency_score = cross_references["alignment_score"]
        
        if "contradiction_detected" in cross_references:
            if cross_references["contradiction_detected"]:
                consistency_score *= 0.5
        
        return min(consistency_score, 1.0)
    
    def calibrate_cross_modal(
        self,
        training_data: List[Dict[str, Any]],
        correctness: List[bool],
    ) -> "MultiModalUncertaintyFusion":
        self.calibration_cache = {
            "n_samples": len(training_data),
            "accuracy": sum(correctness) / len(correctness) if correctness else 0,
        }
        
        return self
