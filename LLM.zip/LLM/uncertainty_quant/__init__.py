"""
Adaptive Uncertainty Quantification System for LLMs
Multi-Modal Uncertainty Estimation with Hallucination Detection and Reasoning Integration

Advanced Features:
- 8+ uncertainty estimation methods (Token Prob, Semantic Entropy, Self-Consistency, etc.)
- Process Reward Model for step-level verification
- Tree of Uncertain Thoughts with multiple search strategies
- Multi-modal fusion (text + image + structured)
- Production API server with FastAPI
- Batch processing with async support
- Calibration and domain transfer
"""

from .core.uncertainty_estimator import UncertaintyEstimator, UncertaintyType, UncertaintyResult
from .core.advanced_estimator import AdvancedUncertaintyEstimator, AdvancedUncertaintyResult, UncertaintyMethod
from .core.calibration import Calibrator, CalibrationMethod, CalibrationResult

from .hallucination.detector import HallucinationDetector, HallucinationResult, HallucinationType

from .reasoning.cot_tracker import CoTUncertaintyTracker, ReasoningStep, CoTAnalysis, StepConfidence
from .reasoning.tout import TreeOfUncertainThoughts, ThoughtNode, SearchStrategy, NodeState, TouTResult
from .reasoning.prm_verifier import ProcessRewardVerifier, StepVerification, ReasoningVerification, StepVerdict
from .reasoning.router import UncertaintyAwareRouter, RoutingDecision, QueryProfile, SolverType

from .multimodal.fusion import (
    MultiModalUncertaintyFusion, 
    ModalityUncertainty, 
    MultiModalResult, 
    ModalModality,
    FusionStrategy,
)

from .api import UnifiedUncertaintyAPI, UncertaintyReport, OutputFormat

__version__ = "1.0.0"

__all__ = [
    # Core
    "UncertaintyEstimator",
    "UncertaintyType", 
    "UncertaintyResult",
    "AdvancedUncertaintyEstimator",
    "AdvancedUncertaintyResult",
    "UncertaintyMethod",
    "Calibrator",
    "CalibrationMethod",
    "CalibrationResult",
    
    # Hallucination
    "HallucinationDetector",
    "HallucinationResult",
    "HallucinationType",
    
    # Reasoning
    "CoTUncertaintyTracker",
    "ReasoningStep",
    "CoTAnalysis",
    "StepConfidence",
    "TreeOfUncertainThoughts",
    "ThoughtNode",
    "SearchStrategy",
    "NodeState",
    "TouTResult",
    "ProcessRewardVerifier",
    "StepVerification",
    "ReasoningVerification",
    "StepVerdict",
    "UncertaintyAwareRouter",
    "RoutingDecision",
    "QueryProfile",
    "SolverType",
    
    # Multi-Modal
    "MultiModalUncertaintyFusion",
    "ModalityUncertainty",
    "MultiModalResult",
    "ModalModality",
    "FusionStrategy",
    
    # API
    "UnifiedUncertaintyAPI",
    "UncertaintyReport",
    "OutputFormat",
]
