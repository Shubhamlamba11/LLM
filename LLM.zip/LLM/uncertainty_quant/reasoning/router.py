"""
Uncertainty-Aware Reasoning Router
Routes queries to appropriate solvers based on uncertainty assessment
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional, Any, Callable, Tuple, Union
import numpy as np


class SolverType(Enum):
    DIRECT = "direct"
    CHAIN_OF_THOUGHT = "chain_of_thought"
    TREE_OF_THOUGHTS = "tree_of_thoughts"
    SELF_CONSISTENCY = "self_consistency"
    TOOL_AUGMENTED = "tool_augmented"
    EXTERNAL_VERIFIER = "external_verifier"
    REFLECTION = "reflection"


@dataclass
class RoutingDecision:
    selected_solver: SolverType
    confidence: float
    uncertainty: float
    reasoning: str
    alternatives: List[Tuple[SolverType, float]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def requires_additional_verification(self, threshold: float = 0.5) -> bool:
        return self.uncertainty > threshold
    
    def needs_human_review(self, threshold: float = 0.75) -> bool:
        return self.uncertainty > threshold
    
    def get_explanation(self) -> str:
        if self.needs_human_review():
            return f"High uncertainty ({self.uncertainty:.2f}) - Human review recommended"
        elif self.requires_additional_verification():
            return f"Moderate uncertainty ({self.uncertainty:.2f}) - Verification recommended"
        else:
            return f"Low uncertainty ({self.uncertainty:.2f}) - Direct solution acceptable"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "solver": self.selected_solver.value,
            "confidence": self.confidence,
            "uncertainty": self.uncertainty,
            "reasoning": self.reasoning,
            "alternatives": [(s.value, c) for s, c in self.alternatives],
            "needs_verification": self.requires_additional_verification(),
            "needs_human_review": self.needs_human_review(),
        }


@dataclass
class QueryProfile:
    complexity: float
    ambiguity: float
    factual_density: float
    reasoning_requirements: List[str]
    domain: Optional[str] = None
    requires_tools: bool = False
    is_multi_step: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_difficulty_score(self) -> float:
        return (
            self.complexity * 0.4 +
            self.ambiguity * 0.3 +
            (1 - self.factual_density) * 0.3
        )
    
    def requires_careful_reasoning(self, threshold: float = 0.6) -> bool:
        return self.get_difficulty_score() > threshold


class UncertaintyAwareRouter:
    def __init__(
        self,
        uncertainty_estimator: Any = None,
        enable_adaptive: bool = True,
        cost_weight: float = 0.3,
    ):
        self.uncertainty_estimator = uncertainty_estimator
        self.enable_adaptive = enable_adaptive
        self.cost_weight = cost_weight
        
        self.solver_capabilities: Dict[SolverType, Dict[str, Any]] = {
            SolverType.DIRECT: {
                "complexity_cap": 0.4,
                "ambiguity_cap": 0.3,
                "estimated_cost": 1.0,
                "speed": "fast",
            },
            SolverType.CHAIN_OF_THOUGHT: {
                "complexity_cap": 0.7,
                "ambiguity_cap": 0.5,
                "estimated_cost": 2.0,
                "speed": "medium",
            },
            SolverType.TREE_OF_THOUGHTS: {
                "complexity_cap": 0.9,
                "ambiguity_cap": 0.7,
                "estimated_cost": 5.0,
                "speed": "slow",
            },
            SolverType.SELF_CONSISTENCY: {
                "complexity_cap": 0.6,
                "ambiguity_cap": 0.5,
                "estimated_cost": 3.0,
                "speed": "medium",
            },
            SolverType.TOOL_AUGMENTED: {
                "complexity_cap": 0.8,
                "ambiguity_cap": 0.6,
                "estimated_cost": 4.0,
                "speed": "medium",
                "requires_tools": True,
            },
            SolverType.EXTERNAL_VERIFIER: {
                "complexity_cap": 1.0,
                "ambiguity_cap": 0.8,
                "estimated_cost": 6.0,
                "speed": "slow",
                "verification": True,
            },
            SolverType.REFLECTION: {
                "complexity_cap": 0.7,
                "ambiguity_cap": 0.6,
                "estimated_cost": 2.5,
                "speed": "medium",
            },
        }
        
        self.routing_history: List[Dict[str, Any]] = []
    
    def route(
        self,
        query: str,
        context: Optional[str] = None,
        return_all: bool = False,
    ) -> RoutingDecision:
        profile = self._analyze_query(query, context)
        
        uncertainty = self._estimate_uncertainty(query, context, profile)
        
        solver_scores = self._score_solvers(profile, uncertainty)
        
        best_solver, best_score = max(solver_scores.items(), key=lambda x: x[1])
        
        alternatives = sorted(
            [(s, score) for s, score in solver_scores.items() if s != best_solver],
            key=lambda x: x[1],
            reverse=True
        )[:3]
        
        decision = RoutingDecision(
            selected_solver=best_solver,
            confidence=best_score,
            uncertainty=uncertainty,
            reasoning=self._generate_reasoning(profile, uncertainty, best_solver),
            alternatives=alternatives,
            metadata={
                "profile": profile.__dict__,
                "solver_scores": {s.value: score for s, score in solver_scores.items()},
            }
        )
        
        self.routing_history.append(decision.to_dict())
        
        if return_all:
            return decision
        return decision
    
    def _analyze_query(
        self,
        query: str,
        context: Optional[str],
    ) -> QueryProfile:
        complexity = self._estimate_complexity(query)
        ambiguity = self._estimate_ambiguity(query)
        factual_density = self._estimate_factual_density(query)
        reasoning_req = self._identify_reasoning_requirements(query)
        domain = self._identify_domain(query)
        requires_tools = self._check_tool_requirement(query)
        is_multi_step = self._check_multi_step(query)
        
        return QueryProfile(
            complexity=complexity,
            ambiguity=ambiguity,
            factual_density=factual_density,
            reasoning_requirements=reasoning_req,
            domain=domain,
            requires_tools=requires_tools,
            is_multi_step=is_multi_step,
        )
    
    def _estimate_complexity(self, query: str) -> float:
        complexity_indicators = {
            "calculate": 0.1, "compute": 0.1, "analyze": 0.2,
            "explain": 0.2, "compare": 0.3, "evaluate": 0.3,
            "design": 0.4, "synthesize": 0.4, "prove": 0.5,
        }
        
        words = query.lower().split()
        complexity_score = 0.3
        
        for word, score in complexity_indicators.items():
            if word in words:
                complexity_score = max(complexity_score, score)
        
        sentence_count = query.count('.')
        if sentence_count > 3:
            complexity_score += 0.1
        
        if len(words) > 30:
            complexity_score += 0.1
        
        question_marks = query.count('?')
        if question_marks > 1:
            complexity_score += 0.1
        
        return min(complexity_score, 1.0)
    
    def _estimate_ambiguity(self, query: str) -> float:
        ambiguity_indicators = {
            "maybe": 0.3, "perhaps": 0.3, "possibly": 0.3,
            "could be": 0.3, "might be": 0.3, "uncertain": 0.4,
            "unclear": 0.4, "ambiguous": 0.5, "vague": 0.4,
            "depends": 0.3, "various": 0.2, "different": 0.2,
        }
        
        query_lower = query.lower()
        ambiguity_score = 0.2
        
        for indicator, score in ambiguity_indicators.items():
            if indicator in query_lower:
                ambiguity_score = max(ambiguity_score, score)
        
        multiple_interpretations = ["interpret", "understand", "meaning"]
        for phrase in multiple_interpretations:
            if phrase in query_lower:
                ambiguity_score += 0.15
        
        return min(ambiguity_score, 1.0)
    
    def _estimate_factual_density(self, query: str) -> float:
        import re
        
        factual_indicators = {
            "fact": 0.1, "statistic": 0.1, "data": 0.1,
            "research": 0.2, "study": 0.2, "according to": 0.2,
            "percent": 0.1, "percentage": 0.1, "number": 0.1,
            "date": 0.1, "year": 0.1, "historical": 0.2,
        }
        
        query_lower = query.lower()
        factual_score = 0.3
        
        numbers = re.findall(r'\d+', query)
        factual_score += min(len(numbers) * 0.05, 0.3)
        
        for indicator, score in factual_indicators.items():
            if indicator in query_lower:
                factual_score = max(factual_score, 1 - score)
        
        return min(factual_score, 1.0)
    
    def _identify_reasoning_requirements(self, query: str) -> List[str]:
        requirements = []
        
        query_lower = query.lower()
        
        if any(word in query_lower for word in ["cause", "effect", "because", "therefore", "result"]):
            requirements.append("causal_reasoning")
        
        if any(word in query_lower for word in ["compare", "versus", "vs", "difference", "similar"]):
            requirements.append("comparative_reasoning")
        
        if any(word in query_lower for word in ["if", "when", "假设", "suppose"]):
            requirements.append("conditional_reasoning")
        
        if any(word in query_lower for word in ["calculate", "compute", "sum", "total", "percentage"]):
            requirements.append("mathematical_reasoning")
        
        if any(word in query_lower for word in ["explain", "why", "how does", "mechanism"]):
            requirements.append("explanatory_reasoning")
        
        if any(word in query_lower for word in ["all", "every", "none", "always", "never"]):
            requirements.append("logical_reasoning")
        
        return requirements
    
    def _identify_domain(self, query: str) -> Optional[str]:
        domains = {
            "mathematics": ["calculate", "compute", "equation", "solve", "math", "algebra"],
            "science": ["experiment", "hypothesis", "theory", "scientific", "physics", "chemistry"],
            "medicine": ["diagnosis", "treatment", "symptom", "patient", "clinical", "medical"],
            "law": ["legal", "court", "law", "contract", "liability", "rights"],
            "programming": ["code", "function", "algorithm", "debug", "implement", "software"],
            "history": ["historical", "century", "war", "civilization", "ancient", "modern"],
            "economics": ["market", "economy", "price", "cost", "gdp", "inflation"],
        }
        
        query_lower = query.lower()
        
        for domain, keywords in domains.items():
            if any(kw in query_lower for kw in keywords):
                return domain
        
        return None
    
    def _check_tool_requirement(self, query: str) -> bool:
        tool_indicators = [
            "search", "look up", "find", "retrieve", "access",
            "database", "web", "internet", "calculate", "compute",
        ]
        
        query_lower = query.lower()
        return any(indicator in query_lower for indicator in tool_indicators)
    
    def _check_multi_step(self, query: str) -> bool:
        multi_step_indicators = [
            "first", "second", "then", "next", "finally",
            "step", "stage", "phase", "part",
        ]
        
        query_lower = query.lower()
        count = sum(1 for indicator in multi_step_indicators if indicator in query_lower)
        
        return count >= 2 or " and then " in query_lower
    
    def _estimate_uncertainty(
        self,
        query: str,
        context: Optional[str],
        profile: QueryProfile,
    ) -> float:
        if self.uncertainty_estimator:
            result = self.uncertainty_estimator.estimate(query, return_all=True)
            if hasattr(result, 'total_uncertainty'):
                return result.total_uncertainty
        
        uncertainty = (
            profile.complexity * 0.35 +
            profile.ambiguity * 0.35 +
            (1 - profile.factual_density) * 0.3
        )
        
        if profile.is_multi_step:
            uncertainty += 0.1
        
        if profile.domain:
            uncertainty += 0.05
        
        return min(uncertainty, 1.0)
    
    def _score_solvers(
        self,
        profile: QueryProfile,
        uncertainty: float,
    ) -> Dict[SolverType, float]:
        scores = {}
        
        for solver_type, capabilities in self.solver_capabilities.items():
            if capabilities.get("requires_tools") and not profile.requires_tools:
                capability_score = 0.3
            else:
                complexity_gap = capabilities["complexity_cap"] - profile.complexity
                ambiguity_gap = capabilities["ambiguity_cap"] - profile.ambiguity
                
                capability_score = (
                    0.4 * max(0, complexity_gap) +
                    0.3 * max(0, ambiguity_gap) +
                    0.3
                )
            
            uncertainty_fit = 1.0 - abs(
                (capabilities["complexity_cap"] + capabilities["ambiguity_cap"]) / 2 - uncertainty
            )
            
            efficiency_score = (
                1.0 - self.cost_weight * (capabilities["estimated_cost"] - 1.0)
            )
            
            if profile.is_multi_step and solver_type in [
                SolverType.CHAIN_OF_THOUGHT,
                SolverType.TREE_OF_THOUGHTS,
            ]:
                capability_score *= 1.2
            
            if profile.domain == "mathematics" and solver_type in [
                SolverType.CHAIN_OF_THOUGHT,
                SolverType.SELF_CONSISTENCY,
            ]:
                capability_score *= 1.15
            
            scores[solver_type] = (
                capability_score * 0.5 +
                uncertainty_fit * 0.3 +
                efficiency_score * 0.2
            )
        
        return scores
    
    def _generate_reasoning(
        self,
        profile: QueryProfile,
        uncertainty: float,
        selected_solver: SolverType,
    ) -> str:
        reasons = []
        
        if uncertainty > 0.6:
            reasons.append(f"High uncertainty ({uncertainty:.2f}) requires robust reasoning")
        elif uncertainty < 0.3:
            reasons.append(f"Low uncertainty ({uncertainty:.2f}) allows direct approach")
        
        if profile.complexity > 0.6:
            reasons.append(f"High complexity ({profile.complexity:.2f}) needs step-by-step reasoning")
        
        if profile.is_multi_step:
            reasons.append("Multi-step problem detected")
        
        if profile.requires_tools:
            reasons.append("Tool usage may be beneficial")
        
        if profile.domain:
            reasons.append(f"Domain: {profile.domain}")
        
        reasons.append(f"Selected solver: {selected_solver.value}")
        
        return "; ".join(reasons)
    
    def get_routing_statistics(self) -> Dict[str, Any]:
        if not self.routing_history:
            return {"message": "No routing history available"}
        
        solver_counts = {}
        total_uncertainty = []
        needs_verification = 0
        needs_human_review = 0
        
        for decision in self.routing_history:
            solver = decision["solver"]
            solver_counts[solver] = solver_counts.get(solver, 0) + 1
            total_uncertainty.append(decision["uncertainty"])
            
            if decision.get("needs_verification", False):
                needs_verification += 1
            if decision.get("needs_human_review", False):
                needs_human_review += 1
        
        return {
            "total_routes": len(self.routing_history),
            "solver_distribution": solver_counts,
            "average_uncertainty": np.mean(total_uncertainty),
            "verification_rate": needs_verification / len(self.routing_history),
            "human_review_rate": needs_human_review / len(self.routing_history),
        }
