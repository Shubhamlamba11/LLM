"""
Tree of Uncertain Thoughts (TouT) Module
Implements uncertainty-aware reasoning path selection and exploration
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional, Any, Callable, Tuple, Set
from dataclasses import dataclass, field
import numpy as np
import heapq


class NodeState(Enum):
    PENDING = "pending"
    EXPANDED = "expanded"
    EVALUATED = "evaluated"
    PRUNED = "pruned"
    SOLVED = "solved"


@dataclass
class ThoughtNode:
    node_id: str
    content: str
    parent_id: Optional[str] = None
    depth: int = 0
    state: NodeState = NodeState.PENDING
    
    value: float = 0.0
    uncertainty: float = 0.5
    confidence: float = 0.5
    
    children_ids: List[str] = field(default_factory=list)
    
    step_uncertainties: List[float] = field(default_factory=list)
    reasoning_score: float = 0.0
    
    visits: int = 0
    total_value: float = 0.0
    
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_score(self) -> float:
        if self.uncertainty == 0:
            return self.value
        return self.value / (self.uncertainty + 0.1)
    
    def update_value(self, value: float) -> None:
        self.visits += 1
        self.total_value += value
        self.value = self.total_value / self.visits
    
    def is_promising(self, threshold: float = 0.6) -> bool:
        return self.confidence >= threshold and self.state != NodeState.PRUNED
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "content": self.content[:100] + "..." if len(self.content) > 100 else self.content,
            "depth": self.depth,
            "state": self.state.value,
            "value": self.value,
            "uncertainty": self.uncertainty,
            "confidence": self.confidence,
            "score": self.get_score(),
            "children": len(self.children_ids),
            "visits": self.visits,
        }


class SearchStrategy(Enum):
    BFS = "breadth_first"
    DFS = "depth_first"
    BEST_FIRST = "best_first"
    MONTE_CARLO = "monte_carlo"
    UCB = "upper_confidence_bound"


@dataclass
class TouTResult:
    best_path: List[ThoughtNode]
    all_nodes: List[ThoughtNode]
    final_uncertainty: float
    exploration_stats: Dict[str, Any]
    pruned_paths: int
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_summary(self) -> str:
        if not self.best_path:
            return "No solution found."
        
        final = self.best_path[-1]
        return (
            f"Solution found with {len(self.best_path)} steps, "
            f"uncertainty={final.uncertainty:.2f}, confidence={final.confidence:.2f}"
        )


class TreeOfUncertainThoughts:
    def __init__(
        self,
        model: Any = None,
        tokenizer: Any = None,
        device: str = "cpu",
        max_depth: int = 10,
        max_breadth: int = 5,
        num_samples: int = 3,
        uncertainty_threshold: float = 0.5,
        value_threshold: float = 0.7,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.max_depth = max_depth
        self.max_breadth = max_breadth
        self.num_samples = num_samples
        self.uncertainty_threshold = uncertainty_threshold
        self.value_threshold = value_threshold
        
        self.nodes: Dict[str, ThoughtNode] = {}
        self.root_id: Optional[str] = None
        self.node_counter = 0
        
        self.expansion_count = 0
        self.pruned_count = 0
        
    def solve(
        self,
        problem: str,
        generate_fn: Optional[Callable] = None,
        evaluate_fn: Optional[Callable] = None,
        search_strategy: SearchStrategy = SearchStrategy.BEST_FIRST,
        return_all: bool = False,
    ) -> TouTResult:
        self.nodes = {}
        self.root_id = None
        self.node_counter = 0
        self.expansion_count = 0
        self.pruned_count = 0
        
        root = self._create_node(
            content=problem,
            depth=0,
            value=1.0,
            uncertainty=0.5,
        )
        self.root_id = root.node_id
        
        if search_strategy == SearchStrategy.BFS:
            self._search_bfs(generate_fn, evaluate_fn)
        elif search_strategy == SearchStrategy.DFS:
            self._search_dfs(generate_fn, evaluate_fn)
        elif search_strategy == SearchStrategy.BEST_FIRST:
            self._search_best_first(generate_fn, evaluate_fn)
        elif search_strategy == SearchStrategy.UCB:
            self._search_ucb(generate_fn, evaluate_fn)
        else:
            self._search_bfs(generate_fn, evaluate_fn)
        
        best_path = self._extract_best_path()
        
        return TouTResult(
            best_path=best_path,
            all_nodes=list(self.nodes.values()),
            final_uncertainty=best_path[-1].uncertainty if best_path else 1.0,
            exploration_stats={
                "total_nodes": len(self.nodes),
                "expanded": self.expansion_count,
                "pruned": self.pruned_count,
                "max_depth_reached": max(n.depth for n in self.nodes.values()) if self.nodes else 0,
            },
            pruned_paths=self.pruned_count,
        )
    
    def _create_node(
        self,
        content: str,
        parent_id: Optional[str] = None,
        depth: int = 0,
        value: float = 0.5,
        uncertainty: float = 0.5,
        confidence: float = 0.5,
    ) -> ThoughtNode:
        self.node_counter += 1
        node_id = f"node_{self.node_counter}"
        
        node = ThoughtNode(
            node_id=node_id,
            content=content,
            parent_id=parent_id,
            depth=depth,
            value=value,
            uncertainty=uncertainty,
            confidence=confidence,
        )
        
        self.nodes[node_id] = node
        
        if parent_id and parent_id in self.nodes:
            self.nodes[parent_id].children_ids.append(node_id)
        
        return node
    
    def _generate_candidates(
        self,
        node: ThoughtNode,
        generate_fn: Optional[Callable],
    ) -> List[str]:
        if generate_fn is None:
            return self._default_generate(node.content)
        
        try:
            candidates = generate_fn(node.content, k=self.max_breadth)
            return candidates
        except Exception:
            return self._default_generate(node.content)
    
    def _default_generate(self, content: str) -> List[str]:
        import random
        
        templates = [
            f"{content} - Approach A",
            f"{content} - Approach B",
            f"{content} - Alternative view",
            f"{content} - Consider X",
            f"{content} - Check Y",
        ]
        
        return random.sample(templates, min(self.max_breadth, len(templates)))
    
    def _evaluate_node(
        self,
        node: ThoughtNode,
        evaluate_fn: Optional[Callable],
    ) -> Tuple[float, float]:
        if evaluate_fn is None:
            return self._default_evaluate(node.content)
        
        try:
            value, uncertainty = evaluate_fn(node.content)
            return value, uncertainty
        except Exception:
            return self._default_evaluate(node.content)
    
    def _default_evaluate(self, content: str) -> Tuple[float, float]:
        uncertainty_indicators = {
            "maybe": 0.3, "perhaps": 0.3, "probably": 0.2, "uncertain": 0.4,
            "might": 0.25, "could": 0.25, "likely": 0.2, "unclear": 0.35,
        }
        
        text_lower = content.lower()
        
        u_score = 0.5
        for indicator, score in uncertainty_indicators.items():
            if indicator in text_lower:
                u_score = min(u_score, score)
        
        confidence = 1.0 - u_score
        
        value = 0.5
        if any(word in text_lower for word in ["therefore", "thus", "hence", "conclusion"]):
            value += 0.2
        if any(word in text_lower for word in ["because", "since", "reason"]):
            value += 0.1
            
        return min(value, 1.0), min(u_score, 1.0)
    
    def _compute_node_uncertainty(
        self,
        node: ThoughtNode,
        candidates: List[str],
    ) -> float:
        if len(candidates) < 2:
            return node.uncertainty * 0.9
        
        similarities = []
        for i, c1 in enumerate(candidates):
            for c2 in candidates[i+1:]:
                sim = self._text_similarity(c1, c2)
                similarities.append(sim)
        
        disagreement = 1.0 - np.mean(similarities) if similarities else 0.0
        
        combined = 0.6 * node.uncertainty + 0.4 * disagreement
        return min(combined, 1.0)
    
    def _text_similarity(self, text1: str, text2: str) -> float:
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1 or not words2:
            return 0.5
            
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union) if union else 0.5
    
    def _expand_node(
        self,
        node: ThoughtNode,
        generate_fn: Optional[Callable],
        evaluate_fn: Optional[Callable],
    ) -> List[ThoughtNode]:
        if node.depth >= self.max_depth:
            node.state = NodeState.SOLVED
            return []
        
        candidates = self._generate_candidates(node, generate_fn)
        
        new_nodes = []
        for candidate in candidates[:self.max_breadth]:
            if evaluate_fn is None:
                value, uncertainty = self._default_evaluate(candidate)
            else:
                try:
                    value, uncertainty = evaluate_fn(candidate)
                except Exception:
                    value, uncertainty = self._default_evaluate(candidate)
            
            if uncertainty > self.uncertainty_threshold * 1.5:
                self.pruned_count += 1
                continue
            
            child = self._create_node(
                content=candidate,
                parent_id=node.node_id,
                depth=node.depth + 1,
                value=value,
                uncertainty=uncertainty,
                confidence=1.0 - uncertainty,
            )
            
            child.step_uncertainties = node.step_uncertainties + [uncertainty]
            
            new_nodes.append(child)
        
        node.children_ids = [n.node_id for n in new_nodes]
        node.state = NodeState.EXPANDED
        self.expansion_count += 1
        
        return new_nodes
    
    def _search_bfs(
        self,
        generate_fn: Optional[Callable],
        evaluate_fn: Optional[Callable],
    ) -> None:
        if not self.root_id:
            return
            
        frontier = [self.root_id]
        visited: Set[str] = set()
        
        while frontier and len(self.nodes) < 100:
            current_id = frontier.pop(0)
            
            if current_id in visited:
                continue
            visited.add(current_id)
            
            current = self.nodes[current_id]
            
            if current.depth >= self.max_depth:
                current.state = NodeState.SOLVED
                continue
            
            if current.uncertainty < self.uncertainty_threshold and current.depth > 0:
                current.state = NodeState.SOLVED
                continue
            
            new_nodes = self._expand_node(current, generate_fn, evaluate_fn)
            
            for new_node in new_nodes:
                if new_node.node_id not in visited:
                    frontier.append(new_node.node_id)
            
            if not new_nodes and current.uncertainty < self.uncertainty_threshold:
                current.state = NodeState.SOLVED
    
    def _search_dfs(
        self,
        generate_fn: Optional[Callable],
        evaluate_fn: Optional[Callable],
    ) -> None:
        if not self.root_id:
            return
            
        stack = [self.root_id]
        visited: Set[str] = set()
        
        while stack and len(self.nodes) < 100:
            current_id = stack.pop()
            
            if current_id in visited:
                continue
            visited.add(current_id)
            
            current = self.nodes[current_id]
            
            if current.depth >= self.max_depth:
                current.state = NodeState.SOLVED
                continue
            
            if current.uncertainty < self.uncertainty_threshold and current.depth > 0:
                current.state = NodeState.SOLVED
                continue
            
            new_nodes = self._expand_node(current, generate_fn, evaluate_fn)
            
            for new_node in reversed(new_nodes):
                if new_node.node_id not in visited:
                    stack.append(new_node.node_id)
    
    def _search_best_first(
        self,
        generate_fn: Optional[Callable],
        evaluate_fn: Optional[Callable],
    ) -> None:
        if not self.root_id:
            return
            
        root = self.nodes[self.root_id]
        pq = [(-root.get_score(), self.root_id)]
        visited: Set[str] = set()
        
        while pq and len(self.nodes) < 100:
            _, current_id = heapq.heappop(pq)
            
            if current_id in visited:
                continue
            visited.add(current_id)
            
            current = self.nodes[current_id]
            
            if current.depth >= self.max_depth:
                current.state = NodeState.SOLVED
                continue
            
            if current.uncertainty < self.uncertainty_threshold and current.depth > 0:
                current.state = NodeState.SOLVED
                continue
            
            new_nodes = self._expand_node(current, generate_fn, evaluate_fn)
            
            for new_node in new_nodes:
                if new_node.node_id not in visited:
                    heapq.heappush(pq, (-new_node.get_score(), new_node.node_id))
            
            if not new_nodes and len(pq) > 0:
                next_node = self.nodes[pq[0][1]]
                if next_node.uncertainty < self.uncertainty_threshold:
                    next_node.state = NodeState.SOLVED
    
    def _search_ucb(
        self,
        generate_fn: Optional[Callable],
        evaluate_fn: Optional[Callable],
    ) -> None:
        if not self.root_id:
            return
            
        exploration_constant = 1.0
        root = self.nodes[self.root_id]
        
        pq = [(-self._ucb_score(root, exploration_constant), self.root_id)]
        visited: Set[str] = set()
        
        while pq and len(self.nodes) < 100:
            _, current_id = heapq.heappop(pq)
            
            if current_id in visited:
                continue
            visited.add(current_id)
            
            current = self.nodes[current_id]
            
            if current.depth >= self.max_depth:
                current.state = NodeState.SOLVED
                continue
            
            new_nodes = self._expand_node(current, generate_fn, evaluate_fn)
            
            for new_node in new_nodes:
                if new_node.node_id not in visited:
                    score = self._ucb_score(new_node, exploration_constant)
                    heapq.heappush(pq, (-score, new_node.node_id))
    
    def _ucb_score(self, node: ThoughtNode, c: float) -> float:
        if node.visits == 0:
            return float('inf')
        
        exploitation = node.value
        exploration = c * np.sqrt(np.log(node.visits + 1) / node.visits)
        
        return exploitation + exploration
    
    def _extract_best_path(self) -> List[ThoughtNode]:
        if not self.root_id:
            return []
        
        solved_nodes = [n for n in self.nodes.values() if n.state == NodeState.SOLVED]
        
        if not solved_nodes:
            solved_nodes = list(self.nodes.values())
        
        if not solved_nodes:
            return []
        
        best = max(solved_nodes, key=lambda n: n.get_score())
        
        path = []
        current = best
        while current:
            path.append(current)
            if current.parent_id and current.parent_id in self.nodes:
                current = self.nodes[current.parent_id]
            else:
                break
        
        path.reverse()
        return path
    
    def get_tree_visualization(self) -> Dict[str, Any]:
        if not self.nodes:
            return {"error": "No tree available"}
        
        root = self.nodes[self.root_id] if self.root_id else None
        
        return {
            "root": root.to_dict() if root else None,
            "total_nodes": len(self.nodes),
            "depth": max(n.depth for n in self.nodes.values()) if self.nodes else 0,
            "solved": len([n for n in self.nodes.values() if n.state == NodeState.SOLVED]),
            "pruned": self.pruned_count,
        }
