"""
Process Reward Model for Step-Level Reasoning Verification
Lightweight verifier that predicts correctness of reasoning steps
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any, Tuple, Callable
from enum import Enum
import numpy as np


class StepVerdict(Enum):
    CORRECT = "correct"
    INCORRECT = "incorrect"
    UNCERTAIN = "uncertain"
    NEEDS_REVIEW = "needs_review"


@dataclass
class StepVerification:
    step_number: int
    content: str
    verdict: StepVerdict
    confidence: float
    score: float
    
    error_type: Optional[str] = None
    suggestions: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def is_correct(self, threshold: float = 0.5) -> bool:
        return self.score >= threshold and self.verdict != StepVerdict.INCORRECT
    
    def needs_correction(self) -> bool:
        return self.verdict in [StepVerdict.INCORRECT, StepVerdict.NEEDS_REVIEW]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step_number,
            "verdict": self.verdict.value,
            "confidence": self.confidence,
            "score": self.score,
            "error_type": self.error_type,
            "suggestions": self.suggestions,
        }


@dataclass
class ReasoningVerification:
    steps: List[StepVerification]
    overall_score: float
    reliable_steps: List[int]
    unreliable_steps: List[int]
    
    critical_errors: List[int]
    total_errors: int
    
    chain_reliability: float
    confidence_propagation: List[float]
    
    def get_verdict(self) -> str:
        if self.total_errors == 0:
            return "PASS"
        elif len(self.unreliable_steps) <= 2:
            return "PASS_WITH_WARNINGS"
        elif self.chain_reliability > 0.7:
            return "CONDITIONAL_PASS"
        else:
            return "FAIL"
    
    def requires_regeneration(self, threshold: float = 0.6) -> bool:
        return self.overall_score < threshold or len(self.unreliable_steps) > 3
    
    def get_fix_suggestions(self) -> Dict[int, List[str]]:
        suggestions = {}
        for step in self.steps:
            if step.needs_correction():
                suggestions[step.step_number] = step.suggestions
        return suggestions
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "verdict": self.get_verdict(),
            "overall_score": self.overall_score,
            "total_errors": self.total_errors,
            "chain_reliability": self.chain_reliability,
            "reliable_steps": self.reliable_steps,
            "unreliable_steps": self.unreliable_steps,
            "critical_errors": self.critical_errors,
            "requires_regeneration": self.requires_regeneration(),
            "steps": [s.to_dict() for s in self.steps],
        }


class ProcessRewardVerifier:
    def __init__(
        self,
        model: Any = None,
        tokenizer: Any = None,
        device: str = "cpu",
        confidence_threshold: float = 0.5,
        use_internal_states: bool = True,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.confidence_threshold = confidence_threshold
        self.use_internal_states = use_internal_states
        
        self.step_patterns = [
            r"Step\s+(\d+)[:\.]",
            r"\d+\.\s+(.+?)(?=\n\d+\.|\Z)",
            r"First[:\s]", r"Second[:\s]", r"Third[:\s]",
            r"Next[:\s]", r"Then[:\s]", r"Finally[:\s]",
            r"Therefore[:\s]", r"Thus[:\s]", r"Hence[:\s]",
            r"(?:because|since)[:\s]",
        ]
        
        self.error_patterns = {
            "calculation": [
                r"\d+\s*[\+\-\*/]\s*\d+\s*=\s*\d+",
                r"(?:error|mistake|wrong) in (?:calculation|math)",
            ],
            "logic": [
                r"(?:therefore|thus)[\s,]+but",
                r"(?:however|although)[\s,]+(?:therefore|thus)",
                r"(?:contradiction|inconsistent)",
            ],
            "factual": [
                r"(?:according to|research shows)[\s,]+but",
                r"(?:fact|truth)[\s,]+(?:however|but)",
            ],
            "reference": [
                r"(?:it|this|that)[\s,]+(?:refer to|refers to)",
                r"(?:undefined|unspecified)[\s,]+(?:it|this)",
            ],
        }
        
    def verify(
        self,
        prompt: str,
        reasoning_chain: str,
        return_all: bool = True,
    ) -> ReasoningVerification:
        steps = self._extract_steps(reasoning_chain)
        
        verifications = []
        for i, step in enumerate(steps):
            verification = self._verify_step(
                i + 1,
                step,
                prompt,
                reasoning_chain,
            )
            verifications.append(verification)
        
        reliable_steps = [v.step_number for v in verifications if v.is_correct()]
        unreliable_steps = [v.step_number for v in verifications if not v.is_correct()]
        critical_errors = [
            v.step_number for v in verifications 
            if v.verdict == StepVerdict.INCORRECT
        ]
        
        overall_score = np.mean([v.score for v in verifications]) if verifications else 0.5
        
        chain_reliability = self._compute_chain_reliability(verifications)
        
        confidence_propagation = self._compute_confidence_propagation(verifications)
        
        result = ReasoningVerification(
            steps=verifications,
            overall_score=overall_score,
            reliable_steps=reliable_steps,
            unreliable_steps=unreliable_steps,
            critical_errors=critical_errors,
            total_errors=len(critical_errors),
            chain_reliability=chain_reliability,
            confidence_propagation=confidence_propagation,
        )
        
        if return_all:
            return result
        return result
    
    def _extract_steps(self, reasoning_chain: str) -> List[str]:
        import re
        
        steps = []
        
        step_matches = list(re.finditer(r"Step\s+(\d+)[:\.]\s*(.+?)(?=\nStep\s+\d+|\Z)", reasoning_chain, re.DOTALL))
        if step_matches:
            for match in step_matches:
                steps.append(match.group(2).strip())
            return steps
        
        numbered = re.findall(r"\d+\.\s+(.+?)(?=\n\d+\.|\Z)", reasoning_chain, re.DOTALL)
        if numbered:
            return [s.strip() for s in numbered]
        
        ordinal_keywords = ["first", "second", "third", "next", "then", "finally"]
        current_step = []
        
        for line in reasoning_chain.split("\n"):
            line = line.strip()
            if not line:
                continue
            
            is_ordinal = any(line.lower().startswith(kw) for kw in ordinal_keywords)
            
            if is_ordinal or re.match(r"^\d+\)", line):
                if current_step:
                    steps.append(" ".join(current_step))
                    current_step = []
                current_step.append(re.sub(r"^\d+\)|^\w+[:\s]+", "", line))
            else:
                current_step.append(line)
        
        if current_step:
            steps.append(" ".join(current_step))
        
        if len(steps) <= 1:
            sentences = [s.strip() for s in reasoning_chain.split(".") if s.strip()]
            steps = [s for s in sentences if len(s) > 20]
        
        return steps[:20]
    
    def _verify_step(
        self,
        step_num: int,
        step_content: str,
        prompt: str,
        full_chain: str,
    ) -> StepVerification:
        errors = self._detect_errors(step_content, full_chain)
        
        logical_coherence = self._check_logical_coherence(step_content, full_chain)
        
        mathematical_correctness = self._check_mathematical(step_content)
        
        reference_validity = self._check_references(step_content, full_chain)
        
        internal_confidence = self._compute_internal_confidence(step_content) if self.use_internal_states else 0.5
        
        score = self._compute_step_score(
            errors, logical_coherence, mathematical_correctness,
            reference_validity, internal_confidence
        )
        
        if score >= 0.8:
            verdict = StepVerdict.CORRECT
            confidence = score
        elif score >= 0.5:
            if errors:
                verdict = StepVerdict.NEEDS_REVIEW
                confidence = 0.6
            else:
                verdict = StepVerdict.UNCERTAIN
                confidence = 0.5
        else:
            verdict = StepVerdict.INCORRECT
            confidence = 1.0 - score
        
        error_type = errors[0]["type"] if errors else None
        
        suggestions = self._generate_suggestions(
            step_content, errors, logical_coherence, mathematical_correctness
        )
        
        return StepVerification(
            step_number=step_num,
            content=step_content,
            verdict=verdict,
            confidence=confidence,
            score=score,
            error_type=error_type,
            suggestions=suggestions,
        )
    
    def _detect_errors(
        self,
        step_content: str,
        full_chain: str,
    ) -> List[Dict[str, Any]]:
        import re
        
        errors = []
        content_lower = step_content.lower()
        
        for error_type, patterns in self.error_patterns.items():
            for pattern in patterns:
                if re.search(pattern, content_lower, re.IGNORECASE):
                    errors.append({
                        "type": error_type,
                        "pattern": pattern,
                        "severity": self._assess_severity(error_type, content_lower),
                    })
        
        calculation_parts = re.findall(r'(\d+\.?\d*)\s*=\s*(\d+\.?\d*)', step_content)
        for left, right in calculation_parts:
            if float(left) != float(right):
                errors.append({
                    "type": "calculation",
                    "detail": f"Mismatch: {left} vs {right}",
                    "severity": 0.8,
                })
        
        contradiction_pairs = [
            ("however", "therefore"), ("although", "thus"),
            ("but", "hence"), ("despite", "consequently"),
        ]
        
        for word1, word2 in contradiction_pairs:
            if word1 in content_lower and word2 in content_lower:
                errors.append({
                    "type": "logic",
                    "detail": f"Contradiction: {word1} ... {word2}",
                    "severity": 0.9,
                })
        
        return errors
    
    def _assess_severity(self, error_type: str, content: str) -> float:
        severity_map = {
            "calculation": 0.8,
            "logic": 0.7,
            "factual": 0.9,
            "reference": 0.5,
        }
        base = severity_map.get(error_type, 0.5)
        
        if "obviously" in content or "clearly" in content:
            base += 0.1
        
        return min(base, 1.0)
    
    def _check_logical_coherence(
        self,
        step_content: str,
        full_chain: str,
    ) -> float:
        content_lower = step_content.lower()
        
        conclusion_words = ["therefore", "thus", "hence", "consequently", "so"]
        has_conclusion = any(word in content_lower for word in conclusion_words)
        
        premise_words = ["because", "since", "as", "given that", "assuming"]
        has_premise = any(word in content_lower for word in premise_words)
        
        if has_conclusion and not has_premise:
            return 0.6
        
        if "if" in content_lower and "then" not in content_lower and "therefore" not in content_lower:
            return 0.7
        
        linking_words = ["and", "also", "furthermore", "moreover"]
        linking_count = sum(1 for w in linking_words if w in content_lower)
        
        coherence = 0.8 + linking_count * 0.05
        return min(coherence, 1.0)
    
    def _check_mathematical(self, step_content: str) -> float:
        import re
        
        equation_matches = re.findall(r'(\d+\.?\d*)\s*([\+\-\*/^])\s*(\d+\.?\d*)\s*=\s*(\d+\.?\d*)', step_content)
        
        if not equation_matches:
            return 0.9
        
        correct = 0
        total = len(equation_matches)
        
        for left, op, right, result in equation_matches:
            a, b, c = float(left), float(right), float(result)
            
            computed = None
            if op == '+':
                computed = a + b
            elif op == '-':
                computed = a - b
            elif op == '*':
                computed = a * b
            elif op == '/':
                computed = a / b if b != 0 else None
            elif op == '^':
                computed = a ** b
            
            if computed is not None and abs(computed - c) < 0.01:
                correct += 1
        
        return correct / total if total > 0 else 0.9
    
    def _check_references(
        self,
        step_content: str,
        full_chain: str,
    ) -> float:
        import re
        
        pronouns = ["it", "this", "that", "these", "those", "he", "she", "they"]
        content_lower = step_content.lower()
        
        pronoun_count = sum(content_lower.count(f" {p} ") for p in pronouns)
        
        if pronoun_count == 0:
            return 1.0
        
        entities_before = re.findall(r'\b[A-Z][a-z]+\b', full_chain)
        
        if not entities_before:
            return 0.5
        
        pronoun_with_verb = re.findall(r'(?:it|this|that)\s+(?:is|was|are|were|has|have|can|could)', content_lower)
        
        if len(pronoun_with_verb) > len(set(entities_before)):
            return 0.6
        
        return 0.85
    
    def _compute_internal_confidence(self, step_content: str) -> float:
        if self.model is None or self.tokenizer is None:
            return 0.7
        
        try:
            inputs = self.tokenizer(step_content, return_tensors="pt").to(self.device)
            
            with torch.no_grad():
                outputs = self.model(**inputs, output_hidden_states=True)
                hidden = outputs.hidden_states[-1]
                
                attention = outputs.attentions[-1] if hasattr(outputs, 'attentions') else None
                
                token_confidences = torch.softmax(outputs.logits[0, -1], dim=-1)
                max_confidence = token_confidences.max().item()
                
                hidden_variance = torch.var(hidden).item()
                
                confidence = (max_confidence * 0.6 + (1 - min(hidden_variance, 1)) * 0.4)
                
                return confidence
                
        except Exception:
            return 0.7
    
    def _compute_step_score(
        self,
        errors: List[Dict],
        logical_coherence: float,
        mathematical_correctness: float,
        reference_validity: float,
        internal_confidence: float,
    ) -> float:
        error_penalty = sum(e["severity"] for e in errors) / 5.0
        
        score = (
            (1 - min(error_penalty, 1.0)) * 0.25 +
            logical_coherence * 0.2 +
            mathematical_correctness * 0.2 +
            reference_validity * 0.15 +
            internal_confidence * 0.2
        )
        
        return min(max(score, 0.0), 1.0)
    
    def _generate_suggestions(
        self,
        step_content: str,
        errors: List[Dict],
        logical_coherence: float,
        mathematical_correctness: float,
    ) -> List[str]:
        suggestions = []
        
        for error in errors:
            if error["type"] == "calculation":
                suggestions.append("Review arithmetic operations and verify calculations")
            elif error["type"] == "logic":
                suggestions.append("Check logical flow - ensure premises support conclusion")
            elif error["type"] == "factual":
                suggestions.append("Verify factual claims with reliable sources")
            elif error["type"] == "reference":
                suggestions.append("Ensure all references are clearly defined")
        
        if logical_coherence < 0.7:
            suggestions.append("Add explicit logical connectors to improve flow")
        
        if mathematical_correctness < 0.8:
            suggestions.append("Double-check mathematical computations")
        
        if not suggestions:
            suggestions.append("Step appears correct - consider verification")
        
        return suggestions
    
    def _compute_chain_reliability(
        self,
        verifications: List[StepVerification],
    ) -> float:
        if len(verifications) <= 1:
            return 1.0
        
        scores = [v.score for v in verifications]
        
        for i in range(len(scores) - 1):
            scores[i] = scores[i] * scores[i + 1]
        
        return np.mean(scores)
    
    def _compute_confidence_propagation(
        self,
        verifications: List[StepVerification],
    ) -> List[float]:
        if not verifications:
            return []
        
        propagation = []
        cumulative = verifications[0].score
        
        for i, v in enumerate(verifications):
            if i == 0:
                propagation.append(v.score)
            else:
                cumulative = cumulative * 0.7 + v.score * 0.3
                propagation.append(cumulative)
        
        return propagation
    
    def verify_batch(
        self,
        items: List[Tuple[str, str]],
    ) -> List[ReasoningVerification]:
        return [self.verify(p, r) for p, r in items]
    
    def get_summary(self, verification: ReasoningVerification) -> str:
        verdict = verification.get_verdict()
        
        if verdict == "PASS":
            return f"All {len(verification.steps)} steps verified. Chain is reliable."
        elif verdict == "PASS_WITH_WARNINGS":
            return f"{len(verification.steps)} steps, {len(verification.unreliable_steps)} need review."
        elif verdict == "CONDITIONAL_PASS":
            return f"Chain reliability: {verification.chain_reliability:.1%}. Review suggested."
        else:
            return f"FAILED: {verification.total_errors} critical errors found. Regenerate recommended."


try:
    import torch
except ImportError:
    torch = None
