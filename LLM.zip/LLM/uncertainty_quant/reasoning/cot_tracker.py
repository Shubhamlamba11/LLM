"""
Chain-of-Thought Uncertainty Tracking Module
Implements step-level confidence tracking with recurrent propagation
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Dict, Optional, Any, Tuple, Callable
import numpy as np
import re


class StepConfidence(Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    UNCERTAIN = "uncertain"


@dataclass
class ReasoningStep:
    step_number: int
    content: str
    keywords: List[str] = field(default_factory=list)
    confidence: float = 0.5
    importance: float = 1.0
    token_confidences: List[float] = field(default_factory=list)
    is_critical: bool = False
    depends_on: List[int] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_confidence_level(self) -> StepConfidence:
        if self.confidence >= 0.8:
            return StepConfidence.HIGH
        elif self.confidence >= 0.6:
            return StepConfidence.MEDIUM
        elif self.confidence >= 0.4:
            return StepConfidence.LOW
        return StepConfidence.UNCERTAIN
    
    def is_reliable(self, threshold: float = 0.6) -> bool:
        return self.confidence >= threshold and self.importance >= 0.5


@dataclass 
class CoTAnalysis:
    steps: List[ReasoningStep]
    overall_confidence: float
    weakest_step: Optional[ReasoningStep] = None
    critical_steps: List[ReasoningStep] = field(default_factory=list)
    confidence_chain: List[float] = field(default_factory=list)
    uncertainty_score: float = 0.0
    chain_reliability: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def get_step_issues(self) -> List[str]:
        issues = []
        for step in self.steps:
            if step.get_confidence_level() == StepConfidence.UNCERTAIN:
                issues.append(f"Step {step.step_number}: Highly uncertain ({step.confidence:.2f})")
            if step.is_critical and step.confidence < 0.5:
                issues.append(f"Step {step.step_number}: Critical step with low confidence")
        return issues
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "overall_confidence": self.overall_confidence,
            "uncertainty_score": self.uncertainty_score,
            "chain_reliability": self.chain_reliability,
            "n_steps": len(self.steps),
            "weakest_step": self.weakest_step.step_number if self.weakest_step else None,
            "critical_steps": [s.step_number for s in self.critical_steps],
            "issues": self.get_step_issues(),
        }


class CoTUncertaintyTracker:
    def __init__(
        self,
        model: Any = None,
        tokenizer: Any = None,
        device: str = "cpu",
        delta: float = 0.3,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device
        self.delta = delta
        self.step_patterns = [
            r"Step\s+\d+[:\.]",
            r"\d+\.\s+",
            r"First[:\s]", r"Second[:\s]", r"Third[:\s]",
            r"Next[:\s]", r"Then[:\s]", r"Finally[:\s]",
            r"Therefore[:\s]", r"Thus[:\s]", r"Hence[:\s]",
        ]
        
    def analyze(
        self,
        prompt: str,
        reasoning_response: str,
        return_all: bool = False,
    ) -> CoTAnalysis:
        steps = self._extract_steps(reasoning_response)
        
        for step in steps:
            self._analyze_step(step, prompt, reasoning_response)
        
        self._propagate_confidence(steps)
        self._identify_critical_steps(steps)
        
        overall_confidence = self._compute_overall_confidence(steps)
        uncertainty_score = 1.0 - overall_confidence
        chain_reliability = self._compute_chain_reliability(steps)
        
        weakest = min(steps, key=lambda s: s.confidence) if steps else None
        
        analysis = CoTAnalysis(
            steps=steps,
            overall_confidence=overall_confidence,
            weakest_step=weakest,
            critical_steps=[s for s in steps if s.is_critical],
            confidence_chain=[s.confidence for s in steps],
            uncertainty_score=uncertainty_score,
            chain_reliability=chain_reliability,
        )
        
        if return_all:
            return analysis
        return analysis
    
    def _extract_steps(self, reasoning_response: str) -> List[ReasoningStep]:
        steps = []
        sentences = re.split(r'(?<=[.!?])\s+', reasoning_response)
        
        current_step_num = 0
        current_content = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
                
            step_indicators = [
                r"step\s+(\d+)",
                r"^\d+\.\s+",
                r"^(first|second|third|fourth|fifth|next|then|finally|therefore|thus|hence)\s",
            ]
            
            is_new_step = False
            for pattern in step_indicators:
                match = re.search(pattern, sentence.lower())
                if match:
                    if current_content:
                        current_step_num += 1
                        steps.append(ReasoningStep(
                            step_number=current_step_num,
                            content=" ".join(current_content),
                        ))
                        current_content = []
                    is_new_step = True
                    break
            
            current_content.append(sentence)
            
            if len(sentence) > 10 and not is_new_step:
                if not current_content:
                    current_step_num += 1
                    steps.append(ReasoningStep(
                        step_number=current_step_num,
                        content=sentence,
                    ))
                elif len(current_content) >= 3:
                    current_step_num += 1
                    steps.append(ReasoningStep(
                        step_number=current_step_num,
                        content=" ".join(current_content[-3:]),
                    ))
        
        if current_content and current_step_num < len(steps) + 1:
            current_step_num += 1
            steps.append(ReasoningStep(
                step_number=current_step_num,
                content=" ".join(current_content),
            ))
        
        for i, step in enumerate(steps):
            if step.step_number == 0:
                step.step_number = i + 1
        
        return steps
    
    def _analyze_step(
        self,
        step: ReasoningStep,
        prompt: str,
        full_response: str,
    ) -> None:
        step.keywords = self._extract_keywords(step.content)
        
        step.token_confidences = self._estimate_token_confidences(step.content)
        
        step.confidence = np.mean(step.token_confidences) if step.token_confidences else 0.5
        
        step.importance = self._estimate_step_importance(step, prompt, full_response)
        
        step.is_critical = self._is_critical_step(step, prompt)
    
    def _extract_keywords(self, text: str) -> List[str]:
        words = text.lower().split()
        
        stop_words = {
            'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been',
            'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
            'would', 'could', 'should', 'may', 'might', 'must', 'shall',
            'can', 'need', 'to', 'of', 'in', 'for', 'on', 'with', 'at',
            'by', 'from', 'as', 'into', 'through', 'during', 'before',
            'after', 'above', 'below', 'between', 'under', 'again',
            'further', 'then', 'once', 'and', 'but', 'or', 'nor', 'so',
            'yet', 'both', 'each', 'few', 'more', 'most', 'other', 'some',
            'such', 'only', 'own', 'same', 'than', 'too', 'very', 'just',
            'also', 'now', 'here', 'there', 'when', 'where', 'why', 'how',
            'all', 'any', 'no', 'not', 'if', 'this', 'that', 'these',
            'those', 'it', 'its', 'i', 'we', 'they', 'he', 'she', 'him',
            'her', 'his', 'my', 'our', 'your', 'their', 'what', 'which',
            'who', 'whom', 'whose', 'let', "'s", "'t", "'re", "'ve", "'d",
        }
        
        keywords = [
            w.strip('.,!?;:()[]{}"\'-') 
            for w in words 
            if len(w) > 3 and w.lower() not in stop_words
        ]
        
        return list(set(keywords))[:10]
    
    def _estimate_token_confidences(self, text: str) -> List[float]:
        confidence_scores = []
        
        words = text.split()
        for i, word in enumerate(words):
            position_factor = 1.0 - (abs(i - len(words)/2) / len(words))
            
            uncertainty_words = {
                'maybe': 0.4, 'perhaps': 0.4, 'possibly': 0.5, 'probably': 0.5,
                'might': 0.5, 'could': 0.5, 'uncertain': 0.3, 'unclear': 0.3,
            }
            
            for uw, score in uncertainty_words.items():
                if uw in word.lower():
                    confidence_scores.append(score * position_factor)
                    break
            else:
                if word[-1:] in '.!?':
                    confidence_scores.append(0.7 * position_factor)
                elif any(c.isdigit() for c in word):
                    confidence_scores.append(0.6 * position_factor)
                else:
                    confidence_scores.append(0.8 * position_factor)
        
        return confidence_scores
    
    def _estimate_step_importance(
        self,
        step: ReasoningStep,
        prompt: str,
        full_response: str,
    ) -> float:
        importance_keywords = {
            'therefore': 1.0, 'thus': 1.0, 'hence': 1.0, 'conclude': 1.0,
            'conclusion': 1.0, 'result': 0.9, 'answer': 0.9, 'final': 0.9,
            'key': 0.8, 'important': 0.8, 'critical': 0.9, 'main': 0.8,
            'primary': 0.8, 'essential': 0.8, 'because': 0.7, 'since': 0.7,
            'so': 0.7, 'reason': 0.7, 'therefore': 1.0,
        }
        
        content_lower = step.content.lower()
        
        for keyword, importance in importance_keywords.items():
            if keyword in content_lower:
                return importance
        
        if len(step.keywords) > 3:
            prompt_keywords = set(prompt.lower().split())
            overlap = len(set(step.keywords) & prompt_keywords)
            return min(0.5 + overlap * 0.1, 1.0)
        
        return 0.5
    
    def _is_critical_step(self, step: ReasoningStep, prompt: str) -> bool:
        critical_patterns = [
            r'\d+\s*[=+\-*/^]\s*\d+',
            r'(?:therefore|thus|hence)\s+(?:the|this|it)',
            r'(?:final|answer|result|conclusion)',
            r'(?:if|when|because|since)',
        ]
        
        content_lower = step.content.lower()
        
        for pattern in critical_patterns:
            if re.search(pattern, content_lower):
                return True
        
        if any(kw in prompt.lower() for kw in step.keywords[:3]):
            return True
        
        return False
    
    def _propagate_confidence(self, steps: List[ReasoningStep]) -> None:
        if len(steps) < 2:
            return
        
        accumulated = [steps[0].confidence]
        
        for i in range(1, len(steps)):
            qi = np.mean([
                r * c 
                for r, c in zip(steps[i-1].token_confidences[-5:], steps[i-1].token_confidences[-5:])
                if r != 0 and c != 0
            ]) if steps[i-1].token_confidences else 0.5
            
            pi = self.delta * qi + (1 - self.delta) * accumulated[-1]
            accumulated.append(pi)
            
            steps[i].confidence = min(
                steps[i].confidence * 0.7 + pi * 0.3,
                1.0
            )
    
    def _identify_critical_steps(self, steps: List[ReasoningStep]) -> None:
        for step in steps:
            if step.is_critical and step.confidence < 0.6:
                step.is_critical = True
            elif step.importance > 0.8 and step.confidence < 0.5:
                step.is_critical = True
    
    def _compute_overall_confidence(self, steps: List[ReasoningStep]) -> float:
        if not steps:
            return 0.5
        
        weighted_sum = sum(
            step.confidence * step.importance 
            for step in steps
        )
        total_weight = sum(step.importance for step in steps)
        
        return weighted_sum / total_weight if total_weight > 0 else 0.5
    
    def _compute_chain_reliability(self, steps: List[ReasoningStep]) -> float:
        if len(steps) < 2:
            return 1.0
        
        reliability_scores = []
        for i in range(len(steps) - 1):
            transition = 1.0 - abs(steps[i].confidence - steps[i+1].confidence)
            reliability_scores.append(transition)
        
        return np.mean(reliability_scores)
    
    def get_uncertain_steps(
        self, analysis: CoTAnalysis, threshold: float = 0.5
    ) -> List[ReasoningStep]:
        return [s for s in analysis.steps if s.confidence < threshold]
    
    def suggest_refinement(
        self, analysis: CoTAnalysis
    ) -> List[Dict[str, Any]]:
        suggestions = []
        
        if analysis.weakest_step:
            suggestions.append({
                "type": "refine_step",
                "step_number": analysis.weakest_step.step_number,
                "reason": f"Lowest confidence: {analysis.weakest_step.confidence:.2f}",
                "action": "Request clarification or verification for this step",
            })
        
        low_confidence_chain = []
        for i in range(len(analysis.confidence_chain) - 1):
            if abs(analysis.confidence_chain[i] - analysis.confidence_chain[i+1]) > 0.3:
                low_confidence_chain.append(i+1)
        
        if low_confidence_chain:
            suggestions.append({
                "type": "check_transitions",
                "steps": low_confidence_chain,
                "reason": "Large confidence jumps detected",
                "action": "Verify reasoning continuity",
            })
        
        if analysis.chain_reliability < 0.6:
            suggestions.append({
                "type": "reevaluate_chain",
                "reason": f"Chain reliability: {analysis.chain_reliability:.2f}",
                "action": "Consider re-deriving the reasoning chain",
            })
        
        return suggestions
