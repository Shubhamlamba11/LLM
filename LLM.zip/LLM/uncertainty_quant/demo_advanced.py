"""
Advanced Demo - Full Feature Showcase
"""

import json

try:
    from transformers import AutoModelForCausalLM, AutoTokenizer
    HAS_TRANSFORMERS = True
except ImportError:
    HAS_TRANSFORMERS = False
    print("Note: transformers not installed. Using heuristic methods only.")


def demo_advanced_uncertainty():
    from uncertainty_quant.core.advanced_estimator import AdvancedUncertaintyEstimator, UncertaintyMethod
    
    print("=" * 70)
    print("ADVANCED UNCERTAINTY ESTIMATION")
    print("=" * 70)
    
    estimator = AdvancedUncertaintyEstimator()
    
    test_cases = [
        {
            "prompt": "What is the capital of France?",
            "response": "The capital of France is Paris.",
            "expected": "LOW"
        },
        {
            "prompt": "Analyze the implications of quantum computing on cryptography.",
            "response": "Quantum computing could potentially break current encryption methods...",
            "expected": "MEDIUM"
        },
        {
            "prompt": "Calculate 15% of 847.",
            "response": "15% of 847 is 127.05.",
            "expected": "LOW"
        },
        {
            "prompt": "What happened in 3025?",
            "response": "In 3025, humanity colonized Mars.",
            "expected": "HIGH"
        },
    ]
    
    for case in test_cases:
        result = estimator.estimate(
            case["prompt"],
            case["response"],
            return_all=True,
        )
        
        print(f"\n{'-' * 50}")
        print(f"Prompt: {case['prompt'][:60]}...")
        print(f"Response: {case['response'][:50]}...")
        print(f"\nUncertainty: {result.total_uncertainty:.3f}")
        print(f"Confidence: {result.confidence:.3f}")
        print(f"Risk Level: {result.risk_level} (expected: {case['expected']})")
        print(f"Epistemic: {result.epistemic:.3f}")
        print(f"Aleatoric: {result.aleatoric:.3f}")
        print(f"\nMethod Scores:")
        for method, score in result.method_scores.items():
            print(f"  {method}: {score:.3f}")
        print(f"\nRecommendations:")
        for rec in result.recommendations[:2]:
            print(f"  - {rec}")


def demo_process_reward_verifier():
    from uncertainty_quant.reasoning.prm_verifier import ProcessRewardVerifier
    
    print("\n" + "=" * 70)
    print("PROCESS REWARD MODEL - Step Verification")
    print("=" * 70)
    
    verifier = ProcessRewardVerifier()
    
    reasoning_chains = [
        {
            "prompt": "Solve: 25 + 17",
            "chain": """
Step 1: Identify the numbers to add: 25 and 17
Step 2: Add the ones place: 5 + 7 = 12
Step 3: Write down 2, carry 1
Step 4: Add the tens: 2 + 1 + 1 (carried) = 4
Step 5: Therefore, 25 + 17 = 32
"""
        },
        {
            "prompt": "Explain photosynthesis",
            "chain": """
Step 1: Photosynthesis is the process by which plants convert light energy
Step 2: The equation is CO2 + H2O + light → glucose + O2
Step 3: This happens in the chloroplasts
Step 4: Therefore plants produce oxygen
Step 5: This is essential for life on Earth
"""
        },
        {
            "prompt": "Calculate area of circle with r=5",
            "chain": """
Step 1: Formula for circle area is πr²
Step 2: Given r = 5
Step 3: Calculate: π × 5² = π × 25
Step 4: = 78.54 square units
Step 5: Therefore the area is 78.54
"""
        },
    ]
    
    for case in reasoning_chains:
        print(f"\n{'-' * 50}")
        print(f"Prompt: {case['prompt']}")
        
        result = verifier.verify(case["prompt"], case["chain"], return_all=True)
        
        print(f"\nVerdict: {result.get_verdict()}")
        print(f"Overall Score: {result.overall_score:.3f}")
        print(f"Chain Reliability: {result.chain_reliability:.3f}")
        print(f"Total Errors: {result.total_errors}")
        
        print(f"\nStep Analysis:")
        for step in result.steps:
            status = "[OK]" if step.is_correct() else "[FAIL]"
            print(f"  {status} Step {step.step_number}: "
                  f"score={step.score:.2f}, verdict={step.verdict.value}")
            if step.suggestions:
                for sug in step.suggestions[:1]:
                    print(f"      -> {sug[:60]}...")
        
        if result.requires_regeneration():
            print(f"\n[!] REGENERATION RECOMMENDED")
        else:
            print(f"\n[+] Reasoning chain verified")


def demo_batch_processing():
    from uncertainty_quant.core.advanced_estimator import AdvancedUncertaintyEstimator
    
    print("\n" + "=" * 70)
    print("BATCH PROCESSING")
    print("=" * 70)
    
    estimator = AdvancedUncertaintyEstimator()
    
    items = [
        ("What is AI?", "AI stands for Artificial Intelligence."),
        ("What is ML?", "Machine Learning is a subset of AI."),
        ("What is DL?", "Deep Learning uses neural networks."),
        ("What is NLP?", "Natural Language Processing deals with text."),
        ("What is CV?", "Computer Vision processes images."),
    ] * 10
    
    print(f"Processing {len(items)} items...")
    
    results = estimator.estimate_batch(items, max_workers=4)
    
    avg_uncertainty = sum(r.total_uncertainty for r in results) / len(results)
    
    print(f"\nCompleted: {len(results)} items")
    print(f"Average Uncertainty: {avg_uncertainty:.3f}")
    print(f"High Uncertainty Items: {sum(1 for r in results if r.total_uncertainty > 0.5)}")


def demo_calibration():
    from uncertainty_quant.core.advanced_estimator import AdvancedUncertaintyEstimator
    from uncertainty_quant.core.calibration import Calibrator, CalibrationMethod
    
    print("\n" + "=" * 70)
    print("CALIBRATION")
    print("=" * 70)
    
    estimator = AdvancedUncertaintyEstimator()
    calibrator = Calibrator(method=CalibrationMethod.TEMPERATURE_SCALING)
    
    training_data = [
        ("What is 2+2?", "2+2 = 4"),
        ("What is 3+3?", "3+3 = 6"),
        ("Is the sky blue?", "Yes, the sky is blue"),
    ] * 100
    
    uncertainties = []
    correctness = []
    
    for prompt, response in training_data:
        result = estimator.estimate(prompt, response)
        uncertainties.append(result.total_uncertainty)
        correctness.append(result.total_uncertainty < 0.4)
    
    calibrator.fit(uncertainties, correctness)
    
    eval_result = calibrator.evaluate_calibration(uncertainties, correctness)
    
    print(f"\nCalibration Results:")
    print(f"  ECE (Expected Calibration Error): {eval_result['ECE']:.4f}")
    print(f"  MCE (Max Calibration Error): {eval_result['MCE']:.4f}")
    print(f"  Accuracy: {eval_result['accuracy']:.2%}")


def demo_routing():
    from uncertainty_quant.reasoning.router import UncertaintyAwareRouter
    
    print("\n" + "=" * 70)
    print("UNCERTAINTY-AWARE ROUTING")
    print("=" * 70)
    
    router = UncertaintyAwareRouter()
    
    queries = [
        "What is the capital of Japan?",
        "Analyze the implications of AGI on society, considering economic, ethical, and technological perspectives.",
        "Calculate the integral of sin(x) from 0 to π",
        "What should I have for dinner?",
        "Prove that the square root of 2 is irrational.",
    ]
    
    for query in queries:
        decision = router.route(query, return_all=True)
        
        print(f"\n{'-' * 50}")
        query_display = query[:45].replace('\u03c0', 'pi')
        print(f"Query: {query_display}...")
        print(f"Selected Solver: {decision.selected_solver.value}")
        print(f"Uncertainty: {decision.uncertainty:.3f}")
        print(f"Needs Verification: {decision.requires_additional_verification()}")
        print(f"Needs Human Review: {decision.needs_human_review()}")
        
        print(f"Alternatives:")
        for alt, score in decision.alternatives[:2]:
            print(f"  - {alt.value}: {score:.3f}")


def run_all_demos():
    print("\n" + "#" * 70)
    print("#" + " " * 68 + "#")
    print("#" + "    ADVANCED UNCERTAINTY QUANTIFICATION SYSTEM - FULL DEMO".center(68) + "#")
    print("#" + " " * 68 + "#")
    print("#" * 70)
    
    demo_advanced_uncertainty()
    demo_process_reward_verifier()
    demo_batch_processing()
    demo_calibration()
    demo_routing()
    
    print("\n" + "#" * 70)
    print("#" + " " * 68 + "#")
    print("#" + "    ALL ADVANCED DEMOS COMPLETED".center(68) + "#")
    print("#" + " " * 68 + "#")
    print("#" * 70)


if __name__ == "__main__":
    run_all_demos()
