"""
Example: Using Uncertainty Quantification with a Real LLM Model
============================================================

This script demonstrates how to properly use the uncertainty quantification
system with a real HuggingFace model for accurate results.

PREREQUISITES:
    pip install torch transformers

USAGE:
    python example_with_model.py
    
    Or if you have a GPU:
    python example_with_model.py --device cuda
"""

import argparse
import json
from typing import List, Dict, Any


def example_basic_usage():
    """Basic uncertainty estimation with a real model"""
    print("\n" + "=" * 60)
    print("EXAMPLE 1: Basic Uncertainty Estimation")
    print("=" * 60)
    
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from uncertainty_quant import AdvancedUncertaintyEstimator
        
        print("\nLoading model (this may take a few minutes)...")
        
        model_name = "microsoft/Phi-3-mini-128k-instruct"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            device_map="auto",
            torch_dtype="float16",
        )
        
        estimator = AdvancedUncertaintyEstimator(
            model=model,
            tokenizer=tokenizer,
        )
        
        test_cases = [
            ("What is the capital of France?", True, "Simple factual"),
            ("What is machine learning?", True, "Definition"),
            ("Should I invest in stocks?", None, "Subjective"),
            ("Who won the Nobel Prize 2024?", False, "Hallucination test"),
        ]
        
        for prompt, expected, case_type in test_cases:
            print(f"\n[{case_type}]")
            print(f"Q: {prompt}")
            
            inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
            outputs = model.generate(**inputs, max_new_tokens=100)
            response = tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            print(f"A: {response[:100]}...")
            
            result = estimator.estimate(prompt, response)
            
            print(f"Uncertainty: {result.total_uncertainty:.3f}")
            print(f"Confidence: {result.confidence:.3f}")
            print(f"Risk: {result.risk_level}")
            print(f"Methods: {len(result.method_scores)} uncertainty methods used")
            
    except ImportError as e:
        print(f"\nError: {e}")
        print("Install dependencies: pip install torch transformers")
        print("\nFalling back to heuristic mode...")
        example_heuristic_fallback()


def example_hallucination_detection():
    """Hallucination detection with real model"""
    print("\n" + "=" * 60)
    print("EXAMPLE 2: Hallucination Detection")
    print("=" * 60)
    
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from uncertainty_quant import HallucinationDetector
        
        print("\nLoading model...")
        
        model_name = "microsoft/Phi-3-mini-128k-instruct"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            device_map="auto",
            torch_dtype="float16",
        )
        
        detector = HallucinationDetector(model=model, tokenizer=tokenizer)
        
        test_cases = [
            {
                "prompt": "Who won the Nobel Prize in Physics 2024?",
                "expected_hallucination": True,
            },
            {
                "prompt": "What is machine learning?",
                "expected_hallucination": False,
            },
        ]
        
        for case in test_cases:
            print(f"\nPrompt: {case['prompt']}")
            
            inputs = tokenizer(case["prompt"], return_tensors="pt").to(model.device)
            outputs = model.generate(**inputs, max_new_tokens=100)
            response = tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            print(f"Response: {response[:100]}...")
            
            result = detector.detect(case["prompt"], response, return_all=True)
            
            print(f"Is Hallucination: {result.is_hallucination}")
            print(f"Risk Level: {result.risk_level}")
            print(f"Confidence: {result.confidence:.3f}")
            
            expected = "Hallucination" if case["expected_hallucination"] else "Correct"
            actual = "Hallucination" if result.is_hallucination else "Correct"
            status = "OK" if expected == actual else "WRONG"
            print(f"Expected: {expected} | Got: {actual} [{status}]")
            
    except ImportError as e:
        print(f"\nError: {e}")
        print("Install dependencies: pip install torch transformers")


def example_calibration():
    """Demonstrate calibration on a dataset"""
    print("\n" + "=" * 60)
    print("EXAMPLE 3: Calibration Test")
    print("=" * 60)
    
    try:
        from transformers import AutoModelForCausalLM, AutoTokenizer
        from uncertainty_quant import AdvancedUncertaintyEstimator
        from uncertainty_quant.evaluation import UncertaintyEvaluator
        import numpy as np
        
        print("\nLoading model...")
        
        model_name = "microsoft/Phi-3-mini-128k-instruct"
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForCausalLM.from_pretrained(
            model_name,
            device_map="auto",
            torch_dtype="float16",
        )
        
        estimator = AdvancedUncertaintyEstimator(model=model, tokenizer=tokenizer)
        evaluator = UncertaintyEvaluator()
        
        test_prompts = [
            "What is the capital of Japan?",
            "What is 2+2?",
            "What is H2O?",
            "What planet are we on?",
            "What is artificial intelligence?",
            "Who invented the telephone?",
            "What is photosynthesis?",
            "What is the speed of light?",
        ] * 10
        
        confidences = []
        correct = []
        
        print(f"\nTesting {len(test_prompts)} cases...")
        
        for i, prompt in enumerate(test_prompts):
            if i % 10 == 0:
                print(f"  Progress: {i}/{len(test_prompts)}")
            
            inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
            outputs = model.generate(**inputs, max_new_tokens=50)
            response = tokenizer.decode(outputs[0], skip_special_tokens=True)
            
            result = estimator.estimate(prompt, response)
            confidences.append(result.confidence)
            
            expected_answers = {
                "japan": "tokyo",
                "2+2": "4",
                "h2o": "water",
                "planet": "earth",
                "artificial intelligence": "ai",
                "telephone": "bell",
                "photosynthesis": "plant",
                "speed of light": "299",
            }
            
            is_correct = any(
                keyword in response.lower() 
                for keyword in expected_answers.values()
            )
            correct.append(is_correct)
        
        confidences = np.array(confidences)
        correct = np.array(correct)
        
        cal_report = evaluator.evaluate_calibration(confidences, correct)
        sel_report = evaluator.evaluate_selective_prediction(confidences, correct)
        
        print(f"\n{'='*40}")
        print("RESULTS:")
        print(f"{'='*40}")
        print(f"ECE: {cal_report.ece:.4f} (target < 0.05)")
        print(f"AUROC: {sel_report.auroc:.4f} (target > 0.85)")
        print(f"Accuracy: {correct.mean():.2%}")
        print(f"Coverage @ 90% accuracy: {sel_report.coverage_at_90_accuracy:.2%}")
        
        if cal_report.ece < 0.05:
            print("\n[SUCCESS] Well-calibrated!")
        else:
            print("\n[NEEDS IMPROVEMENT] Calibration could be better")
            
    except ImportError as e:
        print(f"\nError: {e}")
        print("Install dependencies: pip install torch transformers")


def example_heuristic_fallback():
    """Example using heuristic-based estimation (no model needed)"""
    print("\n" + "=" * 60)
    print("EXAMPLE: Heuristic-Based Estimation (No Model)")
    print("=" * 60)
    
    from uncertainty_quant import AdvancedUncertaintyEstimator, HallucinationDetector
    
    estimator = AdvancedUncertaintyEstimator()
    detector = HallucinationDetector()
    
    test_cases = [
        {
            "prompt": "What is the capital of France?",
            "response": "The capital of France is Paris.",
            "expected": "factual",
        },
        {
            "prompt": "Who won the Nobel Prize 2024?",
            "response": "John Smith won the Nobel Prize.",
            "expected": "hallucination",
        },
    ]
    
    for case in test_cases:
        print(f"\n[{case['expected'].upper()}]")
        print(f"Q: {case['prompt']}")
        print(f"A: {case['response']}")
        
        result = estimator.estimate(case["prompt"], case["response"])
        print(f"Uncertainty: {result.total_uncertainty:.3f}")
        print(f"Confidence: {result.confidence:.3f}")
        
        hall_result = detector.detect(case["prompt"], case["response"], return_all=True)
        print(f"Hallucination Detected: {hall_result.is_hallucination}")
        print(f"Risk Level: {hall_result.risk_level}")


def main():
    parser = argparse.ArgumentParser(description="Uncertainty Quantification Examples")
    parser.add_argument("--device", default="cpu", choices=["cpu", "cuda"],
                        help="Device to use (cuda requires GPU)")
    parser.add_argument("--example", default="all", 
                        choices=["all", "basic", "hallucination", "calibration", "heuristic"],
                        help="Which example to run")
    
    args = parser.parse_args()
    
    print("""
================================================================================
           UNCERTAINTY QUANTIFICATION SYSTEM - EXAMPLES
================================================================================

  This system estimates uncertainty in LLM outputs.

  For best results, use with a real model:

    pip install torch transformers
    python example_with_model.py

  Or run with GPU:

    python example_with_model.py --device cuda

================================================================================
    """)
    
    if args.example in ["all", "basic"]:
        example_basic_usage()
    
    if args.example in ["all", "hallucination"]:
        example_hallucination_detection()
    
    if args.example in ["all", "calibration"]:
        example_calibration()
    
    if args.example in ["all", "heuristic"]:
        example_heuristic_fallback()


if __name__ == "__main__":
    main()
